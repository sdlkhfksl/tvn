import{Q as e,S as t,T as i,V as a,m as n,A as o,aY as s,r,aZ as l,aa as d,a7 as c,a_ as u,a$ as h,a9 as p,x as v,b0 as m,a as f,h as g,e as _,i as y,L as k,N as b,$ as x,z as $,ac as w,ad as C,n as A,b1 as I,aQ as E,b2 as z,b3 as S,b4 as T,b5 as L,b6 as O,b7 as M,b8 as P,b9 as F,aB as D,ba as B,bb as N,bc as V,bd as q,be as j,bf as R,bg as U,bh as H,bi as G,bj as W,bk as K,bl as Y,bm as Z,bn as Q,aS as J,bo as X,bp as ee,bq as te,br as ie,bs as ae,ag as ne,bt as oe,bu as se,bv as re,bw as le,bx as de,by as ce,bz as ue,bA as he,bB as pe,bC as ve,bD as me,bE as fe,bF as ge,bG as _e,bH as ye,bI as ke,bJ as be,bK as xe,bL as $e,bM as we,bN as Ce,bO as Ae,bP as Ie,bQ as Ee,bR as ze,E as Se,bS as Te,bT as Le,bU as Oe,bV as Me,bW as Pe,bX as Fe,bY as De,bZ as Be,b_ as Ne,b$ as Ve,c0 as qe,c1 as je,c2 as Re,c3 as Ue,c4 as He,c5 as Ge,c6 as We,c7 as Ke,c8 as Ye,c9 as Ze,ca as Qe,cb as Je,cc as Xe,cd as et,ce as tt,cf as it,cg as at,ch as nt,ci as ot,cj as st,ck as rt,cl as lt,cm as dt,cn as ct,co as ut,cp as ht,cq as pt,cr as vt,cs as mt,ct as ft,cu as gt,cv as _t,cw as yt,cx as kt,cy as bt,cz as xt,cA as $t,cB as wt,cC as Ct,cD as At,az as It,cE as Et,cF as zt,cG as St,cH as Tt,cI as Lt,cJ as Ot,cK as Mt,cL as Pt,cM as Ft,cN as Dt,cO as Bt,cP as Nt,cQ as Vt,cR as qt,cS as jt,cT as Rt,cU as Ut,cV as Ht,cW as Gt,cX as Wt,cY as Kt,cZ as Yt,c_ as Zt,c$ as Qt,d0 as Jt,d1 as Xt,d2 as ei,d3 as ti,d4 as ii,d5 as ai,d6 as ni,d7 as oi,d8 as si,d9 as ri,da as li,db as di,dc as ci,dd as ui,de as hi,df as pi,dg as vi,dh as mi,di as fi,dj as gi,dk as _i,dl as yi,dm as ki,dn as bi,dp as xi,dq as $i,dr as wi,ds as Ci,dt as Ai,du as Ii,dv as Ei,dw as zi,dx as Si,dy as Ti,dz as Li,dA as Oi,dB as Mi,dC as Pi,dD as Fi,dE as Di,dF as Bi,dG as Ni,dH as Vi,dI as qi,dJ as ji,dK as Ri,dL as Ui,dM as Hi,dN as Gi,dO as Wi,dP as Ki,dQ as Yi,dR as Zi,t as Qi,I as Ji,j as Xi,Z as ea,aK as ta,aD as ia,dS as aa,dT as na,dU as oa,dV as sa,dW as ra,dX as la,dY as da,dZ as ca,d_ as ua,d$ as ha,e0 as pa,e1 as va,aM as ma,e2 as fa,e3 as ga,e4 as _a,e5 as ya,e6 as ka,o as ba,e7 as xa,_ as $a,e8 as wa,e9 as Ca,ea as Aa,eb as Ia,ec as Ea,ed as za,ee as Sa,ef as Ta,eg as La,eh as Oa,ei as Ma,ej as Pa,ek as Fa,el as Da,em as Ba,en as Na,eo as Va,ep as qa,eq as ja,er as Ra,es as Ua,et as Ha,eu as Ga,ev as Wa,ax as Ka,ew as Ya,ex as Za,ey as Qa,ez as Ja,eA as Xa,eB as en,eC as tn,eD as an,eE as nn,eF as on,eG as sn,eH as rn,eI as ln,J as dn,af as cn}from"./main-ad130be7.js";import{d as un,a as hn}from"./c.d262aab0.js";import{a as pn,c as vn,u as mn,m as fn,s as gn,T as _n,b as yn,d as kn}from"./c.3f859915.js";import"./c.0ca5587f.js";import"./c.82eccc94.js";import"./c.f1291e50.js";import"./c.2d5ed670.js";import"./c.2ee83bd0.js";import{c as bn,u as xn}from"./c.743a15a1.js";import{s as $n,a as wn,b as Cn}from"./c.4266acdb.js";import{b as An,e as In}from"./c.0a1cf8d0.js";import{d as En}from"./c.9b92f489.js";import{i as zn}from"./c.21c042d4.js";import"./c.8d4c35ad.js";import{g as Sn}from"./c.f2bb3724.js";import"./c.4feb0cb8.js";import{a as Tn}from"./c.42d6aebd.js";import"./c.3da15c48.js";let Ln=!1,On=[],Mn=[];function Pn(){Ln=!0,requestAnimationFrame((function(){Ln=!1,function(e){for(;e.length;)Fn(e.shift())}(On),setTimeout((function(){!function(e){for(let t=0,i=e.length;t<i;t++)Fn(e.shift())}(Mn)}))}))}function Fn(e){const t=e[0],i=e[1],a=e[2];try{i.apply(t,a)}catch(e){setTimeout((()=>{throw e}))}}function Dn(e,t,i){Ln||Pn(),Mn.push([e,t,i])}const Bn=(e,t,i)=>{const a=new Map;for(let n=t;n<=i;n++)a.set(e[n],n);return a},Nn=e(class extends t{constructor(e){if(super(e),e.type!==i.CHILD)throw Error("repeat() can only be used in text expressions")}dt(e,t,i){let a;void 0===i?i=t:void 0!==t&&(a=t);const n=[],o=[];let s=0;for(const t of e)n[s]=a?a(t,s):s,o[s]=i(t,s),s++;return{values:o,keys:n}}render(e,t,i){return this.dt(e,t,i).values}update(e,[t,i,n]){var o;const s=pn(e),{values:r,keys:l}=this.dt(t,i,n);if(!Array.isArray(s))return this.at=l,r;const d=null!==(o=this.at)&&void 0!==o?o:this.at=[],c=[];let u,h,p=0,v=s.length-1,m=0,f=r.length-1;for(;p<=v&&m<=f;)if(null===s[p])p++;else if(null===s[v])v--;else if(d[p]===l[m])c[m]=vn(s[p],r[m]),p++,m++;else if(d[v]===l[f])c[f]=vn(s[v],r[f]),v--,f--;else if(d[p]===l[f])c[f]=vn(s[p],r[f]),mn(e,c[f+1],s[p]),p++,f--;else if(d[v]===l[m])c[m]=vn(s[v],r[m]),mn(e,s[p],s[v]),v--,m++;else if(void 0===u&&(u=Bn(l,m,f),h=Bn(d,p,v)),u.has(d[p]))if(u.has(d[v])){const t=h.get(l[m]),i=void 0!==t?s[t]:null;if(null===i){const t=mn(e,s[p]);vn(t,r[m]),c[m]=t}else c[m]=vn(i,r[m]),mn(e,s[p],i),s[t]=null;m++}else fn(s[v]),v--;else fn(s[p]),p++;for(;m<=f;){const t=mn(e,c[f+1]);vn(t,r[m]),c[m++]=t}for(;p<=v;){const e=s[p++];null!==e&&fn(e)}return this.at=l,gn(e,c),a}});function Vn(e){if(!e||"object"!=typeof e)return e;if("[object Date]"==Object.prototype.toString.call(e))return new Date(e.getTime());if(Array.isArray(e))return e.map(Vn);var t={};return Object.keys(e).forEach((function(i){t[i]=Vn(e[i])})),t}class qn extends TypeError{constructor(e,t){let i;const{message:a,...n}=e,{path:o}=e;super(0===o.length?a:"At path: "+o.join(".")+" -- "+a),this.value=void 0,this.key=void 0,this.type=void 0,this.refinement=void 0,this.path=void 0,this.branch=void 0,this.failures=void 0,Object.assign(this,n),this.name=this.constructor.name,this.failures=()=>{var a;return null!=(a=i)?a:i=[e,...t()]}}}function jn(e){return"object"==typeof e&&null!=e}function Rn(e){return"string"==typeof e?JSON.stringify(e):""+e}function Un(e,t,i,a){if(!0===e)return;!1===e?e={}:"string"==typeof e&&(e={message:e});const{path:n,branch:o}=t,{type:s}=i,{refinement:r,message:l="Expected a value of type `"+s+"`"+(r?" with refinement `"+r+"`":"")+", but received: `"+Rn(a)+"`"}=e;return{value:a,type:s,refinement:r,key:n[n.length-1],path:n,branch:o,...e,message:l}}function*Hn(e,t,i,a){(function(e){return jn(e)&&"function"==typeof e[Symbol.iterator]})(e)||(e=[e]);for(const n of e){const e=Un(n,t,i,a);e&&(yield e)}}function*Gn(e,t,i){void 0===i&&(i={});const{path:a=[],branch:n=[e],coerce:o=!1,mask:s=!1}=i,r={path:a,branch:n};if(o&&(e=t.coercer(e,r),s&&"type"!==t.type&&jn(t.schema)&&jn(e)&&!Array.isArray(e)))for(const i in e)void 0===t.schema[i]&&delete e[i];let l=!0;for(const i of t.validator(e,r))l=!1,yield[i,void 0];for(let[i,d,c]of t.entries(e,r)){const t=Gn(d,c,{path:void 0===i?a:[...a,i],branch:void 0===i?n:[...n,d],coerce:o,mask:s});for(const a of t)a[0]?(l=!1,yield[a[0],void 0]):o&&(d=a[1],void 0===i?e=d:e instanceof Map?e.set(i,d):e instanceof Set?e.add(d):jn(e)&&(e[i]=d))}if(l)for(const i of t.refiner(e,r))l=!1,yield[i,void 0];l&&(yield[void 0,e])}class Wn{constructor(e){this.TYPE=void 0,this.type=void 0,this.schema=void 0,this.coercer=void 0,this.validator=void 0,this.refiner=void 0,this.entries=void 0;const{type:t,schema:i,validator:a,refiner:n,coercer:o=(e=>e),entries:s=function*(){}}=e;this.type=t,this.schema=i,this.entries=s,this.coercer=o,this.validator=a?(e,t)=>Hn(a(e,t),t,this,e):()=>[],this.refiner=n?(e,t)=>Hn(n(e,t),t,this,e):()=>[]}assert(e){return Kn(e,this)}create(e){return function(e,t){const i=Zn(e,t,{coerce:!0});if(i[0])throw i[0];return i[1]}(e,this)}is(e){return Yn(e,this)}mask(e){return function(e,t){const i=Zn(e,t,{coerce:!0,mask:!0});if(i[0])throw i[0];return i[1]}(e,this)}validate(e,t){return void 0===t&&(t={}),Zn(e,this,t)}}function Kn(e,t){const i=Zn(e,t);if(i[0])throw i[0]}function Yn(e,t){return!Zn(e,t)[0]}function Zn(e,t,i){void 0===i&&(i={});const a=Gn(e,t,i),n=function(e){const{done:t,value:i}=e.next();return t?void 0:i}(a);if(n[0]){const e=new qn(n[0],(function*(){for(const e of a)e[0]&&(yield e[0])}));return[e,void 0]}return[void 0,n[1]]}function Qn(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];const a="type"===t[0].type,n=t.map((e=>e.schema)),o=Object.assign({},...n);return a?ro(o):no(o)}function Jn(e,t){return new Wn({type:e,schema:null,validator:t})}function Xn(){return Jn("any",(()=>!0))}function eo(e){return new Wn({type:"array",schema:e,*entries(t){if(e&&Array.isArray(t))for(const[i,a]of t.entries())yield[i,a,e]},coercer:e=>Array.isArray(e)?e.slice():e,validator:e=>Array.isArray(e)||"Expected an array value, but received: "+Rn(e)})}function to(){return Jn("boolean",(e=>"boolean"==typeof e))}function io(e){const t=Rn(e),i=typeof e;return new Wn({type:"literal",schema:"string"===i||"number"===i||"boolean"===i?e:null,validator:i=>i===e||"Expected the literal `"+t+"`, but received: "+Rn(i)})}function ao(){return Jn("number",(e=>"number"==typeof e&&!isNaN(e)||"Expected a number, but received: "+Rn(e)))}function no(e){const t=e?Object.keys(e):[],i=Jn("never",(()=>!1));return new Wn({type:"object",schema:e||null,*entries(a){if(e&&jn(a)){const n=new Set(Object.keys(a));for(const i of t)n.delete(i),yield[i,a[i],e[i]];for(const e of n)yield[e,a[e],i]}},validator:e=>jn(e)||"Expected an object, but received: "+Rn(e),coercer:e=>jn(e)?{...e}:e})}function oo(e){return new Wn({...e,validator:(t,i)=>void 0===t||e.validator(t,i),refiner:(t,i)=>void 0===t||e.refiner(t,i)})}function so(){return Jn("string",(e=>"string"==typeof e||"Expected a string, but received: "+Rn(e)))}function ro(e){const t=Object.keys(e);return new Wn({type:"type",schema:e,*entries(i){if(jn(i))for(const a of t)yield[a,i[a],e[a]]},validator:e=>jn(e)||"Expected an object, but received: "+Rn(e)})}function lo(e){const t=e.map((e=>e.type)).join(" | ");return new Wn({type:"union",schema:null,coercer(t,i){const a=e.find((e=>{const[i]=e.validate(t,{coerce:!0});return!i}))||Jn("unknown",(()=>!0));return a.coercer(t,i)},validator(i,a){const n=[];for(const t of e){const[...e]=Gn(i,t,a),[o]=e;if(!o[0])return[];for(const[t]of e)t&&n.push(t)}return["Expected the value to satisfy a union of `"+t+"`, but received: "+Rn(i),...n]}})}const co=(e,t)=>{if(!(t instanceof qn))return{warnings:[t.message],errors:void 0};const i=[],a=[];for(const n of t.failures())if(void 0===n.value)i.push(e.localize("ui.errors.config.key_missing","key",n.path.join(".")));else if("never"===n.type)a.push(e.localize("ui.errors.config.key_not_expected","key",n.path.join(".")));else{if("union"===n.type)continue;"enums"===n.type?a.push(e.localize("ui.errors.config.key_wrong_type","key",n.path.join("."),"type_correct",n.message.replace("Expected ","").split(", ")[0],"type_wrong",JSON.stringify(n.value))):a.push(e.localize("ui.errors.config.key_wrong_type","key",n.path.join("."),"type_correct",n.refinement||n.type,"type_wrong",JSON.stringify(n.value)))}return{warnings:a,errors:i}},uo=(e,t)=>e.callWS({type:"validate_config",...t}),ho=e=>e.substr(e.indexOf(".")+1),po=no({alias:oo(so()),enabled:oo(to())}),vo=no({entity_id:oo(lo([so(),eo(so())])),device_id:oo(lo([so(),eo(so())])),area_id:oo(lo([so(),eo(so())]))});Qn(po,no({service:oo(so()),service_template:oo(so()),entity_id:oo(so()),target:oo(vo),data:oo(no())}));const mo=Qn(po,no({service:io("media_player.play_media"),target:oo(no({entity_id:oo(so())})),entity_id:oo(so()),data:no({media_content_id:so(),media_content_type:so()}),metadata:no()})),fo=Qn(po,no({service:io("scene.turn_on"),target:oo(no({entity_id:oo(so())})),entity_id:oo(so()),metadata:no()})),go=e=>{if("delay"in e)return"delay";if("wait_template"in e)return"wait_template";if(["condition","and","or","not"].some((t=>t in e)))return"check_condition";if("event"in e)return"fire_event";if("device_id"in e)return"device_action";if("scene"in e)return"activate_scene";if("repeat"in e)return"repeat";if("choose"in e)return"choose";if("if"in e)return"if";if("wait_for_trigger"in e)return"wait_for_trigger";if("variables"in e)return"variables";if("stop"in e)return"stop";if("parallel"in e)return"parallel";if("service"in e){if("metadata"in e){if(Yn(e,fo))return"activate_scene";if(Yn(e,mo))return"play_media"}return"service"}return"unknown"},_o=e=>e<10?`0${e}`:e;function yo(e){const t=Math.floor(e/3600),i=Math.floor(e%3600/60),a=Math.floor(e%3600%60);return t>0?`${t}:${_o(i)}:${_o(a)}`:i>0?`${i}:${_o(a)}`:a>0?""+a:null}function ko(e){return void 0===e||Array.isArray(e)?e:[e]}const bo=e=>{return t=e.entity_id,void 0===(i=e.attributes).friendly_name?ho(t).replace(/_/g," "):i.friendly_name||"";var t,i},xo=new RegExp("{%|{{"),$o=e=>xo.test(e),wo=e=>{if(!e)return!1;if("string"==typeof e)return $o(e);if("object"==typeof e){return(Array.isArray(e)?e:Object.values(e)).some((e=>e&&wo(e)))}return!1};var Co=/-u(?:-[0-9a-z]{2,8})+/gi;function Ao(e,t,i){if(void 0===i&&(i=Error),!e)throw new i(t)}function Io(e,t){for(var i=t;;){if(e.has(i))return i;var a=i.lastIndexOf("-");if(!~a)return;a>=2&&"-"===i[a-2]&&(a-=2),i=i.slice(0,a)}}function Eo(e,t){Ao(2===t.length,"key must have 2 elements");var i=e.length,a="-".concat(t,"-"),n=e.indexOf(a);if(-1!==n){for(var o=n+4,s=o,r=o,l=!1;!l;){var d=e.indexOf("-",r);2===(-1===d?i-r:d-r)?l=!0:-1===d?(s=i,l=!0):(s=d,r=d+1)}return e.slice(o,s)}if(a="-".concat(t),-1!==(n=e.indexOf(a))&&n+3===i)return""}function zo(e,t,i,a,n,o){var s;s="lookup"===i.localeMatcher?function(e,t,i){for(var a={locale:""},n=0,o=t;n<o.length;n++){var s=o[n],r=s.replace(Co,""),l=Io(e,r);if(l)return a.locale=l,s!==r&&(a.extension=s.slice(r.length+1,s.length)),a}return a.locale=i(),a}(e,t,o):function(e,t,i){var a,n={},o={},s={},r=new Set;e.forEach((function(e){var t=new Intl.Locale(e).minimize().toString(),i=Intl.getCanonicalLocales(e)[0]||e;n[t]=e,o[e]=e,s[i]=e,r.add(t),r.add(e),r.add(i)}));for(var l=0,d=t;l<d.length;l++){var c=d[l];if(a)break;var u=c.replace(Co,"");if(e.has(u)){a=u;break}if(r.has(u)){a=u;break}var h=new Intl.Locale(u),p=h.maximize().toString(),v=h.minimize().toString();if(r.has(v)){a=v;break}a=Io(r,p)}return a?{locale:o[a]||s[a]||n[a]||a}:{locale:i()}}(e,t,o);for(var r=s.locale,l={locale:"",dataLocale:r},d="-u",c=0,u=a;c<u.length;c++){var h=u[c];Ao(r in n,"Missing locale data for ".concat(r));var p=n[r];Ao("object"==typeof p&&null!==p,"locale data ".concat(h," must be an object"));var v=p[h];Ao(Array.isArray(v),"keyLocaleData for ".concat(h," must be an array"));var m=v[0];Ao("string"==typeof m||null===m,"value must be string or null but got ".concat(typeof m," in key ").concat(h));var f="";if(s.extension){var g=Eo(s.extension,h);void 0!==g&&(""!==g?~v.indexOf(g)&&(m=g,f="-".concat(h,"-").concat(m)):~g.indexOf("true")&&(m="true",f="-".concat(h)))}if(h in i){var _=i[h];Ao("string"==typeof _||null==_,"optionsValue must be String, Undefined or Null"),~v.indexOf(_)&&_!==m&&(m=_,f="")}l[h]=m,d+=f}if(d.length>2){var y=r.indexOf("-x-");if(-1===y)r+=d;else{var k=r.slice(0,y),b=r.slice(y,r.length);r=k+d+b}r=Intl.getCanonicalLocales(r)[0]}return l.locale=r,l}function So(e,t,i,a){var n=t.reduce((function(e,t){return e.add(t),e}),new Set);return zo(n,function(e){return Intl.getCanonicalLocales(e)}(e),{localeMatcher:(null==a?void 0:a.algorithm)||"best fit"},[],{},(function(){return i})).locale}var To=Object.freeze({__proto__:null,match:So,LookupSupportedLocales:function(e,t){for(var i=[],a=0,n=t;a<n.length;a++){var o=Io(e,n[a].replace(Co,""));o&&i.push(o)}return i},ResolveLocale:zo}),Lo=["af","ak","am","an","ar","ars","as","asa","ast","az","bal","be","bem","bez","bg","bho","bm","bn","bo","br","brx","bs","ca","ce","ceb","cgg","chr","ckb","cs","cy","da","de","doi","dsb","dv","dz","ee","el","en","eo","es","et","eu","fa","ff","fi","fil","fo","fr","fur","fy","ga","gd","gl","gsw","gu","guw","gv","ha","haw","he","hi","hnj","hr","hsb","hu","hy","ia","id","ig","ii","io","is","it","iu","ja","jbo","jgo","jmc","jv","jw","ka","kab","kaj","kcg","kde","kea","kk","kkj","kl","km","kn","ko","ks","ksb","ksh","ku","kw","ky","lag","lb","lg","lij","lkt","ln","lo","lt","lv","mas","mg","mgo","mk","ml","mn","mo","mr","ms","mt","my","nah","naq","nb","nd","ne","nl","nn","nnh","no","nqo","nr","nso","ny","nyn","om","or","os","osa","pa","pap","pcm","pl","prg","ps","pt-PT","pt","rm","ro","rof","ru","rwk","sah","saq","sat","sc","scn","sd","sdh","se","seh","ses","sg","sh","shi","si","sk","sl","sma","smi","smj","smn","sms","sn","so","sq","sr","ss","ssy","st","su","sv","sw","syr","ta","te","teo","th","ti","tig","tk","tl","tn","to","tpi","tr","ts","tzm","ug","uk","und","ur","uz","ve","vi","vo","vun","wa","wae","wo","xh","xog","yi","yo","yue","zh","zu"];var Oo=bn((function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.CanonicalizeLocaleList=void 0,t.CanonicalizeLocaleList=function(e){return Intl.getCanonicalLocales(e)}}));xn(Oo),Oo.CanonicalizeLocaleList;var Mo=bn((function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.invariant=t.UNICODE_EXTENSION_SEQUENCE_REGEX=void 0,t.UNICODE_EXTENSION_SEQUENCE_REGEX=/-u(?:-[0-9a-z]{2,8})+/gi,t.invariant=function(e,t,i){if(void 0===i&&(i=Error),!e)throw new i(t)}}));xn(Mo),Mo.invariant,Mo.UNICODE_EXTENSION_SEQUENCE_REGEX;var Po=bn((function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.BestAvailableLocale=void 0,t.BestAvailableLocale=function(e,t){for(var i=t;;){if(e.has(i))return i;var a=i.lastIndexOf("-");if(!~a)return;a>=2&&"-"===i[a-2]&&(a-=2),i=i.slice(0,a)}}}));xn(Po),Po.BestAvailableLocale;var Fo=bn((function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.LookupMatcher=void 0,t.LookupMatcher=function(e,t,i){for(var a={locale:""},n=0,o=t;n<o.length;n++){var s=o[n],r=s.replace(Mo.UNICODE_EXTENSION_SEQUENCE_REGEX,""),l=(0,Po.BestAvailableLocale)(e,r);if(l)return a.locale=l,s!==r&&(a.extension=s.slice(r.length+1,s.length)),a}return a.locale=i(),a}}));xn(Fo),Fo.LookupMatcher;var Do=bn((function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.BestFitMatcher=void 0,t.BestFitMatcher=function(e,t,i){var a,n={},o={},s={},r=new Set;e.forEach((function(e){var t=new Intl.Locale(e).minimize().toString(),i=Intl.getCanonicalLocales(e)[0]||e;n[t]=e,o[e]=e,s[i]=e,r.add(t),r.add(e),r.add(i)}));for(var l=0,d=t;l<d.length;l++){var c=d[l];if(a)break;var u=c.replace(Mo.UNICODE_EXTENSION_SEQUENCE_REGEX,"");if(e.has(u)){a=u;break}if(r.has(u)){a=u;break}var h=new Intl.Locale(u),p=h.maximize().toString(),v=h.minimize().toString();if(r.has(v)){a=v;break}a=(0,Po.BestAvailableLocale)(r,p)}return a?{locale:o[a]||s[a]||n[a]||a}:{locale:i()}}}));xn(Do),Do.BestFitMatcher;var Bo=bn((function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.UnicodeExtensionValue=void 0,t.UnicodeExtensionValue=function(e,t){(0,Mo.invariant)(2===t.length,"key must have 2 elements");var i=e.length,a="-".concat(t,"-"),n=e.indexOf(a);if(-1!==n){for(var o=n+4,s=o,r=o,l=!1;!l;){var d=e.indexOf("-",r);2===(-1===d?i-r:d-r)?l=!0:-1===d?(s=i,l=!0):(s=d,r=d+1)}return e.slice(o,s)}if(a="-".concat(t),-1!==(n=e.indexOf(a))&&n+3===i)return""}}));xn(Bo),Bo.UnicodeExtensionValue;var No=bn((function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.ResolveLocale=void 0,t.ResolveLocale=function(e,t,i,a,n,o){for(var s,r=(s="lookup"===i.localeMatcher?(0,Fo.LookupMatcher)(e,t,o):(0,Do.BestFitMatcher)(e,t,o)).locale,l={locale:"",dataLocale:r},d="-u",c=0,u=a;c<u.length;c++){var h=u[c];(0,Mo.invariant)(r in n,"Missing locale data for ".concat(r));var p=n[r];(0,Mo.invariant)("object"==typeof p&&null!==p,"locale data ".concat(h," must be an object"));var v=p[h];(0,Mo.invariant)(Array.isArray(v),"keyLocaleData for ".concat(h," must be an array"));var m=v[0];(0,Mo.invariant)("string"==typeof m||null===m,"value must be string or null but got ".concat(typeof m," in key ").concat(h));var f="";if(s.extension){var g=(0,Bo.UnicodeExtensionValue)(s.extension,h);void 0!==g&&(""!==g?~v.indexOf(g)&&(m=g,f="-".concat(h,"-").concat(m)):~g.indexOf("true")&&(m="true",f="-".concat(h)))}if(h in i){var _=i[h];(0,Mo.invariant)("string"==typeof _||null==_,"optionsValue must be String, Undefined or Null"),~v.indexOf(_)&&_!==m&&(m=_,f="")}l[h]=m,d+=f}if(d.length>2){var y=r.indexOf("-x-");if(-1===y)r+=d;else{var k=r.slice(0,y),b=r.slice(y,r.length);r=k+d+b}r=Intl.getCanonicalLocales(r)[0]}return l.locale=r,l}}));xn(No),No.ResolveLocale;var Vo=bn((function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.LookupSupportedLocales=void 0,t.LookupSupportedLocales=function(e,t){for(var i=[],a=0,n=t;a<n.length;a++){var o=n[a].replace(Mo.UNICODE_EXTENSION_SEQUENCE_REGEX,""),s=(0,Po.BestAvailableLocale)(e,o);s&&i.push(s)}return i}}));xn(Vo),Vo.LookupSupportedLocales;var qo=bn((function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.ResolveLocale=t.LookupSupportedLocales=t.match=void 0,t.match=function(e,t,i,a){var n=t.reduce((function(e,t){return e.add(t),e}),new Set);return(0,No.ResolveLocale)(n,(0,Oo.CanonicalizeLocaleList)(e),{localeMatcher:(null==a?void 0:a.algorithm)||"best fit"},[],{},(function(){return i})).locale},Object.defineProperty(t,"LookupSupportedLocales",{enumerable:!0,get:function(){return Vo.LookupSupportedLocales}});var i=No;Object.defineProperty(t,"ResolveLocale",{enumerable:!0,get:function(){return i.ResolveLocale}})}));xn(qo);var jo=qo.ResolveLocale,Ro=qo.LookupSupportedLocales,Uo=qo.match,Ho=["af-NA","af","agq","ak","am","ar-AE","ar-BH","ar-DJ","ar-DZ","ar-EG","ar-EH","ar-ER","ar-IL","ar-IQ","ar-JO","ar-KM","ar-KW","ar-LB","ar-LY","ar-MA","ar-MR","ar-OM","ar-PS","ar-QA","ar-SA","ar-SD","ar-SO","ar-SS","ar-SY","ar-TD","ar-TN","ar-YE","ar","as","asa","ast","az-Cyrl","az-Latn","az","bas","be-tarask","be","bem","bez","bg","bm","bn-IN","bn","bo-IN","bo","br","brx","bs-Cyrl","bs-Latn","bs","ca-AD","ca-ES-valencia","ca-FR","ca-IT","ca","ccp-IN","ccp","ce","ceb","cgg","chr","ckb-IR","ckb","cs","cy","da-GL","da","dav","de-AT","de-BE","de-CH","de-IT","de-LI","de-LU","de","dje","doi","dsb","dua","dyo","dz","ebu","ee-TG","ee","el-CY","el","en-001","en-150","en-AE","en-AG","en-AI","en-AS","en-AT","en-AU","en-BB","en-BE","en-BI","en-BM","en-BS","en-BW","en-BZ","en-CA","en-CC","en-CH","en-CK","en-CM","en-CX","en-CY","en-DE","en-DG","en-DK","en-DM","en-ER","en-FI","en-FJ","en-FK","en-FM","en-GB","en-GD","en-GG","en-GH","en-GI","en-GM","en-GU","en-GY","en-HK","en-IE","en-IL","en-IM","en-IN","en-IO","en-JE","en-JM","en-KE","en-KI","en-KN","en-KY","en-LC","en-LR","en-LS","en-MG","en-MH","en-MO","en-MP","en-MS","en-MT","en-MU","en-MW","en-MY","en-NA","en-NF","en-NG","en-NL","en-NR","en-NU","en-NZ","en-PG","en-PH","en-PK","en-PN","en-PR","en-PW","en-RW","en-SB","en-SC","en-SD","en-SE","en-SG","en-SH","en-SI","en-SL","en-SS","en-SX","en-SZ","en-TC","en-TK","en-TO","en-TT","en-TV","en-TZ","en-UG","en-UM","en-VC","en-VG","en-VI","en-VU","en-WS","en-ZA","en-ZM","en-ZW","en","eo","es-419","es-AR","es-BO","es-BR","es-BZ","es-CL","es-CO","es-CR","es-CU","es-DO","es-EA","es-EC","es-GQ","es-GT","es-HN","es-IC","es-MX","es-NI","es-PA","es-PE","es-PH","es-PR","es-PY","es-SV","es-US","es-UY","es-VE","es","et","eu","ewo","fa-AF","fa","ff-Adlm-BF","ff-Adlm-CM","ff-Adlm-GH","ff-Adlm-GM","ff-Adlm-GW","ff-Adlm-LR","ff-Adlm-MR","ff-Adlm-NE","ff-Adlm-NG","ff-Adlm-SL","ff-Adlm-SN","ff-Adlm","ff-Latn-BF","ff-Latn-CM","ff-Latn-GH","ff-Latn-GM","ff-Latn-GN","ff-Latn-GW","ff-Latn-LR","ff-Latn-MR","ff-Latn-NE","ff-Latn-NG","ff-Latn-SL","ff-Latn","ff","fi","fil","fo-DK","fo","fr-BE","fr-BF","fr-BI","fr-BJ","fr-BL","fr-CA","fr-CD","fr-CF","fr-CG","fr-CH","fr-CI","fr-CM","fr-DJ","fr-DZ","fr-GA","fr-GF","fr-GN","fr-GP","fr-GQ","fr-HT","fr-KM","fr-LU","fr-MA","fr-MC","fr-MF","fr-MG","fr-ML","fr-MQ","fr-MR","fr-MU","fr-NC","fr-NE","fr-PF","fr-PM","fr-RE","fr-RW","fr-SC","fr-SN","fr-SY","fr-TD","fr-TG","fr-TN","fr-VU","fr-WF","fr-YT","fr","fur","fy","ga-GB","ga","gd","gl","gsw-FR","gsw-LI","gsw","gu","guz","gv","ha-GH","ha-NE","ha","haw","he","hi","hr-BA","hr","hsb","hu","hy","ia","id","ig","ii","is","it-CH","it-SM","it-VA","it","ja","jgo","jmc","jv","ka","kab","kam","kde","kea","kgp","khq","ki","kk","kkj","kl","kln","km","kn","ko-KP","ko","kok","ks-Arab","ks","ksb","ksf","ksh","ku","kw","ky","lag","lb","lg","lkt","ln-AO","ln-CF","ln-CG","ln","lo","lrc-IQ","lrc","lt","lu","luo","luy","lv","mai","mas-TZ","mas","mer","mfe","mg","mgh","mgo","mi","mk","ml","mn","mni-Beng","mni","mr","ms-BN","ms-ID","ms-SG","ms","mt","mua","my","mzn","naq","nb-SJ","nb","nd","nds-NL","nds","ne-IN","ne","nl-AW","nl-BE","nl-BQ","nl-CW","nl-SR","nl-SX","nl","nmg","nn","nnh","no","nus","nyn","om-KE","om","or","os-RU","os","pa-Arab","pa-Guru","pa","pcm","pl","ps-PK","ps","pt-AO","pt-CH","pt-CV","pt-GQ","pt-GW","pt-LU","pt-MO","pt-MZ","pt-PT","pt-ST","pt-TL","pt","qu-BO","qu-EC","qu","rm","rn","ro-MD","ro","rof","ru-BY","ru-KG","ru-KZ","ru-MD","ru-UA","ru","rw","rwk","sa","sah","saq","sat-Olck","sat","sbp","sc","sd-Arab","sd-Deva","sd","se-FI","se-SE","se","seh","ses","sg","shi-Latn","shi-Tfng","shi","si","sk","sl","smn","sn","so-DJ","so-ET","so-KE","so","sq-MK","sq-XK","sq","sr-Cyrl-BA","sr-Cyrl-ME","sr-Cyrl-XK","sr-Cyrl","sr-Latn-BA","sr-Latn-ME","sr-Latn-XK","sr-Latn","sr","su-Latn","su","sv-AX","sv-FI","sv","sw-CD","sw-KE","sw-UG","sw","ta-LK","ta-MY","ta-SG","ta","te","teo-KE","teo","tg","th","ti-ER","ti","tk","to","tr-CY","tr","tt","twq","tzm","ug","uk","und","ur-IN","ur","uz-Arab","uz-Cyrl","uz-Latn","uz","vai-Latn","vai-Vaii","vai","vi","vun","wae","wo","xh","xog","yav","yi","yo-BJ","yo","yrl-CO","yrl-VE","yrl","yue-Hans","yue-Hant","yue","zgh","zh-Hans-HK","zh-Hans-MO","zh-Hans-SG","zh-Hans","zh-Hant-HK","zh-Hant-MO","zh-Hant","zh","zu"];var Go=["af-NA","af","agq","ak","am","ar-AE","ar-BH","ar-DJ","ar-DZ","ar-EG","ar-EH","ar-ER","ar-IL","ar-IQ","ar-JO","ar-KM","ar-KW","ar-LB","ar-LY","ar-MA","ar-MR","ar-OM","ar-PS","ar-QA","ar-SA","ar-SD","ar-SO","ar-SS","ar-SY","ar-TD","ar-TN","ar-YE","ar","as","asa","ast","az-Cyrl","az-Latn","az","bas","be-tarask","be","bem","bez","bg","bm","bn-IN","bn","bo-IN","bo","br","brx","bs-Cyrl","bs-Latn","bs","ca-AD","ca-ES-valencia","ca-FR","ca-IT","ca","ccp-IN","ccp","ce","ceb","cgg","chr","ckb-IR","ckb","cs","cy","da-GL","da","dav","de-AT","de-BE","de-CH","de-IT","de-LI","de-LU","de","dje","doi","dsb","dua","dyo","dz","ebu","ee-TG","ee","el-CY","el","en-001","en-150","en-AE","en-AG","en-AI","en-AS","en-AT","en-AU","en-BB","en-BE","en-BI","en-BM","en-BS","en-BW","en-BZ","en-CA","en-CC","en-CH","en-CK","en-CM","en-CX","en-CY","en-DE","en-DG","en-DK","en-DM","en-ER","en-FI","en-FJ","en-FK","en-FM","en-GB","en-GD","en-GG","en-GH","en-GI","en-GM","en-GU","en-GY","en-HK","en-IE","en-IL","en-IM","en-IN","en-IO","en-JE","en-JM","en-KE","en-KI","en-KN","en-KY","en-LC","en-LR","en-LS","en-MG","en-MH","en-MO","en-MP","en-MS","en-MT","en-MU","en-MW","en-MY","en-NA","en-NF","en-NG","en-NL","en-NR","en-NU","en-NZ","en-PG","en-PH","en-PK","en-PN","en-PR","en-PW","en-RW","en-SB","en-SC","en-SD","en-SE","en-SG","en-SH","en-SI","en-SL","en-SS","en-SX","en-SZ","en-TC","en-TK","en-TO","en-TT","en-TV","en-TZ","en-UG","en-UM","en-VC","en-VG","en-VI","en-VU","en-WS","en-ZA","en-ZM","en-ZW","en","eo","es-419","es-AR","es-BO","es-BR","es-BZ","es-CL","es-CO","es-CR","es-CU","es-DO","es-EA","es-EC","es-GQ","es-GT","es-HN","es-IC","es-MX","es-NI","es-PA","es-PE","es-PH","es-PR","es-PY","es-SV","es-US","es-UY","es-VE","es","et","eu","ewo","fa-AF","fa","ff-Adlm-BF","ff-Adlm-CM","ff-Adlm-GH","ff-Adlm-GM","ff-Adlm-GW","ff-Adlm-LR","ff-Adlm-MR","ff-Adlm-NE","ff-Adlm-NG","ff-Adlm-SL","ff-Adlm-SN","ff-Adlm","ff-Latn-BF","ff-Latn-CM","ff-Latn-GH","ff-Latn-GM","ff-Latn-GN","ff-Latn-GW","ff-Latn-LR","ff-Latn-MR","ff-Latn-NE","ff-Latn-NG","ff-Latn-SL","ff-Latn","ff","fi","fil","fo-DK","fo","fr-BE","fr-BF","fr-BI","fr-BJ","fr-BL","fr-CA","fr-CD","fr-CF","fr-CG","fr-CH","fr-CI","fr-CM","fr-DJ","fr-DZ","fr-GA","fr-GF","fr-GN","fr-GP","fr-GQ","fr-HT","fr-KM","fr-LU","fr-MA","fr-MC","fr-MF","fr-MG","fr-ML","fr-MQ","fr-MR","fr-MU","fr-NC","fr-NE","fr-PF","fr-PM","fr-RE","fr-RW","fr-SC","fr-SN","fr-SY","fr-TD","fr-TG","fr-TN","fr-VU","fr-WF","fr-YT","fr","fur","fy","ga-GB","ga","gd","gl","gsw-FR","gsw-LI","gsw","gu","guz","gv","ha-GH","ha-NE","ha","haw","he","hi","hr-BA","hr","hsb","hu","hy","ia","id","ig","ii","is","it-CH","it-SM","it-VA","it","ja","jgo","jmc","jv","ka","kab","kam","kde","kea","kgp","khq","ki","kk","kkj","kl","kln","km","kn","ko-KP","ko","kok","ks-Arab","ks","ksb","ksf","ksh","ku","kw","ky","lag","lb","lg","lkt","ln-AO","ln-CF","ln-CG","ln","lo","lrc-IQ","lrc","lt","lu","luo","luy","lv","mai","mas-TZ","mas","mer","mfe","mg","mgh","mgo","mi","mk","ml","mn","mni-Beng","mni","mr","ms-BN","ms-ID","ms-SG","ms","mt","mua","my","mzn","naq","nb-SJ","nb","nd","nds-NL","nds","ne-IN","ne","nl-AW","nl-BE","nl-BQ","nl-CW","nl-SR","nl-SX","nl","nmg","nn","nnh","no","nus","nyn","om-KE","om","or","os-RU","os","pa-Arab","pa-Guru","pa","pcm","pl","ps-PK","ps","pt-AO","pt-CH","pt-CV","pt-GQ","pt-GW","pt-LU","pt-MO","pt-MZ","pt-PT","pt-ST","pt-TL","pt","qu-BO","qu-EC","qu","rm","rn","ro-MD","ro","rof","ru-BY","ru-KG","ru-KZ","ru-MD","ru-UA","ru","rw","rwk","sa","sah","saq","sat-Olck","sat","sbp","sc","sd-Arab","sd-Deva","sd","se-FI","se-SE","se","seh","ses","sg","shi-Latn","shi-Tfng","shi","si","sk","sl","smn","sn","so-DJ","so-ET","so-KE","so","sq-MK","sq-XK","sq","sr-Cyrl-BA","sr-Cyrl-ME","sr-Cyrl-XK","sr-Cyrl","sr-Latn-BA","sr-Latn-ME","sr-Latn-XK","sr-Latn","sr","su-Latn","su","sv-AX","sv-FI","sv","sw-CD","sw-KE","sw-UG","sw","ta-LK","ta-MY","ta-SG","ta","te","teo-KE","teo","tg","th","ti-ER","ti","tk","to","tr-CY","tr","tt","twq","tzm","ug","uk","und","ur-IN","ur","uz-Arab","uz-Cyrl","uz-Latn","uz","vai-Latn","vai-Vaii","vai","vi","vun","wae","wo","xh","xog","yav","yi","yo-BJ","yo","yrl-CO","yrl-VE","yrl","yue-Hans","yue-Hant","yue","zgh","zh-Hans-HK","zh-Hans-MO","zh-Hans-SG","zh-Hans","zh-Hant-HK","zh-Hant-MO","zh-Hant","zh","zu"];let Wo,Ko;!function(e){e.language="language",e.system="system",e.comma_decimal="comma_decimal",e.decimal_comma="decimal_comma",e.space_comma="space_comma",e.none="none"}(Wo||(Wo={})),function(e){e.language="language",e.system="system",e.am_pm="12",e.twenty_four="24"}(Ko||(Ko={}));const Yo={},Zo=window.localStorage||{},Qo={"zh-cn":"zh-Hans","zh-sg":"zh-Hans","zh-my":"zh-Hans","zh-tw":"zh-Hant","zh-hk":"zh-Hant","zh-mo":"zh-Hant",zh:"zh-Hant"};function Jo(e){if(e in Yo.translations)return e;const t=e.toLowerCase();if(t in Qo)return Qo[t];const i=Object.keys(Yo.translations).find((e=>e.toLowerCase()===t));return i||(e.includes("-")?Jo(e.split("-")[0]):void 0)}const Xo=new Set,es=[];"Locale"in Intl&&!function(){try{return"x-private"===new Intl.Locale("und-x-private").toString()}catch(e){return!0}}()||es.push(import("./c.8de55195.js")),function(e){if(void 0===e&&(e="en"),!("PluralRules"in Intl)||"one"===new Intl.PluralRules("en",{minimumFractionDigits:2}).select(1)||!function(e){if(!e)return!0;var t=Array.isArray(e)?e:[e];return Intl.PluralRules.supportedLocalesOf(t).length===t.length}(e))return e?So([e],Lo,"en"):void 0}()&&(es.push(import("./c.568c70d8.js")),es.push(import("./c.e23b0d0b.js"))),function(e){if(void 0===e&&(e="en"),!("RelativeTimeFormat"in Intl)||!function(e){if(!e)return!0;var t=Array.isArray(e)?e:[e];return Intl.RelativeTimeFormat.supportedLocalesOf(t).length===t.length}(e)||!function(e){try{return"numberingSystem"in new Intl.RelativeTimeFormat(e||"en",{numeric:"auto"}).resolvedOptions()}catch(e){return!1}}(e))return Uo([e],Ho,"en")}()&&es.push(import("./c.4c04acb5.js")),function(e){if(void 0===e&&(e="en"),!("DateTimeFormat"in Intl)||!("formatToParts"in Intl.DateTimeFormat.prototype)||!("formatRange"in Intl.DateTimeFormat.prototype)||function(){try{return"dayPeriod"!==new Intl.DateTimeFormat("en",{hourCycle:"h11",hour:"numeric"}).formatToParts(0)[2].type}catch(e){return!1}}()||function(){try{return!!new Intl.DateTimeFormat("en",{dateStyle:"short",hour:"numeric"}).format(new Date(0))}catch(e){return!1}}()||!function(){try{return!!new Intl.DateTimeFormat(void 0,{dateStyle:"short"}).resolvedOptions().dateStyle}catch(e){return!1}}()||!function(e){if(!e)return!0;var t=Array.isArray(e)?e:[e];return Intl.DateTimeFormat.supportedLocalesOf(t).length===t.length}(e))return e?Uo([e],Go,"en"):void 0}()&&(es.push(import("./c.456b65b4.js")),es.push(import("./c.ad739743.js")));const ts=0===es.length?void 0:Promise.all(es).then((()=>is(function(){let e=null;if(Zo.selectedLanguage)try{const t=JSON.parse(Zo.selectedLanguage);if(t&&(e=Jo(t),e))return e}catch(e){}if(navigator.languages)for(const t of navigator.languages)if(e=Jo(t),e)return e;return e=Jo(navigator.language),e||"en"}()))),is=async e=>{if(!Xo.has(e)){Xo.add(e);try{if(Intl.NumberFormat&&"function"==typeof Intl.NumberFormat.__addLocaleData){const t=await fetch(`/static/locale-data/intl-numberformat/${e}.json`);Intl.NumberFormat.__addLocaleData(await t.json())}if(Intl.RelativeTimeFormat&&"function"==typeof Intl.RelativeTimeFormat.__addLocaleData){const t=await fetch(`/static/locale-data/intl-relativetimeformat/${e}.json`);Intl.RelativeTimeFormat.__addLocaleData(await t.json())}if(Intl.DateTimeFormat&&"function"==typeof Intl.DateTimeFormat.__addLocaleData){const t=await fetch(`/static/locale-data/intl-datetimeformat/${e}.json`);Intl.DateTimeFormat.__addLocaleData(await t.json())}}catch(e){}}};ts&&await ts,n((e=>new Intl.DateTimeFormat(e.language,{weekday:"long",month:"long",day:"numeric"})));const as=(e,t)=>ns(t).format(e),ns=n((e=>new Intl.DateTimeFormat(e.language,{year:"numeric",month:"long",day:"numeric"}))),os=n((e=>new Intl.DateTimeFormat(e.language,{year:"numeric",month:"numeric",day:"numeric"})));n((e=>new Intl.DateTimeFormat(e.language,{day:"numeric",month:"short"}))),n((e=>new Intl.DateTimeFormat(e.language,{month:"long",year:"numeric"}))),n((e=>new Intl.DateTimeFormat(e.language,{month:"long"}))),n((e=>new Intl.DateTimeFormat(e.language,{year:"numeric"})));const ss=n((e=>{if(e.time_format===Ko.language||e.time_format===Ko.system){const t=e.time_format===Ko.language?e.language:void 0,i=(new Date).toLocaleString(t);return i.includes("AM")||i.includes("PM")}return e.time_format===Ko.am_pm}));ts&&await ts;const rs=(e,t)=>ls(t).format(e),ls=n((e=>new Intl.DateTimeFormat("en"!==e.language||ss(e)?e.language:"en-u-hc-h23",{year:"numeric",month:"long",day:"numeric",hour:ss(e)?"numeric":"2-digit",minute:"2-digit",hour12:ss(e)})));n((e=>new Intl.DateTimeFormat("en"!==e.language||ss(e)?e.language:"en-u-hc-h23",{month:"short",day:"numeric",hour:ss(e)?"numeric":"2-digit",minute:"2-digit",hour12:ss(e)}))),n((e=>new Intl.DateTimeFormat("en"!==e.language||ss(e)?e.language:"en-u-hc-h23",{year:"numeric",month:"long",day:"numeric",hour:ss(e)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hour12:ss(e)}))),n((e=>new Intl.DateTimeFormat("en"!==e.language||ss(e)?e.language:"en-u-hc-h23",{year:"numeric",month:"numeric",day:"numeric",hour:"numeric",minute:"2-digit",hour12:ss(e)})));const ds=(e,t,i)=>{const a=t?(e=>{switch(e.number_format){case Wo.comma_decimal:return["en-US","en"];case Wo.decimal_comma:return["de","es","it"];case Wo.space_comma:return["fr","sv","cs"];case Wo.system:return;default:return e.language}})(t):void 0;if(Number.isNaN=Number.isNaN||function e(t){return"number"==typeof t&&e(t)},(null==t?void 0:t.number_format)!==Wo.none&&!Number.isNaN(Number(e))&&Intl)try{return new Intl.NumberFormat(a,cs(e,i)).format(Number(e))}catch(t){return console.error(t),new Intl.NumberFormat(void 0,cs(e,i)).format(Number(e))}return"string"==typeof e?e:`${((e,t=2)=>Math.round(e*10**t)/10**t)(e,null==i?void 0:i.maximumFractionDigits).toString()}${"currency"===(null==i?void 0:i.style)?` ${i.currency}`:""}`},cs=(e,t)=>{const i={maximumFractionDigits:2,...t};if("string"!=typeof e)return i;if(!t||!t.minimumFractionDigits&&!t.maximumFractionDigits){const t=e.indexOf(".")>-1?e.split(".")[1].length:0;i.minimumFractionDigits=t,i.maximumFractionDigits=t}return i},us=e=>e.charAt(0).toUpperCase()+e.slice(1);function hs(e){return e=e.replace(/_/g," ").replace(/\bid\b/g,"ID").replace(/\bip\b/g,"IP").replace(/\bmac\b/g,"MAC").replace(/\bgps\b/g,"GPS"),us(e)}const ps=(e,t,i=!1)=>{if(e.alias&&!i)return e.alias;if("event"===e.platform&&e.event_type){let t="";if(Array.isArray(e.event_type))for(const[i,a]of e.event_type.entries())t+=`${i>0?",":""} ${e.event_type.length>1&&i===e.event_type.length-1?"or":""} ${a}`;else t=e.event_type.toString();return`When ${t} event is fired`}if("homeassistant"===e.platform&&e.event)return"When Home Assistant is "+("start"===e.event?"started":"shutdown");if("numeric_state"===e.platform&&e.entity_id){let i="When";const a=t.states[e.entity_id],n=a?bo(a):e.entity_id;return e.attribute&&(i+=` ${hs(e.attribute)} from`),i+=` ${n} is`,"above"in e&&(i+=` above ${e.above}`),"below"in e&&"above"in e&&(i+=" and"),"below"in e&&(i+=` below ${e.below}`),i}if("state"===e.platform&&e.entity_id){let i="When",a="";const n=t.states;if(e.attribute&&(i+=` ${hs(e.attribute)} from`),Array.isArray(e.entity_id))for(const[t,i]of e.entity_id.entries())n[i]&&(a+=`${t>0?",":""} ${e.entity_id.length>1&&t===e.entity_id.length-1?"or":""} ${bo(n[i])||i}`);else a=n[e.entity_id]?bo(n[e.entity_id]):e.entity_id;if(i+=` ${a} changes`,e.from){let t="";if(Array.isArray(e.from))for(const[i,a]of e.from.entries())t+=`${i>0?",":""} ${e.from.length>1&&i===e.from.length-1?"or":""} ${a}`;else t=e.from.toString();i+=` from ${t}`}if(e.to){let t="";if(Array.isArray(e.to))for(const[i,a]of e.to.entries())t+=`${i>0?",":""} ${e.to.length>1&&i===e.to.length-1?"or":""} ${a}`;else e.to&&(t=e.to.toString());i+=` to ${t}`}if("for"in e){let t;t="number"==typeof e.for?`for ${yo(e.for)}`:"string"==typeof e.for?`for ${e.for}`:`for ${JSON.stringify(e.for)}`,i+=` for ${t}`}return i}if("sun"===e.platform&&e.event){let t="When the sun "+("sunset"===e.event?"sets":"rises");if(e.offset){let i="";e.offset&&(i="number"==typeof e.offset?` offset by ${yo(e.offset)}`:"string"==typeof e.offset?` offset by ${e.offset}`:` offset by ${JSON.stringify(e.offset)}`),t+=i}return t}if("tag"===e.platform)return"When a tag is scanned";if("time"===e.platform&&e.at){return`When the time is equal to ${e.at.includes(".")&&t.states[e.at]||e.at}`}if("time_pattern"===e.platform)return"Time pattern trigger";if("zone"===e.platform&&e.entity_id&&e.zone){let i="",a="",n=!1;const o=t.states;if(Array.isArray(e.entity_id))for(const[t,a]of e.entity_id.entries())o[a]&&(i+=`${t>0?",":""} ${e.entity_id.length>1&&t===e.entity_id.length-1?"or":""} ${bo(o[a])||a}`);else i=o[e.entity_id]?bo(o[e.entity_id]):e.entity_id;if(Array.isArray(e.zone)){e.zone.length>1&&(n=!0);for(const[t,i]of e.zone.entries())o[i]&&(a+=`${t>0?",":""} ${e.zone.length>1&&t===e.zone.length-1?"or":""} ${bo(o[i])||i}`)}else a=o[e.zone]?bo(o[e.zone]):e.zone;return`When ${i} ${e.event}s ${a} ${n?"zones":"zone"}`}if("geo_location"===e.platform&&e.source&&e.zone){let i="",a="",n=!1;const o=t.states;if(Array.isArray(e.source))for(const[t,a]of e.source.entries())i+=`${t>0?",":""} ${e.source.length>1&&t===e.source.length-1?"or":""} ${a}`;else i=e.source;if(Array.isArray(e.zone)){e.zone.length>1&&(n=!0);for(const[t,i]of e.zone.entries())o[i]&&(a+=`${t>0?",":""} ${e.zone.length>1&&t===e.zone.length-1?"or":""} ${bo(o[i])||i}`)}else a=o[e.zone]?bo(o[e.zone]):e.zone;return`When ${i} ${e.event}s ${a} ${n?"zones":"zone"}`}return"mqtt"===e.platform?"When a MQTT payload has been received":"template"===e.platform?"When a template triggers":"webhook"===e.platform?"When a Webhook payload has been received":`${e.platform||"Unknown"} trigger`},vs=(e,t,i=!1)=>{if(e.alias&&!i)return e.alias;if(["or","and","not"].includes(e.condition))return`multiple conditions using "${e.condition}"`;if("state"===e.condition&&e.entity_id){let i="Confirm";const a=t.states[e.entity_id],n=a?bo(a):e.entity_id;"attribute"in e&&(i+=` ${e.attribute} from`);let o="";if(Array.isArray(e.state))for(const[t,i]of e.state.entries())o+=`${t>0?",":""} ${e.state.length>1&&t===e.state.length-1?"or":""} ${i}`;else o=e.state.toString();if(i+=` ${n} is ${o}`,"for"in e){let t;t="number"==typeof e.for?`for ${yo(e.for)}`:"string"==typeof e.for?`for ${e.for}`:`for ${JSON.stringify(e.for)}`,i+=` for ${t}`}return i}if("numeric_state"===e.condition&&e.entity_id){let i="Confirm";const a=t.states[e.entity_id],n=a?bo(a):e.entity_id;return"attribute"in e&&(i+=` ${e.attribute} from`),i+=` ${n} is`,"above"in e&&(i+=` above ${e.above}`),"below"in e&&"above"in e&&(i+=" and"),"below"in e&&(i+=` below ${e.below}`),i}if("sun"===e.condition&&("before"in e||"after"in e)){let t="Confirm";if(!e.after&&!e.before)return t+=" sun",t;if(t+=" sun",e.after){let i="";e.after_offset&&(i="number"==typeof e.after_offset?` offset by ${yo(e.after_offset)}`:"string"==typeof e.after_offset?` offset by ${e.after_offset}`:` offset by ${JSON.stringify(e.after_offset)}`),t+=` after ${e.after}${i}`}return e.before&&(t+=` before ${e.before}`),t}if("zone"===e.condition&&e.entity_id&&e.zone){let i="",a=!1,n="",o=!1;const s=t.states;if(Array.isArray(e.entity_id)){e.entity_id.length>1&&(a=!0);for(const[t,a]of e.entity_id.entries())s[a]&&(i+=`${t>0?",":""} ${e.entity_id.length>1&&t===e.entity_id.length-1?"or":""} ${bo(s[a])||a}`)}else i=s[e.entity_id]?bo(s[e.entity_id]):e.entity_id;if(Array.isArray(e.zone)){e.zone.length>1&&(o=!0);for(const[t,i]of e.zone.entries())s[i]&&(n+=`${t>0?",":""} ${e.zone.length>1&&t===e.zone.length-1?"or":""} ${bo(s[i])||i}`)}else n=s[e.zone]?bo(s[e.zone]):e.zone;return`Confirm ${i} ${a?"are":"is"} in ${n} ${o?"zones":"zone"}`}return`${e.condition} condition`},ms=(e,t,i,a=!1)=>{if(t.alias&&!a)return t.alias;if(i||(i=go(t)),"service"===i){const e=t;let a;if(e.service_template||e.service&&$o(e.service))a="Call a service based on a template";else{if(!e.service)return i;a=`Call service ${e.service}`}if(e.target){const t=[];for(const[i,a]of Object.entries({area_id:"areas",device_id:"devices",entity_id:"entities"})){if(!(i in e.target))continue;const n=Array.isArray(e.target[i])?e.target[i]:[e.target[i]],o=[];let s=!0;for(const e of n){if($o(e)){t.push(`templated ${a}`),s=!1;break}o.push(e)}s&&t.push(`${a} ${o.join(", ")}`)}t.length>0&&(a+=` on ${t.join(", ")}`)}return a}if("delay"===i){const e=t;let i;return i="number"==typeof e.delay?`for ${yo(e.delay)}`:"string"==typeof e.delay?$o(e.delay)?"based on a template":`for ${e.delay}`:`for ${JSON.stringify(e.delay)}`,`Delay ${i}`}if("activate_scene"===i){var n;const i=t;let a;var o;if("scene"in i)a=i.scene;else a=(null===(o=i.target)||void 0===o?void 0:o.entity_id)||i.entity_id;const s=a?e.states[a]:void 0;return`Activate scene ${s?bo(s):"scene"in i?i.scene:(null===(n=i.target)||void 0===n?void 0:n.entity_id)||i.entity_id||""}`}if("play_media"===i){var s,r;const i=t,a=(null===(s=i.target)||void 0===s?void 0:s.entity_id)||i.entity_id,n=a?e.states[a]:void 0;return`Play ${i.metadata.title||i.data.media_content_id} on ${n?bo(n):(null===(r=i.target)||void 0===r?void 0:r.entity_id)||i.entity_id}`}if("wait_for_trigger"===i){return`Wait for ${ko(t.wait_for_trigger).map((t=>ps(t,e))).join(", ")}`}if("variables"===i){const e=t;return`Define variables ${Object.keys(e.variables).join(", ")}`}if("fire_event"===i){const e=t;return $o(e.event)?"Fire event based on a template":`Fire event ${e.event}`}if("wait_template"===i)return"Wait for a template to render true";if("check_condition"===i)return`Test ${vs(t,e)}`;if("stop"===i){const e=t;return"Stopped"+(e.stop?` because: ${e.stop}`:"")}if("if"===i){const i=t;return`If ${"string"==typeof i.if?i.if:ko(i.if).map((t=>vs(t,e))).join(", ")} then ${ko(i.then).map((t=>ms(e,t)))}${i.else?` else ${ko(i.else).map((t=>ms(e,t)))}`:""}`}if("choose"===i){const i=t;return i.choose?`If ${ko(i.choose).map((t=>`${"string"==typeof t.conditions?t.conditions:ko(t.conditions).map((t=>vs(t,e))).join(", ")} then ${ko(t.sequence).map((t=>ms(e,t))).join(", ")}`)).join(", else if ")}${i.default?`. If none match: ${ko(i.default).map((t=>ms(e,t))).join(", ")}`:""}`:"Choose"}if("repeat"===i){const i=t;return`Repeat ${ko(i.repeat.sequence).map((t=>ms(e,t)))} ${"count"in i.repeat?`${i.repeat.count} times`:""}${"while"in i.repeat?`while ${ko(i.repeat.while).map((t=>vs(t,e))).join(", ")} is true`:"until"in i.repeat?`until ${ko(i.repeat.until).map((t=>vs(t,e))).join(", ")} is true`:"for_each"in i.repeat?`for every item: ${ko(i.repeat.for_each).map((e=>JSON.stringify(e))).join(", ")}`:""}`}if("check_condition"===i)return`Test ${vs(t,e)}`;if("device_action"===i){const i=t,a=e.states[i.entity_id];return`${i.type||"Perform action with"} ${a?bo(a):i.entity_id}`}if("parallel"===i){return`Run in parallel: ${ko(t.parallel).map((t=>ms(e,t))).join(", ")}`}return i},fs=(e,t)=>o(e,"hass-notification",t),gs=e=>e.substr(0,e.indexOf(".")),_s=(e,t)=>e<t?-1:e>t?1:0,ys=(e,t)=>_s(e.toLowerCase(),t.toLowerCase());class ks extends HTMLElement{static get version(){return"23.1.6"}}customElements.define("vaadin-material-styles",ks);const bs=e=>class extends e{static get properties(){return{theme:{type:String,reflectToAttribute:!0,observer:"__deprecatedThemePropertyChanged"},_theme:{type:String,readOnly:!0}}}__deprecatedThemePropertyChanged(e){this._set_theme(e)}},xs=[];function $s(e,t,i={}){var a;e&&(a=e,Es(customElements.get(a))&&console.warn(`The custom element definition for "${e}"\n      was finalized before a style module was registered.\n      Make sure to add component specific style modules before\n      importing the corresponding custom element.`)),t=function(e=[]){return[e].flat(1/0).filter((e=>e instanceof s||(console.warn("An item in styles is not of type CSSResult. Use `unsafeCSS` or `css`."),!1)))}(t),window.Vaadin&&window.Vaadin.styleModules?window.Vaadin.styleModules.registerStyles(e,t,i):xs.push({themeFor:e,styles:t,include:i.include,moduleId:i.moduleId})}function ws(){return window.Vaadin&&window.Vaadin.styleModules?window.Vaadin.styleModules.getAllThemes():xs}function Cs(e=""){let t=0;return 0===e.indexOf("lumo-")||0===e.indexOf("material-")?t=1:0===e.indexOf("vaadin-")&&(t=2),t}function As(e){const t=[];return e.include&&[].concat(e.include).forEach((e=>{const i=ws().find((t=>t.moduleId===e));i?t.push(...As(i),...i.styles):console.warn(`Included moduleId ${e} not found in style registry`)}),e.styles),t}function Is(e){const t=`${e}-default-theme`,i=ws().filter((i=>i.moduleId!==t&&function(e,t){return(e||"").split(" ").some((e=>new RegExp(`^${e.split("*").join(".*")}$`).test(t)))}(i.themeFor,e))).map((e=>({...e,styles:[...As(e),...e.styles],includePriority:Cs(e.moduleId)}))).sort(((e,t)=>t.includePriority-e.includePriority));return i.length>0?i:ws().filter((e=>e.moduleId===t))}function Es(e){return e&&Object.prototype.hasOwnProperty.call(e,"__themes")}const zs=e=>class extends(bs(e)){static finalize(){if(super.finalize(),this.elementStyles)return;const e=this.prototype._template;e&&!Es(this)&&function(e,t){const i=document.createElement("style");i.innerHTML=e.map((e=>e.cssText)).join("\n"),t.content.appendChild(i)}(this.getStylesForThis(),e)}static finalizeStyles(e){const t=this.getStylesForThis();return e?[...super.finalizeStyles(e),...t]:t}static getStylesForThis(){const e=Object.getPrototypeOf(this.prototype),t=(e?e.constructor.__themes:[])||[];this.__themes=[...t,...Is(this.is)];const i=this.__themes.flatMap((e=>e.styles));return i.filter(((e,t)=>t===i.lastIndexOf(e)))}};$s("",r`
  :host {
    /* Text colors */
    --material-body-text-color: var(--light-theme-text-color, rgba(0, 0, 0, 0.87));
    --material-secondary-text-color: var(--light-theme-secondary-color, rgba(0, 0, 0, 0.54));
    --material-disabled-text-color: var(--light-theme-disabled-color, rgba(0, 0, 0, 0.38));

    /* Primary colors */
    --material-primary-color: var(--primary-color, #6200ee);
    --material-primary-contrast-color: var(--dark-theme-base-color, #fff);
    --material-primary-text-color: var(--material-primary-color);

    /* Error colors */
    --material-error-color: var(--error-color, #b00020);
    --material-error-text-color: var(--material-error-color);

    /* Background colors */
    --material-background-color: var(--light-theme-background-color, #fff);
    --material-secondary-background-color: var(--light-theme-secondary-background-color, #f5f5f5);
    --material-disabled-color: rgba(0, 0, 0, 0.26);

    /* Divider colors */
    --material-divider-color: rgba(0, 0, 0, 0.12);

    /* Undocumented internal properties (prefixed with three dashes) */

    /* Text field tweaks */
    --_material-text-field-input-line-background-color: initial;
    --_material-text-field-input-line-opacity: initial;
    --_material-text-field-input-line-hover-opacity: initial;
    --_material-text-field-focused-label-opacity: initial;

    /* Button tweaks */
    --_material-button-raised-background-color: initial;
    --_material-button-outline-color: initial;

    /* Grid tweaks */
    --_material-grid-row-hover-background-color: initial;

    /* Split layout tweaks */
    --_material-split-layout-splitter-background-color: initial;

    background-color: var(--material-background-color);
    color: var(--material-body-text-color);
  }

  [theme~='dark'] {
    /* Text colors */
    --material-body-text-color: var(--dark-theme-text-color, rgba(255, 255, 255, 1));
    --material-secondary-text-color: var(--dark-theme-secondary-color, rgba(255, 255, 255, 0.7));
    --material-disabled-text-color: var(--dark-theme-disabled-color, rgba(255, 255, 255, 0.5));

    /* Primary colors */
    --material-primary-color: var(--light-primary-color, #7e3ff2);
    --material-primary-text-color: #b794f6;

    /* Error colors */
    --material-error-color: var(--error-color, #de2839);
    --material-error-text-color: var(--material-error-color);

    /* Background colors */
    --material-background-color: var(--dark-theme-background-color, #303030);
    --material-secondary-background-color: var(--dark-theme-secondary-background-color, #3b3b3b);
    --material-disabled-color: rgba(255, 255, 255, 0.3);

    /* Divider colors */
    --material-divider-color: rgba(255, 255, 255, 0.12);

    /* Undocumented internal properties (prefixed with three dashes) */

    /* Text field tweaks */
    --_material-text-field-input-line-background-color: #fff;
    --_material-text-field-input-line-opacity: 0.7;
    --_material-text-field-input-line-hover-opacity: 1;
    --_material-text-field-focused-label-opacity: 1;

    /* Button tweaks */
    --_material-button-raised-background-color: rgba(255, 255, 255, 0.08);
    --_material-button-outline-color: rgba(255, 255, 255, 0.2);

    /* Grid tweaks */
    --_material-grid-row-hover-background-color: rgba(255, 255, 255, 0.08);
    --_material-grid-row-selected-overlay-opacity: 0.16;

    /* Split layout tweaks */
    --_material-split-layout-splitter-background-color: rgba(255, 255, 255, 0.8);

    background-color: var(--material-background-color);
    color: var(--material-body-text-color);
  }

  a {
    color: inherit;
  }
`,{moduleId:"material-color-light"});$s("",r`
  :host {
    /* Text colors */
    --material-body-text-color: var(--dark-theme-text-color, rgba(255, 255, 255, 1));
    --material-secondary-text-color: var(--dark-theme-secondary-color, rgba(255, 255, 255, 0.7));
    --material-disabled-text-color: var(--dark-theme-disabled-color, rgba(255, 255, 255, 0.5));

    /* Primary colors */
    --material-primary-color: var(--light-primary-color, #7e3ff2);
    --material-primary-text-color: #b794f6;

    /* Error colors */
    --material-error-color: var(--error-color, #de2839);
    --material-error-text-color: var(--material-error-color);

    /* Background colors */
    --material-background-color: var(--dark-theme-background-color, #303030);
    --material-secondary-background-color: var(--dark-theme-secondary-background-color, #3b3b3b);
    --material-disabled-color: rgba(255, 255, 255, 0.3);

    /* Divider colors */
    --material-divider-color: rgba(255, 255, 255, 0.12);

    /* Undocumented internal properties (prefixed with three dashes) */

    /* Text field tweaks */
    --_material-text-field-input-line-background-color: #fff;
    --_material-text-field-input-line-opacity: 0.7;
    --_material-text-field-input-line-hover-opacity: 1;
    --_material-text-field-focused-label-opacity: 1;

    /* Button tweaks */
    --_material-button-raised-background-color: rgba(255, 255, 255, 0.08);
    --_material-button-outline-color: rgba(255, 255, 255, 0.2);

    /* Grid tweaks */
    --_material-grid-row-hover-background-color: rgba(255, 255, 255, 0.08);
    --_material-grid-row-selected-overlay-opacity: 0.16;

    /* Split layout tweaks */
    --_material-split-layout-splitter-background-color: rgba(255, 255, 255, 0.8);

    background-color: var(--material-background-color);
    color: var(--material-body-text-color);
  }
`,{moduleId:"material-color-dark"});const Ss=r`
  :host {
    /* Text colors */
    --material-body-text-color: var(--light-theme-text-color, rgba(0, 0, 0, 0.87));
    --material-secondary-text-color: var(--light-theme-secondary-color, rgba(0, 0, 0, 0.54));
    --material-disabled-text-color: var(--light-theme-disabled-color, rgba(0, 0, 0, 0.38));

    /* Primary colors */
    --material-primary-color: var(--primary-color, #6200ee);
    --material-primary-contrast-color: var(--dark-theme-base-color, #fff);
    --material-primary-text-color: var(--material-primary-color);

    /* Error colors */
    --material-error-color: var(--error-color, #b00020);
    --material-error-text-color: var(--material-error-color);

    /* Background colors */
    --material-background-color: var(--light-theme-background-color, #fff);
    --material-secondary-background-color: var(--light-theme-secondary-background-color, #f5f5f5);
    --material-disabled-color: rgba(0, 0, 0, 0.26);

    /* Divider colors */
    --material-divider-color: rgba(0, 0, 0, 0.12);
  }
`,Ts=document.createElement("template");Ts.innerHTML=`<style>${Ss.toString().replace(":host","html")}</style>`,document.head.appendChild(Ts.content);const Ls=r`
  :host {
    /* Font family */
    --material-font-family: 'Roboto', sans-serif;

    /* Font sizes */
    --material-h1-font-size: 6rem;
    --material-h2-font-size: 3.75rem;
    --material-h3-font-size: 3rem;
    --material-h4-font-size: 2.125rem;
    --material-h5-font-size: 1.5rem;
    --material-h6-font-size: 1.25rem;
    --material-body-font-size: 1rem;
    --material-small-font-size: 0.875rem;
    --material-button-font-size: 0.875rem;
    --material-caption-font-size: 0.75rem;

    /* Icon size */
    --material-icon-font-size: 20px;
  }
`;$s("",r`
  body,
  :host {
    font-family: var(--material-font-family);
    font-size: var(--material-body-font-size);
    line-height: 1.4;
    -webkit-text-size-adjust: 100%;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    color: inherit;
    line-height: 1.1;
    margin-top: 1.5em;
  }

  h1 {
    font-size: var(--material-h3-font-size);
    font-weight: 300;
    letter-spacing: -0.015em;
    margin-bottom: 1em;
    text-indent: -0.07em;
  }

  h2 {
    font-size: var(--material-h4-font-size);
    font-weight: 300;
    letter-spacing: -0.01em;
    margin-bottom: 0.75em;
    text-indent: -0.07em;
  }

  h3 {
    font-size: var(--material-h5-font-size);
    font-weight: 400;
    margin-bottom: 0.75em;
    text-indent: -0.05em;
  }

  h4 {
    font-size: var(--material-h6-font-size);
    font-weight: 400;
    letter-spacing: 0.01em;
    margin-bottom: 0.75em;
    text-indent: -0.05em;
  }

  h5 {
    font-size: var(--material-body-font-size);
    font-weight: 500;
    margin-bottom: 0.5em;
    text-indent: -0.025em;
  }

  h6 {
    font-size: var(--material-small-font-size);
    font-weight: 500;
    letter-spacing: 0.01em;
    margin-bottom: 0.25em;
    text-indent: -0.025em;
  }

  a,
  b,
  strong {
    font-weight: 500;
  }
`,{moduleId:"material-typography"});const Os=document.createElement("template");if(Os.innerHTML=`<style>${Ls.toString().replace(":host","html")}</style>`,document.head.appendChild(Os.content),!window.polymerSkipLoadingFontRoboto){const e="https://fonts.googleapis.com/css?family=Roboto+Mono:400,700|Roboto:400,300,300italic,400italic,500,500italic,700,700italic",t=document.createElement("link");t.rel="stylesheet",t.type="text/css",t.crossOrigin="anonymous",t.href=e,document.head.appendChild(t)}const Ms=r`
  /* prettier-ignore */
  :host {
    /* from http://codepen.io/shyndman/pen/c5394ddf2e8b2a5c9185904b57421cdb */
    --material-shadow-elevation-2dp: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12), 0 3px 1px -2px rgba(0, 0, 0, 0.2);
    --material-shadow-elevation-3dp: 0 3px 4px 0 rgba(0, 0, 0, 0.14), 0 1px 8px 0 rgba(0, 0, 0, 0.12), 0 3px 3px -2px rgba(0, 0, 0, 0.4);
    --material-shadow-elevation-4dp: 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 1px 10px 0 rgba(0, 0, 0, 0.12), 0 2px 4px -1px rgba(0, 0, 0, 0.4);
    --material-shadow-elevation-6dp: 0 6px 10px 0 rgba(0, 0, 0, 0.14), 0 1px 18px 0 rgba(0, 0, 0, 0.12), 0 3px 5px -1px rgba(0, 0, 0, 0.4);
    --material-shadow-elevation-8dp: 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12), 0 5px 5px -3px rgba(0, 0, 0, 0.4);
    --material-shadow-elevation-12dp: 0 12px 16px 1px rgba(0, 0, 0, 0.14), 0 4px 22px 3px rgba(0, 0, 0, 0.12), 0 6px 7px -4px rgba(0, 0, 0, 0.4);
    --material-shadow-elevation-16dp: 0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.4);
    --material-shadow-elevation-24dp: 0 24px 38px 3px rgba(0, 0, 0, 0.14), 0 9px 46px 8px rgba(0, 0, 0, 0.12), 0 11px 15px -7px rgba(0, 0, 0, 0.4);
  }
`,Ps=document.createElement("template");Ps.innerHTML=`<style>${Ms.toString().replace(":host","html")}</style>`,document.head.appendChild(Ps.content);const Fs=r`
  :host {
    top: 16px;
    right: 16px;
    /* TODO (@jouni): remove unnecessary multiplication after https://github.com/vaadin/vaadin-overlay/issues/90 is fixed */
    bottom: calc(1px * var(--vaadin-overlay-viewport-bottom) + 16px);
    left: 16px;
  }

  [part='overlay'] {
    background-color: var(--material-background-color);
    border-radius: 4px;
    box-shadow: var(--material-shadow-elevation-4dp);
    color: var(--material-body-text-color);
    font-family: var(--material-font-family);
    font-size: var(--material-body-font-size);
    font-weight: 400;
  }

  [part='content'] {
    padding: 8px 0;
  }

  [part='backdrop'] {
    opacity: 0.2;
    animation: 0.2s vaadin-overlay-backdrop-enter;
    will-change: opacity;
  }

  @keyframes vaadin-overlay-backdrop-enter {
    0% {
      opacity: 0;
    }
  }
`;$s("",Fs,{moduleId:"material-overlay"}),$s("vaadin-overlay",Fs,{moduleId:"material-vaadin-overlay"});const Ds=e=>e.test(navigator.userAgent),Bs=e=>e.test(navigator.platform);Ds(/Android/),Ds(/Chrome/)&&/Google Inc/.test(navigator.vendor),Ds(/Firefox/);const Ns=Bs(/^iPad/)||Bs(/^Mac/)&&navigator.maxTouchPoints>1,Vs=Bs(/^iPhone/)||Ns,qs=Ds(/^((?!chrome|android).)*safari/i),js=(()=>{try{return document.createEvent("TouchEvent"),!0}catch(e){return!1}})(),Rs=l((e=>class extends e{constructor(){super(),this.__controllers=new Set}connectedCallback(){super.connectedCallback(),this.__controllers.forEach((e=>{e.hostConnected&&e.hostConnected()}))}disconnectedCallback(){super.disconnectedCallback(),this.__controllers.forEach((e=>{e.hostDisconnected&&e.hostDisconnected()}))}addController(e){this.__controllers.add(e),void 0!==this.$&&this.isConnected&&e.hostConnected&&e.hostConnected()}removeController(e){this.__controllers.delete(e)}}));class Us{static detectScrollType(){const e=document.createElement("div");e.textContent="ABCD",e.dir="rtl",e.style.fontSize="14px",e.style.width="4px",e.style.height="1px",e.style.position="absolute",e.style.top="-1000px",e.style.overflow="scroll",document.body.appendChild(e);let t="reverse";return e.scrollLeft>0?t="default":(e.scrollLeft=2,e.scrollLeft<2&&(t="negative")),document.body.removeChild(e),t}static getNormalizedScrollLeft(e,t,i){const{scrollLeft:a}=i;if("rtl"!==t||!e)return a;switch(e){case"negative":return i.scrollWidth-i.clientWidth+a;case"reverse":return i.scrollWidth-i.clientWidth-a;default:return a}}static setNormalizedScrollLeft(e,t,i,a){if("rtl"===t&&e)switch(e){case"negative":i.scrollLeft=i.clientWidth-i.scrollWidth+a;break;case"reverse":i.scrollLeft=i.scrollWidth-i.clientWidth-a;break;default:i.scrollLeft=a}else i.scrollLeft=a}}const Hs=[];let Gs;function Ws(e,t,i=e.getAttribute("dir")){t?e.setAttribute("dir",t):null!=i&&e.removeAttribute("dir")}function Ks(){return document.documentElement.getAttribute("dir")}new MutationObserver((function(){const e=Ks();Hs.forEach((t=>{Ws(t,e)}))})).observe(document.documentElement,{attributes:!0,attributeFilter:["dir"]});const Ys=e=>class extends e{static get properties(){return{dir:{type:String,value:"",reflectToAttribute:!0,converter:{fromAttribute:e=>e||"",toAttribute:e=>""===e?null:e}}}}static finalize(){super.finalize(),Gs||(Gs=Us.detectScrollType())}connectedCallback(){super.connectedCallback(),this.hasAttribute("dir")||(this.__subscribe(),Ws(this,Ks(),null))}attributeChangedCallback(e,t,i){if(super.attributeChangedCallback(e,t,i),"dir"!==e)return;const a=Ks(),n=i===a&&-1===Hs.indexOf(this),o=!i&&t&&-1===Hs.indexOf(this),s=i!==a&&t===a;n||o?(this.__subscribe(),Ws(this,a,i)):s&&this.__subscribe(!1)}disconnectedCallback(){super.disconnectedCallback(),this.__subscribe(!1),this.removeAttribute("dir")}_valueToNodeAttribute(e,t,i){("dir"!==i||""!==t||e.hasAttribute("dir"))&&super._valueToNodeAttribute(e,t,i)}_attributeToProperty(e,t,i){"dir"!==e||t?super._attributeToProperty(e,t,i):this.dir=""}__subscribe(e=!0){e?Hs.includes(this)||Hs.push(this):Hs.includes(this)&&Hs.splice(Hs.indexOf(this),1)}__getNormalizedScrollLeft(e){return Us.getNormalizedScrollLeft(Gs,this.getAttribute("dir")||"ltr",e)}__setNormalizedScrollLeft(e,t){return Us.setNormalizedScrollLeft(Gs,this.getAttribute("dir")||"ltr",e,t)}};function Zs(e,t){const i=Math.max(e.tabIndex,0),a=Math.max(t.tabIndex,0);return 0===i||0===a?a>i:i>a}function Qs(e){const t=e.length;if(t<2)return e;const i=Math.ceil(t/2);return function(e,t){const i=[];for(;e.length>0&&t.length>0;)Zs(e[0],t[0])?i.push(t.shift()):i.push(e.shift());return i.concat(e,t)}(Qs(e.slice(0,i)),Qs(e.slice(i)))}function Js(e,t){if(e.nodeType!==Node.ELEMENT_NODE||function(e){const t=e.style;if("hidden"===t.visibility||"none"===t.display)return!0;const i=window.getComputedStyle(e);return"hidden"===i.visibility||"none"===i.display}(e))return!1;const i=e,a=function(e){if(!function(e){return!e.matches('[tabindex="-1"]')&&(e.matches("input, select, textarea, button, object")?e.matches(":not([disabled])"):e.matches("a[href], area[href], iframe, [tabindex], [contentEditable]"))}(e))return-1;const t=e.getAttribute("tabindex")||0;return Number(t)}(i);let n=a>0;a>=0&&t.push(i);let o=[];return o="slot"===i.localName?i.assignedNodes({flatten:!0}):(i.shadowRoot||i).children,[...o].forEach((e=>{n=Js(e,t)||n})),n}function Xs(e){return e.getRootNode().activeElement===e}const er=[];class tr{constructor(e){this.host=e,this.__trapNode=null,this.__onKeyDown=this.__onKeyDown.bind(this)}hostConnected(){document.addEventListener("keydown",this.__onKeyDown)}hostDisconnected(){document.removeEventListener("keydown",this.__onKeyDown)}trapFocus(e){if(this.__trapNode=e,0===this.__focusableElements.length)throw this.__trapNode=null,new Error("The trap node should have at least one focusable descendant or be focusable itself.");er.push(this),-1===this.__focusedElementIndex&&this.__focusableElements[0].focus()}releaseFocus(){this.__trapNode=null,er.pop()}__onKeyDown(e){if(this.__trapNode&&this===Array.from(er).pop()&&"Tab"===e.key){e.preventDefault();const t=e.shiftKey;this.__focusNextElement(t)}}__focusNextElement(e=!1){const t=this.__focusableElements,i=e?-1:1,a=this.__focusedElementIndex,n=t[(t.length+a+i)%t.length];n.focus(),"input"===n.localName&&n.select()}get __focusableElements(){return function(e){const t=[];return Js(e,t)?Qs(t):t}(this.__trapNode)}get __focusedElementIndex(){const e=this.__focusableElements;return e.indexOf(e.filter(Xs).pop())}}class ir extends(zs(Ys(Rs(d)))){static get template(){return c`
      <style>
        :host {
          z-index: 200;
          position: fixed;

          /* Despite of what the names say, <vaadin-overlay> is just a container
          for position/sizing/alignment. The actual overlay is the overlay part. */

          /* Default position constraints: the entire viewport. Note: themes can
          override this to introduce gaps between the overlay and the viewport. */
          top: 0;
          right: 0;
          bottom: var(--vaadin-overlay-viewport-bottom);
          left: 0;

          /* Use flexbox alignment for the overlay part. */
          display: flex;
          flex-direction: column; /* makes dropdowns sizing easier */
          /* Align to center by default. */
          align-items: center;
          justify-content: center;

          /* Allow centering when max-width/max-height applies. */
          margin: auto;

          /* The host is not clickable, only the overlay part is. */
          pointer-events: none;

          /* Remove tap highlight on touch devices. */
          -webkit-tap-highlight-color: transparent;

          /* CSS API for host */
          --vaadin-overlay-viewport-bottom: 0;
        }

        :host([hidden]),
        :host(:not([opened]):not([closing])) {
          display: none !important;
        }

        [part='overlay'] {
          -webkit-overflow-scrolling: touch;
          overflow: auto;
          pointer-events: auto;

          /* Prevent overflowing the host in MSIE 11 */
          max-width: 100%;
          box-sizing: border-box;

          -webkit-tap-highlight-color: initial; /* reenable tap highlight inside */
        }

        [part='backdrop'] {
          z-index: -1;
          content: '';
          background: rgba(0, 0, 0, 0.5);
          position: fixed;
          top: 0;
          left: 0;
          bottom: 0;
          right: 0;
          pointer-events: auto;
        }
      </style>

      <div id="backdrop" part="backdrop" hidden$="[[!withBackdrop]]"></div>
      <div part="overlay" id="overlay" tabindex="0">
        <div part="content" id="content">
          <slot></slot>
        </div>
      </div>
    `}static get is(){return"vaadin-overlay"}static get properties(){return{opened:{type:Boolean,notify:!0,observer:"_openedChanged",reflectToAttribute:!0},owner:Element,renderer:Function,template:{type:Object,notify:!0},content:{type:Object,notify:!0},withBackdrop:{type:Boolean,value:!1,reflectToAttribute:!0},model:Object,modeless:{type:Boolean,value:!1,reflectToAttribute:!0,observer:"_modelessChanged"},hidden:{type:Boolean,reflectToAttribute:!0,observer:"_hiddenChanged"},focusTrap:{type:Boolean,value:!1},restoreFocusOnClose:{type:Boolean,value:!1},restoreFocusNode:{type:HTMLElement},_mouseDownInside:{type:Boolean},_mouseUpInside:{type:Boolean},_instance:{type:Object},_originalContentPart:Object,_contentNodes:Array,_oldOwner:Element,_oldModel:Object,_oldTemplate:Object,_oldRenderer:Object,_oldOpened:Boolean}}static get observers(){return["_templateOrRendererChanged(template, renderer, owner, model, opened)"]}constructor(){super(),this._boundMouseDownListener=this._mouseDownListener.bind(this),this._boundMouseUpListener=this._mouseUpListener.bind(this),this._boundOutsideClickListener=this._outsideClickListener.bind(this),this._boundKeydownListener=this._keydownListener.bind(this),this._observer=new u(this,(e=>{this._setTemplateFromNodes(e.addedNodes)})),this._boundIronOverlayCanceledListener=this._ironOverlayCanceled.bind(this),Vs&&(this._boundIosResizeListener=()=>this._detectIosNavbar()),this.__focusTrapController=new tr(this)}ready(){super.ready(),this._observer.flush(),this.addEventListener("click",(()=>{})),this.$.backdrop.addEventListener("click",(()=>{})),this.addController(this.__focusTrapController)}_detectIosNavbar(){if(!this.opened)return;const e=window.innerHeight,t=window.innerWidth>e,i=document.documentElement.clientHeight;t&&i>e?this.style.setProperty("--vaadin-overlay-viewport-bottom",i-e+"px"):this.style.setProperty("--vaadin-overlay-viewport-bottom","0")}_setTemplateFromNodes(e){this.template=e.filter((e=>e.localName&&"template"===e.localName))[0]||this.template}close(e){const t=new CustomEvent("vaadin-overlay-close",{bubbles:!0,cancelable:!0,detail:{sourceEvent:e}});this.dispatchEvent(t),t.defaultPrevented||(this.opened=!1)}connectedCallback(){super.connectedCallback(),this._boundIosResizeListener&&(this._detectIosNavbar(),window.addEventListener("resize",this._boundIosResizeListener))}disconnectedCallback(){super.disconnectedCallback(),this._boundIosResizeListener&&window.removeEventListener("resize",this._boundIosResizeListener)}requestContentUpdate(){this.renderer&&this.renderer.call(this.owner,this.content,this.owner,this.model)}_ironOverlayCanceled(e){e.preventDefault()}_mouseDownListener(e){this._mouseDownInside=e.composedPath().indexOf(this.$.overlay)>=0}_mouseUpListener(e){this._mouseUpInside=e.composedPath().indexOf(this.$.overlay)>=0}_outsideClickListener(e){if(e.composedPath().includes(this.$.overlay)||this._mouseDownInside||this._mouseUpInside)return this._mouseDownInside=!1,void(this._mouseUpInside=!1);if(!this._last)return;const t=new CustomEvent("vaadin-overlay-outside-click",{bubbles:!0,cancelable:!0,detail:{sourceEvent:e}});this.dispatchEvent(t),this.opened&&!t.defaultPrevented&&this.close(e)}_keydownListener(e){if(this._last&&(!this.modeless||e.composedPath().includes(this.$.overlay))&&"Escape"===e.key){const t=new CustomEvent("vaadin-overlay-escape-press",{bubbles:!0,cancelable:!0,detail:{sourceEvent:e}});this.dispatchEvent(t),this.opened&&!t.defaultPrevented&&this.close(e)}}_ensureTemplatized(){this._setTemplateFromNodes(Array.from(this.children))}_openedChanged(e,t){this._instance||this._ensureTemplatized(),e?(this.__restoreFocusNode=this._getActiveElement(),this._animatedOpening(),Dn(this,(()=>{this.focusTrap&&this.__focusTrapController.trapFocus(this.$.overlay);const e=new CustomEvent("vaadin-overlay-open",{bubbles:!0});this.dispatchEvent(e)})),document.addEventListener("keydown",this._boundKeydownListener),this.modeless||this._addGlobalListeners()):t&&(this.focusTrap&&this.__focusTrapController.releaseFocus(),this._animatedClosing(),document.removeEventListener("keydown",this._boundKeydownListener),this.modeless||this._removeGlobalListeners())}_hiddenChanged(e){e&&this.hasAttribute("closing")&&this._flushAnimation("closing")}_shouldAnimate(){const e=getComputedStyle(this).getPropertyValue("animation-name");return!("none"===getComputedStyle(this).getPropertyValue("display"))&&e&&"none"!==e}_enqueueAnimation(e,t){const i=`__${e}Handler`,a=e=>{e&&e.target!==this||(t(),this.removeEventListener("animationend",a),delete this[i])};this[i]=a,this.addEventListener("animationend",a)}_flushAnimation(e){const t=`__${e}Handler`;"function"==typeof this[t]&&this[t]()}_animatedOpening(){this.parentNode===document.body&&this.hasAttribute("closing")&&this._flushAnimation("closing"),this._attachOverlay(),this.modeless||this._enterModalState(),this.setAttribute("opening",""),this._shouldAnimate()?this._enqueueAnimation("opening",(()=>{this._finishOpening()})):this._finishOpening()}_attachOverlay(){this._placeholder=document.createComment("vaadin-overlay-placeholder"),this.parentNode.insertBefore(this._placeholder,this),document.body.appendChild(this),this.bringToFront()}_finishOpening(){document.addEventListener("iron-overlay-canceled",this._boundIronOverlayCanceledListener),this.removeAttribute("opening")}_finishClosing(){document.removeEventListener("iron-overlay-canceled",this._boundIronOverlayCanceledListener),this._detachOverlay(),this.$.overlay.style.removeProperty("pointer-events"),this.removeAttribute("closing")}_animatedClosing(){if(this.hasAttribute("opening")&&this._flushAnimation("opening"),this._placeholder){this._exitModalState();const e=this.restoreFocusNode||this.__restoreFocusNode;if(this.restoreFocusOnClose&&e){const t=this._getActiveElement();(t===document.body||this._deepContains(t))&&setTimeout((()=>e.focus())),this.__restoreFocusNode=null}this.setAttribute("closing",""),this.dispatchEvent(new CustomEvent("vaadin-overlay-closing")),this._shouldAnimate()?this._enqueueAnimation("closing",(()=>{this._finishClosing()})):this._finishClosing()}}_detachOverlay(){this._placeholder.parentNode.insertBefore(this,this._placeholder),this._placeholder.parentNode.removeChild(this._placeholder)}static get __attachedInstances(){return Array.from(document.body.children).filter((e=>e instanceof ir&&!e.hasAttribute("closing"))).sort(((e,t)=>e.__zIndex-t.__zIndex||0))}get _last(){return this===ir.__attachedInstances.pop()}_modelessChanged(e){e?(this._removeGlobalListeners(),this._exitModalState()):this.opened&&(this._addGlobalListeners(),this._enterModalState())}_addGlobalListeners(){document.addEventListener("mousedown",this._boundMouseDownListener),document.addEventListener("mouseup",this._boundMouseUpListener),document.documentElement.addEventListener("click",this._boundOutsideClickListener,!0)}_enterModalState(){"none"!==document.body.style.pointerEvents&&(this._previousDocumentPointerEvents=document.body.style.pointerEvents,document.body.style.pointerEvents="none"),ir.__attachedInstances.forEach((e=>{e!==this&&(e.shadowRoot.querySelector('[part="overlay"]').style.pointerEvents="none")}))}_removeGlobalListeners(){document.removeEventListener("mousedown",this._boundMouseDownListener),document.removeEventListener("mouseup",this._boundMouseUpListener),document.documentElement.removeEventListener("click",this._boundOutsideClickListener,!0)}_exitModalState(){void 0!==this._previousDocumentPointerEvents&&(document.body.style.pointerEvents=this._previousDocumentPointerEvents,delete this._previousDocumentPointerEvents);const e=ir.__attachedInstances;let t;for(;(t=e.pop())&&(t===this||(t.shadowRoot.querySelector('[part="overlay"]').style.removeProperty("pointer-events"),t.modeless)););}_removeOldContent(){this.content&&this._contentNodes&&(this._observer.disconnect(),this._contentNodes.forEach((e=>{e.parentNode===this.content&&this.content.removeChild(e)})),this._originalContentPart&&(this.$.content.parentNode.replaceChild(this._originalContentPart,this.$.content),this.$.content=this._originalContentPart,this._originalContentPart=void 0),this._observer.connect(),this._contentNodes=void 0,this.content=void 0)}_stampOverlayTemplate(e){this._removeOldContent(),e._Templatizer||(e._Templatizer=h(e,this,{forwardHostProp(e,t){this._instance&&this._instance.forwardHostProp(e,t)}})),this._instance=new e._Templatizer({}),this._contentNodes=Array.from(this._instance.root.childNodes);const t=e._templateRoot||(e._templateRoot=e.getRootNode());if(t!==document){this.$.content.shadowRoot||this.$.content.attachShadow({mode:"open"});let e=Array.from(t.querySelectorAll("style")).reduce(((e,t)=>e+t.textContent),"");if(e=e.replace(/:host/g,":host-nomatch"),e){const t=document.createElement("style");t.textContent=e,this.$.content.shadowRoot.appendChild(t),this._contentNodes.unshift(t)}this.$.content.shadowRoot.appendChild(this._instance.root),this.content=this.$.content.shadowRoot}else this.appendChild(this._instance.root),this.content=this}_removeNewRendererOrTemplate(e,t,i,a){e!==t?this.template=void 0:i!==a&&(this.renderer=void 0)}_templateOrRendererChanged(e,t,i,a,n){if(e&&t)throw this._removeNewRendererOrTemplate(e,this._oldTemplate,t,this._oldRenderer),new Error("You should only use either a renderer or a template for overlay content");const o=this._oldOwner!==i||this._oldModel!==a;this._oldModel=a,this._oldOwner=i;const s=this._oldTemplate!==e;this._oldTemplate=e;const r=this._oldRenderer!==t;this._oldRenderer=t;const l=this._oldOpened!==n;this._oldOpened=n,r&&(this.content=this,this.content.innerHTML="",delete this.content._$litPart$),e&&s?this._stampOverlayTemplate(e):t&&(r||l||o)&&n&&this.requestContentUpdate()}_getActiveElement(){let e=document.activeElement||document.body;for(;e.shadowRoot&&e.shadowRoot.activeElement;)e=e.shadowRoot.activeElement;return e}_deepContains(e){if(this.contains(e))return!0;let t=e;const i=e.ownerDocument;for(;t&&t!==i&&t!==this;)t=t.parentNode||t.host;return t===this}bringToFront(){let e="";const t=ir.__attachedInstances.filter((e=>e!==this)).pop();if(t){e=t.__zIndex+1}this.style.zIndex=e,this.__zIndex=e||parseFloat(getComputedStyle(this).zIndex)}}customElements.define(ir.is,ir);const ar=Fs;$s("",ar,{moduleId:"material-menu-overlay"});$s("vaadin-combo-box-overlay",[ar,r`
  :host {
    --_vaadin-combo-box-items-container-border-width: 8px 0;
    --_vaadin-combo-box-items-container-border-style: solid;
    --_vaadin-combo-box-items-container-border-color: transparent;
  }

  [part='overlay'] {
    position: relative;
    overflow: visible;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }

  [part='content'] {
    padding: 0;
  }

  :host([loading]) [part='loader'] {
    height: 2px;
    position: absolute;
    z-index: 1;
    top: -2px;
    left: 0;
    right: 0;
    background: var(--material-background-color)
      linear-gradient(
        90deg,
        transparent 0%,
        transparent 20%,
        var(--material-primary-color) 20%,
        var(--material-primary-color) 40%,
        transparent 40%,
        transparent 60%,
        var(--material-primary-color) 60%,
        var(--material-primary-color) 80%,
        transparent 80%,
        transparent 100%
      )
      0 0 / 400% 100% repeat-x;
    opacity: 0;
    animation: 3s linear infinite material-combo-box-loader-progress, 0.3s 0.1s both material-combo-box-loader-fade-in;
  }

  [part='loader']::before {
    content: '';
    display: block;
    height: 100%;
    opacity: 0.16;
    background: var(--material-primary-color);
  }

  @keyframes material-combo-box-loader-fade-in {
    0% {
      opacity: 0;
    }

    100% {
      opacity: 1;
    }
  }

  @keyframes material-combo-box-loader-progress {
    0% {
      background-position: 0 0;
      background-size: 300% 100%;
    }

    33% {
      background-position: -100% 0;
      background-size: 400% 100%;
    }

    67% {
      background-position: -200% 0;
      background-size: 250% 100%;
    }

    100% {
      background-position: -300% 0;
      background-size: 300% 100%;
    }
  }

  /* RTL specific styles */

  @keyframes material-combo-box-loader-progress-rtl {
    0% {
      background-position: 100% 0;
      background-size: 300% 100%;
    }

    33% {
      background-position: 200% 0;
      background-size: 400% 100%;
    }

    67% {
      background-position: 300% 0;
      background-size: 250% 100%;
    }

    100% {
      background-position: 400% 0;
      background-size: 300% 100%;
    }
  }

  :host([loading][dir='rtl']) [part='loader'] {
    animation: 3s linear infinite material-combo-box-loader-progress-rtl,
      0.3s 0.1s both material-combo-box-loader-fade-in;
  }
`],{moduleId:"material-combo-box-overlay"});const nr=document.createElement("template");nr.innerHTML='\n  <style>\n    @font-face {\n      font-family: \'material-icons\';\n      src: url(data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAjAAAsAAAAADaAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAADsAAABUIIslek9TLzIAAAFEAAAARAAAAFZSk1xEY21hcAAAAYgAAACNAAACNOuCXH5nbHlmAAACGAAABDoAAAX4NWGBxmhlYWQAAAZUAAAAMAAAADZhSa2YaGhlYQAABoQAAAAeAAAAJBGxCLtobXR4AAAGpAAAABMAAABAjXoAAGxvY2EAAAa4AAAAIgAAACIKMAjcbWF4cAAABtwAAAAfAAAAIAEeAFRuYW1lAAAG/AAAATQAAAJe3l764XBvc3QAAAgwAAAAkAAAAMondETCeJxjYGRgYOBiMGCwY2BycfMJYeDLSSzJY5BiYGGAAJA8MpsxJzM9kYEDxgPKsYBpDiBmg4gCACY7BUgAeJxjYOS4wTiBgZWBga2WbQIDA2MAhGZpYChlymZgYGJgZWbACgLSXFMYHF4xvuJnv/CvgOEG+wXG6UBhRpAcAA0HDXt4nO2R2Q0DIQxEHwt7HzSSGlJQvlJkqqGJjYdJGbH0PPJgELKBEcjBIyiQ3iQUr3BT9zNb9wvP3lPkt3rfkZNy1KXnIXpLvDgxs7DGvZ2Dk4saxxP/OHr+/KqqCZo+08EgzUa7acVoym002lubDNLZIF0M0tUg3Yz22XaD9DD6XTsN0ssgrYb6BZEQJiUAAAB4nH1UXUgcVxS+Z2ZnZpeq7IT9CbTY2Z24o1m72+zPTB/UFSS2MWssTZRs6doqialmy27bPIghPzQttCxjfEhjfGhoUFLBQoVdKixSkofCEkurwQdBgw1NqeCWFrokVt3b3pnRqm3J/Nw598537v3Od869CBC5uFm2EZkRAgl4kQcOuFm1NJcv3R+kBVpQS/dNdzcilH9w80e0F+8EPsiDAjCkUv485SMIgqd8GxHT3dIc8UYUQnjefINLoGfR88RDDIt2F3lFdwXYeVslBF2BBgjzIR/QLt7FzZ7Kb+7Pn5LfkMnDNhrfP++wjexYnlx6Z9fPtTXGZnAyh5hbiEHIApwFJPpD/OYg5TdNqnAJbpFgiGXgWIbp13AgWQhxllFL49RJFcumVWKVxlWY2cI1buHIdE6gV1S4h2WVOsn0qziMw8Ta0iLBLKFnjPk0qDYrlyArluaIJnpD+UmXaSONbu38IO40Qn+9RPQxo/3oEFLIPG6ORRxrdTqQ0yEoMlJkq+RBkod2Sz6QPFalARRZcFaC02HlKoBjaVFLgemrmVwGr0aPHYuCPZOD4VwG7NG2tihezeRmRq8NPaiPROofDF2D5h373etU+VHcwJkJrJDN4b5cFhc0J7Blc3A9lwVbtG1t7T9+OKfbjK00jr89D1r4umZj9IqWcQtFTUMRivQKLoPinhifQ8LTYhTDwbDIB02TM//HxGB5RiuEp1NeP5DPkwQZ+pLa2GQr0D7kRY3ba/+z8C5lQ7qyAV1Zm6EswXKszelwOgKKrMghySN5TJOPlxfwVEcHHFlYhsLyAhzp6MBTC8uPe+KxtEeSPOlY/Lsds+e15qbqmprqpuaxbYOt6IrjicVFPBHv6opD++IitMe7Nir/7WqYtLDHWTeQieyrXssyN4sqUBWqQy8jVMWKgqaivE/RahBYu02PJRhQJFZ0a9zDIcUCcjikxyu6OUkOCloSWIoMBwNaoHYb+8v8I1wsruKRzro7FzGXNi+l12PV3oPD3aeTZ7uzZeWxaEttLZi68Q+yt0YbvZD69acnUPZHAc50Rr4vfYYvCm4d1Nna1wPv/zYClrdhLf3kQJr5ovts8nT3cI23OgMveFuisfLyUh4OpS5oowe9cuH13h6s/v45LsB7cIWt9ba0xlxo114j9QU80IIpyiytf0xNo11nko90SJiCnj3rdvREEFEbEPfm2eEEF8/+nLxqlHNdJFJHSnt0avTmw9rZmvHUucsDycRtn9/vu51IFpN9x/E31DTTnty7B0jh8V+e+zoQ2oJpHi/6TmhYjRalNZa3CLcqVGuw05XX+Gj3do5cAZ1VWC8x4MlRSI6Tq+6+3pGbmcErl+5FPj0/cPgVfY0BxmZUWqS+N1HqxSk8r2+2RxPpT1pfDQam+q0njl/+6IbB3qjBD1LvNB3GD3EKhqCIy9DfIQrMlQAAeJxjYGRgYABiYWGbw/H8Nl8ZuDkTgCIMNaobGhH0v0zO++wXgFwOBiaQKAAHHgoPeJxjYGRgYL/wr4CBgcuKAQg47zMwMqACAQBc2wOEAAB4nGNgYGDgTCAec1mh8gG9VgYDAAAAAAAAGAAwAGIAdgCKAJ4AwAEkATIBcAHcAlQCYgKwAvwAAHicY2BkYGAQYPBgYGEAASYg5gJCBob/YD4DABFeAXMAeJx9kL1uwjAUhU8gUJVIVaWqnRgsVepSEX5G1BkkRgb2EBwIcuLIMUi8QR+kT9CH6NgH6VP0xHiBAVtyvvvdc50oAB7xgwDNCvDgzma1cMfqzG3Ss+eQ/Oq5gwhjz136D889vGPhOcITDrwhCO9p+vj03GL+y3Ob/ttzSP713MEL/jx30Q/guYdV0Pcc4S0wRWKlyRM1yFNd1ku5PajkSl5WK2nqXJdiHI8uG3NZSkOzEeuTqI/bibWZyIwuxEyXViqlRWX0XqY23llbTYfDzPs41QUKJLCQMMhJCgM+U2iUqLGk3/JfKHbMzeSt3sr5mqapBf9/jNHNiTl96XrnzIZTa5x41jjyiya0FhnrjBnNuwRmbrZJK25NU7nenialj7FzUxWmGHJnV/nYvb34BzHZcLZ4nG2M0Q6CMBRDV2CIOhTf/Ak+am5XIdyw5QoS/l4W4ptN2uYkTVWmdt3VfzXIkKOARokDKhxxwhkGNS64osFNXaxIWFoflnGx4s2Oc0xQOcs0eivadeQGs+VHwtgyPaf6B9K/ukk7pjTj4IbKS4jpT9P2JTmtZDa3vn/bB5MvItu1FOJgfTnHVEp9AbKdMX4=) format(\'woff\');\n      font-weight: normal;\n      font-style: normal;\n    }\n\n    html {\n      --material-icons-arrow-downward: "\\ea01";\n      --material-icons-arrow-upward: "\\ea02";\n      --material-icons-calendar: "\\ea03";\n      --material-icons-check: "\\ea04";\n      --material-icons-chevron-left: "\\ea05";\n      --material-icons-chevron-right: "\\ea06";\n      --material-icons-clear: "\\ea07";\n      --material-icons-clock: "\\ea08";\n      --material-icons-dropdown: "\\ea09";\n      --material-icons-error: "\\ea0a";\n      --material-icons-eye: "\\ea0b";\n      --material-icons-eye-disabled: "\\ea0c";\n      --material-icons-play: "\\ea0d";\n      --material-icons-reload: "\\ea0e";\n      --material-icons-upload: "\\ea0f";\n    }\n  </style>\n',document.head.appendChild(nr.content);const or=r`
  :host {
    display: flex;
    align-items: center;
    box-sizing: border-box;
    min-height: 36px;
    padding: 8px 32px 8px 10px;
    overflow: hidden;
    font-family: var(--material-font-family);
    font-size: var(--material-small-font-size);
    line-height: 24px;
  }

  /* It's the list-box's responsibility to add the focus style */
  :host([focused]) {
    outline: none;
  }

  /* Checkmark */
  [part='checkmark']::before {
    display: var(--_material-item-selected-icon-display, none);
    content: '';
    font-family: material-icons;
    font-size: 24px;
    line-height: 1;
    font-weight: 400;
    width: 24px;
    text-align: center;
    margin-right: 10px;
    color: var(--material-secondary-text-color);
    flex: none;
  }

  :host([selected]) [part='checkmark']::before {
    content: var(--material-icons-check);
  }

  @media (any-hover: hover) {
    :host(:hover:not([disabled])) {
      background-color: var(--material-secondary-background-color);
    }

    :host([focused]:not([disabled])) {
      background-color: var(--material-divider-color);
    }
  }

  /* Disabled */
  :host([disabled]) {
    color: var(--material-disabled-text-color);
    cursor: default;
    pointer-events: none;
  }

  /* RTL specific styles */
  :host([dir='rtl']) {
    padding: 8px 10px 8px 32px;
  }

  :host([dir='rtl']) [part='checkmark']::before {
    margin-right: 0;
    margin-left: 10px;
  }
`;$s("vaadin-item",or,{moduleId:"material-item"});$s("vaadin-combo-box-item",[or,r`
  :host {
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
    padding: 4px 10px;
    --_material-item-selected-icon-display: block;
  }
`],{moduleId:"material-combo-box-item"});class sr extends(zs(Ys(d))){static get template(){return c`
      <style>
        :host {
          display: block;
        }

        :host([hidden]) {
          display: none;
        }
      </style>
      <span part="checkmark" aria-hidden="true"></span>
      <div part="content">
        <slot></slot>
      </div>
    `}static get is(){return"vaadin-combo-box-item"}static get properties(){return{index:Number,item:Object,label:String,selected:{type:Boolean,value:!1,reflectToAttribute:!0},focused:{type:Boolean,value:!1,reflectToAttribute:!0},renderer:Function,_oldRenderer:Function}}static get observers(){return["__rendererOrItemChanged(renderer, index, item.*, selected, focused)","__updateLabel(label, renderer)"]}connectedCallback(){super.connectedCallback(),this._comboBox=this.parentNode.comboBox;const e=this._comboBox.getAttribute("dir");e&&this.setAttribute("dir",e)}requestContentUpdate(){if(!this.renderer)return;const e={index:this.index,item:this.item,focused:this.focused,selected:this.selected};this.renderer(this,this._comboBox,e)}__rendererOrItemChanged(e,t,i){void 0!==i&&void 0!==t&&(this._oldRenderer!==e&&(this.innerHTML="",delete this._$litPart$),e&&(this._oldRenderer=e,this.requestContentUpdate()))}__updateLabel(e,t){t||(this.textContent=e)}}customElements.define(sr.is,sr);const rr={start:"top",end:"bottom"},lr={start:"left",end:"right"},dr=e=>class extends e{static get properties(){return{positionTarget:{type:Object,value:null},horizontalAlign:{type:String,value:"start"},verticalAlign:{type:String,value:"top"},noHorizontalOverlap:{type:Boolean,value:!1},noVerticalOverlap:{type:Boolean,value:!1}}}static get observers(){return["__positionSettingsChanged(horizontalAlign, verticalAlign, noHorizontalOverlap, noVerticalOverlap)","__overlayOpenedChanged(opened, positionTarget)"]}constructor(){super(),this._updatePosition=this._updatePosition.bind(this)}connectedCallback(){super.connectedCallback(),this.opened&&this.__addUpdatePositionEventListeners()}disconnectedCallback(){super.disconnectedCallback(),this.__removeUpdatePositionEventListeners()}__addUpdatePositionEventListeners(){window.addEventListener("resize",this._updatePosition),this.__positionTargetAncestorRootNodes=function(e){const t=[];for(;e;){if(e.nodeType===Node.DOCUMENT_NODE){t.push(e);break}e.nodeType!==Node.DOCUMENT_FRAGMENT_NODE?e=e.assignedSlot?e.assignedSlot:e.parentNode:(t.push(e),e=e.host)}return t}(this.positionTarget),this.__positionTargetAncestorRootNodes.forEach((e=>{e.addEventListener("scroll",this._updatePosition,!0)}))}__removeUpdatePositionEventListeners(){window.removeEventListener("resize",this._updatePosition),this.__positionTargetAncestorRootNodes&&(this.__positionTargetAncestorRootNodes.forEach((e=>{e.removeEventListener("scroll",this._updatePosition,!0)})),this.__positionTargetAncestorRootNodes=null)}__overlayOpenedChanged(e,t){if(this.__removeUpdatePositionEventListeners(),e&&t&&this.__addUpdatePositionEventListeners(),e){const e=getComputedStyle(this);this.__margins||(this.__margins={},["top","bottom","left","right"].forEach((t=>{this.__margins[t]=parseInt(e[t],10)}))),this.setAttribute("dir",e.direction),this._updatePosition(),requestAnimationFrame((()=>this._updatePosition()))}}get __isRTL(){return"rtl"===this.getAttribute("dir")}__positionSettingsChanged(){this._updatePosition()}_updatePosition(){if(!this.positionTarget||!this.opened)return;const e=this.positionTarget.getBoundingClientRect(),t=this.__shouldAlignStartVertically(e);this.style.justifyContent=t?"flex-start":"flex-end";const i=this.__shouldAlignStartHorizontally(e,this.__isRTL),a=!this.__isRTL&&i||this.__isRTL&&!i;this.style.alignItems=a?"flex-start":"flex-end";const n=this.getBoundingClientRect(),o=this.__calculatePositionInOneDimension(e,n,this.noVerticalOverlap,rr,this,t),s=this.__calculatePositionInOneDimension(e,n,this.noHorizontalOverlap,lr,this,i);Object.assign(this.style,o,s),this.toggleAttribute("bottom-aligned",!t),this.toggleAttribute("top-aligned",t),this.toggleAttribute("end-aligned",!a),this.toggleAttribute("start-aligned",a)}__shouldAlignStartHorizontally(e,t){const i=Math.max(this.__oldContentWidth||0,this.$.overlay.offsetWidth);this.__oldContentWidth=this.$.overlay.offsetWidth;const a=Math.min(window.innerWidth,document.documentElement.clientWidth),n=!t&&"start"===this.horizontalAlign||t&&"end"===this.horizontalAlign;return this.__shouldAlignStart(e,i,a,this.__margins,n,this.noHorizontalOverlap,lr)}__shouldAlignStartVertically(e){const t=Math.max(this.__oldContentHeight||0,this.$.overlay.offsetHeight);this.__oldContentHeight=this.$.overlay.offsetHeight;const i=Math.min(window.innerHeight,document.documentElement.clientHeight),a="top"===this.verticalAlign;return this.__shouldAlignStart(e,t,i,this.__margins,a,this.noVerticalOverlap,rr)}__shouldAlignStart(e,t,i,a,n,o,s){const r=i-e[o?s.end:s.start]-a[s.end],l=e[o?s.start:s.end]-a[s.start],d=n?r:l;return n===(d>(n?l:r)||d>t)}__calculatePositionInOneDimension(e,t,i,a,n,o){const s=o?a.start:a.end,r=o?a.end:a.start;return{[s]:`${parseFloat(n.style[s]||getComputedStyle(n)[s])+(t[o?a.start:a.end]-e[i===o?a.end:a.start])*(o?-1:1)}px`,[r]:""}}};let cr;$s("vaadin-combo-box-overlay",r`
    #overlay {
      width: var(--vaadin-combo-box-overlay-width, var(--_vaadin-combo-box-overlay-default-width, auto));
    }

    [part='content'] {
      display: flex;
      flex-direction: column;
      height: 100%;
    }
  `,{moduleId:"vaadin-combo-box-overlay-styles"});class ur extends(dr(ir)){static get is(){return"vaadin-combo-box-overlay"}static get template(){return cr||(cr=super.template.cloneNode(!0),cr.content.querySelector('[part~="overlay"]').removeAttribute("tabindex")),cr}static get observers(){return["_setOverlayWidth(positionTarget, opened)"]}connectedCallback(){super.connectedCallback();const e=this.__dataHost,t=e&&e.getRootNode().host;this._comboBox=t;const i=t&&t.getAttribute("dir");i&&this.setAttribute("dir",i)}ready(){super.ready();const e=document.createElement("div");e.setAttribute("part","loader");const t=this.shadowRoot.querySelector('[part~="content"]');t.parentNode.insertBefore(e,t)}_outsideClickListener(e){const t=e.composedPath();t.includes(this.positionTarget)||t.includes(this)||this.close()}_setOverlayWidth(e,t){if(e&&t){const t=this.localName;this.style.setProperty(`--_${t}-default-width`,`${e.clientWidth}px`);const i=getComputedStyle(this._comboBox).getPropertyValue(`--${t}-width`);""===i?this.style.removeProperty(`--${t}-width`):this.style.setProperty(`--${t}-width`,i),this._updatePosition()}}}customElements.define(ur.is,ur);let hr=0,pr=0;const vr=[];let mr=0,fr=!1;const gr=document.createTextNode("");new window.MutationObserver((function(){fr=!1;const e=vr.length;for(let t=0;t<e;t++){const e=vr[t];if(e)try{e()}catch(e){setTimeout((()=>{throw e}))}}vr.splice(0,e),pr+=e})).observe(gr,{characterData:!0});const _r={after:e=>({run:t=>window.setTimeout(t,e),cancel(e){window.clearTimeout(e)}}),run:(e,t)=>window.setTimeout(e,t),cancel(e){window.clearTimeout(e)}},yr={run:e=>window.requestAnimationFrame(e),cancel(e){window.cancelAnimationFrame(e)}},kr={run:e=>window.requestIdleCallback?window.requestIdleCallback(e):window.setTimeout(e,16),cancel(e){window.cancelIdleCallback?window.cancelIdleCallback(e):window.clearTimeout(e)}},br={run(e){fr||(fr=!0,gr.textContent=mr,mr+=1),vr.push(e);const t=hr;return hr+=1,t},cancel(e){const t=e-pr;if(t>=0){if(!vr[t])throw new Error(`invalid async handle: ${e}`);vr[t]=null}}};class xr{static debounce(e,t,i){return e instanceof xr?e._cancelAsync():e=new xr,e.setConfig(t,i),e}constructor(){this._asyncModule=null,this._callback=null,this._timer=null}setConfig(e,t){this._asyncModule=e,this._callback=t,this._timer=this._asyncModule.run((()=>{this._timer=null,$r.delete(this),this._callback()}))}cancel(){this.isActive()&&(this._cancelAsync(),$r.delete(this))}_cancelAsync(){this.isActive()&&(this._asyncModule.cancel(this._timer),this._timer=null)}flush(){this.isActive()&&(this.cancel(),this._callback())}isActive(){return null!=this._timer}}let $r=new Set;function wr(){const e=Boolean($r.size);return $r.forEach((e=>{try{e.flush()}catch(e){setTimeout((()=>{throw e}))}})),e}const Cr=()=>{let e;do{e=wr()}while(e)},Ar=navigator.userAgent.match(/iP(?:hone|ad;(?: U;)? CPU) OS (\d+)/),Ir=Ar&&Ar[1]>=8,Er={_ratio:.5,_scrollerPaddingTop:0,_scrollPosition:0,_physicalSize:0,_physicalAverage:0,_physicalAverageCount:0,_physicalTop:0,_virtualCount:0,_estScrollHeight:0,_scrollHeight:0,_viewportHeight:0,_viewportWidth:0,_physicalItems:null,_physicalSizes:null,_firstVisibleIndexVal:null,_lastVisibleIndexVal:null,_maxPages:2,_templateCost:0,get _physicalBottom(){return this._physicalTop+this._physicalSize},get _scrollBottom(){return this._scrollPosition+this._viewportHeight},get _virtualEnd(){return this._virtualStart+this._physicalCount-1},get _hiddenContentSize(){return this._physicalSize-this._viewportHeight},get _maxScrollTop(){return this._estScrollHeight-this._viewportHeight+this._scrollOffset},get _maxVirtualStart(){const e=this._virtualCount;return Math.max(0,e-this._physicalCount)},get _virtualStart(){return this._virtualStartVal||0},set _virtualStart(e){e=this._clamp(e,0,this._maxVirtualStart),this._virtualStartVal=e},get _physicalStart(){return this._physicalStartVal||0},set _physicalStart(e){(e%=this._physicalCount)<0&&(e=this._physicalCount+e),this._physicalStartVal=e},get _physicalEnd(){return(this._physicalStart+this._physicalCount-1)%this._physicalCount},get _physicalCount(){return this._physicalCountVal||0},set _physicalCount(e){this._physicalCountVal=e},get _optPhysicalSize(){return 0===this._viewportHeight?1/0:this._viewportHeight*this._maxPages},get _isVisible(){return Boolean(this.offsetWidth||this.offsetHeight)},get firstVisibleIndex(){let e=this._firstVisibleIndexVal;if(null==e){let t=this._physicalTop+this._scrollOffset;e=this._iterateItems(((e,i)=>{if(t+=this._getPhysicalSizeIncrement(e),t>this._scrollPosition)return i}))||0,this._firstVisibleIndexVal=e}return e},get lastVisibleIndex(){let e=this._lastVisibleIndexVal;if(null==e){let t=this._physicalTop+this._scrollOffset;this._iterateItems(((i,a)=>{t<this._scrollBottom&&(e=a),t+=this._getPhysicalSizeIncrement(i)})),this._lastVisibleIndexVal=e}return e},get _scrollOffset(){return this._scrollerPaddingTop+this.scrollOffset},_scrollHandler(){const e=Math.max(0,Math.min(this._maxScrollTop,this._scrollTop));let t=e-this._scrollPosition;const i=t>=0;if(this._scrollPosition=e,this._firstVisibleIndexVal=null,this._lastVisibleIndexVal=null,Math.abs(t)>this._physicalSize&&this._physicalSize>0){t-=this._scrollOffset;const e=Math.round(t/this._physicalAverage);this._virtualStart+=e,this._physicalStart+=e,this._physicalTop=Math.min(Math.floor(this._virtualStart)*this._physicalAverage,this._scrollPosition),this._update()}else if(this._physicalCount>0){const e=this._getReusables(i);i?(this._physicalTop=e.physicalTop,this._virtualStart+=e.indexes.length,this._physicalStart+=e.indexes.length):(this._virtualStart-=e.indexes.length,this._physicalStart-=e.indexes.length),this._update(e.indexes,i?null:e.indexes),this._debounce("_increasePoolIfNeeded",this._increasePoolIfNeeded.bind(this,0),br)}},_getReusables(e){let t,i,a;const n=[],o=this._hiddenContentSize*this._ratio,s=this._virtualStart,r=this._virtualEnd,l=this._physicalCount;let d=this._physicalTop+this._scrollOffset;const c=this._physicalBottom+this._scrollOffset,u=this._scrollPosition,h=this._scrollBottom;for(e?(t=this._physicalStart,i=u-d):(t=this._physicalEnd,i=c-h);a=this._getPhysicalSizeIncrement(t),i-=a,!(n.length>=l||i<=o);)if(e){if(r+n.length+1>=this._virtualCount)break;if(d+a>=u-this._scrollOffset)break;n.push(t),d+=a,t=(t+1)%l}else{if(s-n.length<=0)break;if(d+this._physicalSize-a<=h)break;n.push(t),d-=a,t=0===t?l-1:t-1}return{indexes:n,physicalTop:d-this._scrollOffset}},_update(e,t){if(!(e&&0===e.length||0===this._physicalCount)){if(this._assignModels(e),this._updateMetrics(e),t)for(;t.length;){const e=t.pop();this._physicalTop-=this._getPhysicalSizeIncrement(e)}this._positionItems(),this._updateScrollerSize()}},_isClientFull(){return 0!==this._scrollBottom&&this._physicalBottom-1>=this._scrollBottom&&this._physicalTop<=this._scrollPosition},_increasePoolIfNeeded(e){const t=this._clamp(this._physicalCount+e,3,this._virtualCount-this._virtualStart)-this._physicalCount;let i=Math.round(.5*this._physicalCount);if(!(t<0)){if(t>0){const e=window.performance.now();[].push.apply(this._physicalItems,this._createPool(t));for(let e=0;e<t;e++)this._physicalSizes.push(0);this._physicalCount+=t,this._physicalStart>this._physicalEnd&&this._isIndexRendered(this._focusedVirtualIndex)&&this._getPhysicalIndex(this._focusedVirtualIndex)<this._physicalEnd&&(this._physicalStart+=t),this._update(),this._templateCost=(window.performance.now()-e)/t,i=Math.round(.5*this._physicalCount)}this._virtualEnd>=this._virtualCount-1||0===i||(this._isClientFull()?this._physicalSize<this._optPhysicalSize&&this._debounce("_increasePoolIfNeeded",this._increasePoolIfNeeded.bind(this,this._clamp(Math.round(50/this._templateCost),1,i)),kr):this._debounce("_increasePoolIfNeeded",this._increasePoolIfNeeded.bind(this,i),br))}},_render(){if(this.isAttached&&this._isVisible)if(0!==this._physicalCount){const e=this._getReusables(!0);this._physicalTop=e.physicalTop,this._virtualStart+=e.indexes.length,this._physicalStart+=e.indexes.length,this._update(e.indexes),this._update(),this._increasePoolIfNeeded(0)}else this._virtualCount>0&&(this.updateViewportBoundaries(),this._increasePoolIfNeeded(3))},_itemsChanged(e){"items"===e.path&&(this._virtualStart=0,this._physicalTop=0,this._virtualCount=this.items?this.items.length:0,this._physicalIndexForKey={},this._firstVisibleIndexVal=null,this._lastVisibleIndexVal=null,this._physicalCount=this._physicalCount||0,this._physicalItems=this._physicalItems||[],this._physicalSizes=this._physicalSizes||[],this._physicalStart=0,this._scrollTop>this._scrollOffset&&this._resetScrollPosition(0),this._debounce("_render",this._render,yr))},_iterateItems(e,t){let i,a,n,o;if(2===arguments.length&&t){for(o=0;o<t.length;o++)if(i=t[o],a=this._computeVidx(i),null!=(n=e.call(this,i,a)))return n}else{for(i=this._physicalStart,a=this._virtualStart;i<this._physicalCount;i++,a++)if(null!=(n=e.call(this,i,a)))return n;for(i=0;i<this._physicalStart;i++,a++)if(null!=(n=e.call(this,i,a)))return n}},_computeVidx(e){return e>=this._physicalStart?this._virtualStart+(e-this._physicalStart):this._virtualStart+(this._physicalCount-this._physicalStart)+e},_updateMetrics(e){Cr();let t=0,i=0;const a=this._physicalAverageCount,n=this._physicalAverage;this._iterateItems(((e,a)=>{i+=this._physicalSizes[e],this._physicalSizes[e]=this._physicalItems[e].offsetHeight,t+=this._physicalSizes[e],this._physicalAverageCount+=this._physicalSizes[e]?1:0}),e),this._physicalSize=this._physicalSize+t-i,this._physicalAverageCount!==a&&(this._physicalAverage=Math.round((n*a+t)/this._physicalAverageCount))},_positionItems(){this._adjustScrollPosition();let e=this._physicalTop;this._iterateItems((t=>{this.translate3d(0,`${e}px`,0,this._physicalItems[t]),e+=this._physicalSizes[t]}))},_getPhysicalSizeIncrement(e){return this._physicalSizes[e]},_adjustScrollPosition(){const e=0===this._virtualStart?this._physicalTop:Math.min(this._scrollPosition+this._physicalTop,0);if(0!==e){this._physicalTop-=e;const t=this._scrollPosition;!Ir&&t>0&&this._resetScrollPosition(t-e)}},_resetScrollPosition(e){this.scrollTarget&&e>=0&&(this._scrollTop=e,this._scrollPosition=this._scrollTop)},_updateScrollerSize(e){this._estScrollHeight=this._physicalBottom+Math.max(this._virtualCount-this._physicalCount-this._virtualStart,0)*this._physicalAverage,((e=(e=e||0===this._scrollHeight)||this._scrollPosition>=this._estScrollHeight-this._physicalSize)||Math.abs(this._estScrollHeight-this._scrollHeight)>=this._viewportHeight)&&(this.$.items.style.height=`${this._estScrollHeight}px`,this._scrollHeight=this._estScrollHeight)},scrollToIndex(e){if("number"!=typeof e||e<0||e>this.items.length-1)return;if(Cr(),0===this._physicalCount)return;e=this._clamp(e,0,this._virtualCount-1),(!this._isIndexRendered(e)||e>=this._maxVirtualStart)&&(this._virtualStart=e-1),this._assignModels(),this._updateMetrics(),this._physicalTop=this._virtualStart*this._physicalAverage;let t=this._physicalStart,i=this._virtualStart,a=0;const n=this._hiddenContentSize;for(;i<e&&a<=n;)a+=this._getPhysicalSizeIncrement(t),t=(t+1)%this._physicalCount,i+=1;this._updateScrollerSize(!0),this._positionItems(),this._resetScrollPosition(this._physicalTop+this._scrollOffset+a),this._increasePoolIfNeeded(0),this._firstVisibleIndexVal=null,this._lastVisibleIndexVal=null},_resetAverage(){this._physicalAverage=0,this._physicalAverageCount=0},_resizeHandler(){this._debounce("_render",(()=>{this._firstVisibleIndexVal=null,this._lastVisibleIndexVal=null,this._isVisible?(this.updateViewportBoundaries(),this.toggleScrollListener(!0),this._resetAverage(),this._render()):this.toggleScrollListener(!1)}),yr)},_isIndexRendered(e){return e>=this._virtualStart&&e<=this._virtualEnd},_getPhysicalIndex(e){return(this._physicalStart+(e-this._virtualStart))%this._physicalCount},_clamp:(e,t,i)=>Math.min(i,Math.max(t,e)),_debounce(e,t,i){var a;this._debouncers=this._debouncers||{},this._debouncers[e]=xr.debounce(this._debouncers[e],i,t.bind(this)),a=this._debouncers[e],$r.add(a)}};class zr{constructor({createElements:e,updateElement:t,scrollTarget:i,scrollContainer:a,elementsContainer:n,reorderElements:o}){this.isAttached=!0,this._vidxOffset=0,this.createElements=e,this.updateElement=t,this.scrollTarget=i,this.scrollContainer=a,this.elementsContainer=n||a,this.reorderElements=o,this._maxPages=1.3,this.__placeholderHeight=200,this.__elementHeightQueue=Array(10),this.timeouts={SCROLL_REORDER:500,IGNORE_WHEEL:500},this.__resizeObserver=new ResizeObserver((()=>this._resizeHandler())),"visible"===getComputedStyle(this.scrollTarget).overflow&&(this.scrollTarget.style.overflow="auto"),"static"===getComputedStyle(this.scrollContainer).position&&(this.scrollContainer.style.position="relative"),this.__resizeObserver.observe(this.scrollTarget),this.scrollTarget.addEventListener("scroll",(()=>this._scrollHandler())),this._scrollLineHeight=this._getScrollLineHeight(),this.scrollTarget.addEventListener("wheel",(e=>this.__onWheel(e))),this.reorderElements&&(this.scrollTarget.addEventListener("mousedown",(()=>this.__mouseDown=!0)),this.scrollTarget.addEventListener("mouseup",(()=>{this.__mouseDown=!1,this.__pendingReorder&&this.__reorderElements()})))}get scrollOffset(){return 0}get adjustedFirstVisibleIndex(){return this.firstVisibleIndex+this._vidxOffset}get adjustedLastVisibleIndex(){return this.lastVisibleIndex+this._vidxOffset}scrollToIndex(e){if("number"!=typeof e||isNaN(e)||0===this.size||!this.scrollTarget.offsetHeight)return;e=this._clamp(e,0,this.size-1);const t=this.__getVisibleElements().length;let i=Math.floor(e/this.size*this._virtualCount);this._virtualCount-i<t?(i=this._virtualCount-(this.size-e),this._vidxOffset=this.size-this._virtualCount):i<t?e<1e3?(i=e,this._vidxOffset=0):(i=1e3,this._vidxOffset=e-i):this._vidxOffset=e-i,this.__skipNextVirtualIndexAdjust=!0,super.scrollToIndex(i),this.adjustedFirstVisibleIndex!==e&&this._scrollTop<this._maxScrollTop&&!this.grid&&(this._scrollTop-=this.__getIndexScrollOffset(e)||0),this._scrollHandler()}flush(){0!==this.scrollTarget.offsetHeight&&(this._resizeHandler(),Cr(),this._scrollHandler(),this.__scrollReorderDebouncer&&this.__scrollReorderDebouncer.flush(),this.__debouncerWheelAnimationFrame&&this.__debouncerWheelAnimationFrame.flush())}update(e=0,t=this.size-1){this.__getVisibleElements().forEach((i=>{i.__virtualIndex>=e&&i.__virtualIndex<=t&&this.__updateElement(i,i.__virtualIndex,!0)}))}__updateElement(e,t,i){e.style.paddingTop&&(e.style.paddingTop=""),this.__preventElementUpdates||e.__lastUpdatedIndex===t&&!i||(this.updateElement(e,t),e.__lastUpdatedIndex=t);const a=e.offsetHeight;if(0===a)e.style.paddingTop=`${this.__placeholderHeight}px`;else{this.__elementHeightQueue.push(a),this.__elementHeightQueue.shift();const e=this.__elementHeightQueue.filter((e=>void 0!==e));this.__placeholderHeight=Math.round(e.reduce(((e,t)=>e+t),0)/e.length)}}__getIndexScrollOffset(e){const t=this.__getVisibleElements().find((t=>t.__virtualIndex===e));return t?this.scrollTarget.getBoundingClientRect().top-t.getBoundingClientRect().top:void 0}get size(){return this.__size}set size(e){if(e===this.size)return;let t,i;if(this.__preventElementUpdates=!0,e>0&&(t=this.adjustedFirstVisibleIndex,i=this.__getIndexScrollOffset(t)),this.__size=e,Cr(),this._itemsChanged({path:"items"}),Cr(),e>0){t=Math.min(t,e-1),this.scrollToIndex(t);const a=this.__getIndexScrollOffset(t);void 0!==i&&void 0!==a&&(this._scrollTop+=i-a)}this.elementsContainer.children.length||requestAnimationFrame((()=>this._resizeHandler())),this.__preventElementUpdates=!1,this._resizeHandler(),Cr()}get _scrollTop(){return this.scrollTarget.scrollTop}set _scrollTop(e){this.scrollTarget.scrollTop=e}get items(){return{length:Math.min(this.size,1e5)}}get offsetHeight(){return this.scrollTarget.offsetHeight}get $(){return{items:this.scrollContainer}}updateViewportBoundaries(){const e=window.getComputedStyle(this.scrollTarget);this._scrollerPaddingTop=this.scrollTarget===this?0:parseInt(e["padding-top"],10),this._isRTL=Boolean("rtl"===e.direction),this._viewportWidth=this.elementsContainer.offsetWidth,this._viewportHeight=this.scrollTarget.offsetHeight,this._scrollPageHeight=this._viewportHeight-this._scrollLineHeight,this.grid&&this._updateGridMetrics()}setAttribute(){}_createPool(e){const t=this.createElements(e),i=document.createDocumentFragment();return t.forEach((e=>{e.style.position="absolute",i.appendChild(e),this.__resizeObserver.observe(e)})),this.elementsContainer.appendChild(i),t}_assignModels(e){this._iterateItems(((e,t)=>{const i=this._physicalItems[e];i.hidden=t>=this.size,i.hidden?delete i.__lastUpdatedIndex:(i.__virtualIndex=t+(this._vidxOffset||0),this.__updateElement(i,i.__virtualIndex))}),e)}_isClientFull(){return setTimeout((()=>this.__clientFull=!0)),this.__clientFull||super._isClientFull()}translate3d(e,t,i,a){a.style.transform=`translateY(${t})`}toggleScrollListener(){}_scrollHandler(){this._adjustVirtualIndexOffset(this._scrollTop-(this.__previousScrollTop||0));const e=this.scrollTarget.scrollTop-this._scrollPosition;if(super._scrollHandler(),0!==this._physicalCount){const t=e>=0,i=this._getReusables(!t);i.indexes.length&&(this._physicalTop=i.physicalTop,t?(this._virtualStart-=i.indexes.length,this._physicalStart-=i.indexes.length):(this._virtualStart+=i.indexes.length,this._physicalStart+=i.indexes.length),this._resizeHandler())}this.reorderElements&&(this.__scrollReorderDebouncer=xr.debounce(this.__scrollReorderDebouncer,_r.after(this.timeouts.SCROLL_REORDER),(()=>this.__reorderElements()))),this.__previousScrollTop=this._scrollTop}__onWheel(e){if(e.ctrlKey||this._hasScrolledAncestor(e.target,e.deltaX,e.deltaY))return;let t=e.deltaY;if(e.deltaMode===WheelEvent.DOM_DELTA_LINE?t*=this._scrollLineHeight:e.deltaMode===WheelEvent.DOM_DELTA_PAGE&&(t*=this._scrollPageHeight),this._deltaYAcc=this._deltaYAcc||0,this._wheelAnimationFrame)return this._deltaYAcc+=t,void e.preventDefault();t+=this._deltaYAcc,this._deltaYAcc=0,this._wheelAnimationFrame=!0,this.__debouncerWheelAnimationFrame=xr.debounce(this.__debouncerWheelAnimationFrame,yr,(()=>this._wheelAnimationFrame=!1));const i=Math.abs(e.deltaX)+Math.abs(t);this._canScroll(this.scrollTarget,e.deltaX,t)?(e.preventDefault(),this.scrollTarget.scrollTop+=t,this.scrollTarget.scrollLeft+=e.deltaX,this._hasResidualMomentum=!0,this._ignoreNewWheel=!0,this._debouncerIgnoreNewWheel=xr.debounce(this._debouncerIgnoreNewWheel,_r.after(this.timeouts.IGNORE_WHEEL),(()=>this._ignoreNewWheel=!1))):this._hasResidualMomentum&&i<=this._previousMomentum||this._ignoreNewWheel?e.preventDefault():i>this._previousMomentum&&(this._hasResidualMomentum=!1),this._previousMomentum=i}_hasScrolledAncestor(e,t,i){return e!==this.scrollTarget&&e!==this.scrollTarget.getRootNode().host&&(!(!this._canScroll(e,t,i)||-1===["auto","scroll"].indexOf(getComputedStyle(e).overflow))||(e!==this&&e.parentElement?this._hasScrolledAncestor(e.parentElement,t,i):void 0))}_canScroll(e,t,i){return i>0&&e.scrollTop<e.scrollHeight-e.offsetHeight||i<0&&e.scrollTop>0||t>0&&e.scrollLeft<e.scrollWidth-e.offsetWidth||t<0&&e.scrollLeft>0}_getScrollLineHeight(){const e=document.createElement("div");e.style.fontSize="initial",e.style.display="none",document.body.appendChild(e);const t=window.getComputedStyle(e).fontSize;return document.body.removeChild(e),t?window.parseInt(t):void 0}__getVisibleElements(){return Array.from(this.elementsContainer.children).filter((e=>!e.hidden))}__reorderElements(){if(this.__mouseDown)return void(this.__pendingReorder=!0);this.__pendingReorder=!1;const e=this._virtualStart+(this._vidxOffset||0),t=this.__getVisibleElements(),i=t.find((e=>e.contains(this.elementsContainer.getRootNode().activeElement)||e.contains(this.scrollTarget.getRootNode().activeElement)))||t[0];if(!i)return;const a=i.__virtualIndex-e,n=t.indexOf(i)-a;if(n>0)for(let e=0;e<n;e++)this.elementsContainer.appendChild(t[e]);else if(n<0)for(let e=t.length+n;e<t.length;e++)this.elementsContainer.insertBefore(t[e],t[0]);if(qs){const{transform:e}=this.scrollTarget.style;this.scrollTarget.style.transform="translateZ(0)",setTimeout((()=>this.scrollTarget.style.transform=e))}}_adjustVirtualIndexOffset(e){if(this._virtualCount>=this.size)this._vidxOffset=0;else if(this.__skipNextVirtualIndexAdjust)this.__skipNextVirtualIndexAdjust=!1;else if(Math.abs(e)>1e4){const e=this._scrollTop/(this.scrollTarget.scrollHeight-this.scrollTarget.offsetHeight),t=e*this.size;this._vidxOffset=Math.round(t-e*this._virtualCount)}else{const e=this._vidxOffset,t=1e3,i=100;0===this._scrollTop?(this._vidxOffset=0,e!==this._vidxOffset&&super.scrollToIndex(0)):this.firstVisibleIndex<t&&this._vidxOffset>0&&(this._vidxOffset-=Math.min(this._vidxOffset,i),super.scrollToIndex(this.firstVisibleIndex+(e-this._vidxOffset)));const a=this.size-this._virtualCount;this._scrollTop>=this._maxScrollTop&&this._maxScrollTop>0?(this._vidxOffset=a,e!==this._vidxOffset&&super.scrollToIndex(this._virtualCount-1)):this.firstVisibleIndex>this._virtualCount-t&&this._vidxOffset<a&&(this._vidxOffset+=Math.min(a-this._vidxOffset,i),super.scrollToIndex(this.firstVisibleIndex-(this._vidxOffset-e)))}}}Object.setPrototypeOf(zr.prototype,Er);class Sr{constructor(e){this.__adapter=new zr(e)}get size(){return this.__adapter.size}set size(e){this.__adapter.size=e}scrollToIndex(e){this.__adapter.scrollToIndex(e)}update(e=0,t=this.size-1){this.__adapter.update(e,t)}flush(){this.__adapter.flush()}get firstVisibleIndex(){return this.__adapter.adjustedFirstVisibleIndex}get lastVisibleIndex(){return this.__adapter.adjustedLastVisibleIndex}}const Tr=class{toString(){return""}};class Lr extends d{static get is(){return"vaadin-combo-box-scroller"}static get template(){return c`
      <style>
        :host {
          display: block;
          min-height: 1px;
          overflow: auto;

          /* Fixes item background from getting on top of scrollbars on Safari */
          transform: translate3d(0, 0, 0);

          /* Enable momentum scrolling on iOS */
          -webkit-overflow-scrolling: touch;

          /* Fixes scrollbar disappearing when 'Show scroll bars: Always' enabled in Safari */
          box-shadow: 0 0 0 white;
        }

        #selector {
          border-width: var(--_vaadin-combo-box-items-container-border-width);
          border-style: var(--_vaadin-combo-box-items-container-border-style);
          border-color: var(--_vaadin-combo-box-items-container-border-color);
        }
      </style>
      <div id="selector">
        <slot></slot>
      </div>
    `}static get properties(){return{items:{type:Array,observer:"__itemsChanged"},focusedIndex:{type:Number,observer:"__focusedIndexChanged"},loading:{type:Boolean,observer:"__loadingChanged"},opened:{type:Boolean,observer:"__openedChanged"},selectedItem:{type:Object},itemIdPath:{type:String},comboBox:{type:Object},getItemLabel:{type:Object},renderer:{type:Object,observer:"__rendererChanged"},theme:{type:String}}}constructor(){super(),this.__boundOnItemClick=this.__onItemClick.bind(this)}__openedChanged(e){e&&this.requestContentUpdate()}ready(){super.ready(),this.__hostTagName=this.constructor.is.replace("-scroller",""),this.setAttribute("role","listbox"),this.addEventListener("click",(e=>e.stopPropagation())),this.__patchWheelOverScrolling(),this.__virtualizer=new Sr({createElements:this.__createElements.bind(this),updateElement:this.__updateElement.bind(this),elementsContainer:this,scrollTarget:this,scrollContainer:this.$.selector})}requestContentUpdate(){this.__virtualizer&&this.__virtualizer.update()}scrollIntoView(e){if(!(this.opened&&e>=0))return;const t=this._visibleItemsCount();let i=e;e>this.__virtualizer.lastVisibleIndex-1?(this.__virtualizer.scrollToIndex(e),i=e-t+1):e>this.__virtualizer.firstVisibleIndex&&(i=this.__virtualizer.firstVisibleIndex),this.__virtualizer.scrollToIndex(Math.max(0,i));const a=[...this.children].find((e=>!e.hidden&&e.index===this.__virtualizer.lastVisibleIndex));if(!a||e!==a.index)return;const n=a.getBoundingClientRect(),o=this.getBoundingClientRect(),s=n.bottom-o.bottom+this._viewportTotalPaddingBottom;s>0&&(this.scrollTop+=s)}__getAriaRole(e){return void 0!==e&&"option"}__getAriaSelected(e,t){return this.__isItemFocused(e,t).toString()}__isItemFocused(e,t){return e===t}__isItemSelected(e,t,i){return!(e instanceof Tr)&&(i&&void 0!==e&&void 0!==t?this.get(i,e)===this.get(i,t):e===t)}__itemsChanged(e){this.__virtualizer&&e&&(this.__virtualizer.size=e.length,this.__virtualizer.flush(),this.setAttribute("aria-setsize",e.length),this.requestContentUpdate())}__loadingChanged(e){this.__virtualizer&&!e&&setTimeout((()=>this.requestContentUpdate()))}__focusedIndexChanged(e,t){this.__virtualizer&&(e!==t&&this.requestContentUpdate(),e>=0&&!this.loading&&this.scrollIntoView(e))}__rendererChanged(e,t){(e||t)&&this.requestContentUpdate()}__createElements(e){return[...Array(e)].map((()=>{const e=document.createElement(`${this.__hostTagName}-item`);return e.addEventListener("click",this.__boundOnItemClick),e.tabIndex="-1",e.style.width="100%",e}))}__updateElement(e,t){const i=this.items[t],a=this.focusedIndex;e.setProperties({item:i,index:this.__requestItemByIndex(i,t),label:this.getItemLabel(i),selected:this.__isItemSelected(i,this.selectedItem,this.itemIdPath),renderer:this.renderer,focused:this.__isItemFocused(a,t)}),e.id=`${this.__hostTagName}-item-${t}`,e.setAttribute("role",this.__getAriaRole(t)),e.setAttribute("aria-selected",this.__getAriaSelected(a,t)),e.setAttribute("aria-posinset",t+1),this.theme?e.setAttribute("theme",this.theme):e.removeAttribute("theme")}__onItemClick(e){this.dispatchEvent(new CustomEvent("selection-changed",{detail:{item:e.currentTarget.item}}))}__patchWheelOverScrolling(){this.$.selector.addEventListener("wheel",(e=>{const t=0===this.scrollTop,i=this.scrollHeight-this.scrollTop-this.clientHeight<=1;(t&&e.deltaY<0||i&&e.deltaY>0)&&e.preventDefault()}))}get _viewportTotalPaddingBottom(){if(void 0===this._cachedViewportTotalPaddingBottom){const e=window.getComputedStyle(this.$.selector);this._cachedViewportTotalPaddingBottom=[e.paddingBottom,e.borderBottomWidth].map((e=>parseInt(e,10))).reduce(((e,t)=>e+t))}return this._cachedViewportTotalPaddingBottom}__requestItemByIndex(e,t){return e instanceof Tr&&void 0!==t&&this.dispatchEvent(new CustomEvent("index-requested",{detail:{index:t,currentScrollerPos:this._oldScrollerPosition}})),t}_visibleItemsCount(){this.__virtualizer.scrollToIndex(this.__virtualizer.firstVisibleIndex);return this.__virtualizer.size>0?this.__virtualizer.lastVisibleIndex-this.__virtualizer.firstVisibleIndex+1:0}}customElements.define(Lr.is,Lr);class Or extends d{static get is(){return"vaadin-combo-box-dropdown"}static get template(){return c`
      <vaadin-combo-box-overlay
        id="overlay"
        hidden$="[[_isOverlayHidden(_items.*, loading)]]"
        loading$="[[loading]]"
        opened="{{_overlayOpened}}"
        theme$="[[theme]]"
        position-target="[[positionTarget]]"
        no-vertical-overlap
        restore-focus-on-close="[[restoreFocusOnClose]]"
        restore-focus-node="[[restoreFocusNode]]"
      ></vaadin-combo-box-overlay>
    `}static get properties(){return{opened:Boolean,positionTarget:{type:Object},renderer:Function,loading:{type:Boolean,value:!1,reflectToAttribute:!0},theme:String,_selectedItem:{type:Object},_items:{type:Array},_focusedIndex:{type:Number,value:-1},focusedItem:{type:String,computed:"_getFocusedItem(_focusedIndex)"},_itemLabelPath:{type:String,value:"label"},_itemValuePath:{type:String,value:"value"},_scroller:Object,_itemIdPath:String,_overlayOpened:{type:Boolean,observer:"_openedChanged"}}}static get observers(){return["_openedOrItemsChanged(opened, _items, loading)","__updateScroller(_scroller, _items, opened, loading, _selectedItem, _itemIdPath, _focusedIndex, renderer, theme)"]}constructor(){super();const e=Or._uniqueId=1+Or._uniqueId||0;this.scrollerId=`${this.localName}-scroller-${e}`}ready(){super.ready(),this.__hostTagName=this.constructor.is.replace("-dropdown","");const e=this.$.overlay,t=`${this.__hostTagName}-scroller`;e.renderer=e=>{if(!e.firstChild){const i=document.createElement(t);e.appendChild(i)}},e.requestContentUpdate(),this._scroller=e.content.querySelector(t),this._scroller.id=this.scrollerId,this._scroller.getItemLabel=this.getItemLabel.bind(this),this._scroller.comboBox=this.getRootNode().host,this._scroller.addEventListener("selection-changed",(e=>this._forwardScrollerEvent(e))),this._scroller.addEventListener("index-requested",(e=>this._forwardScrollerEvent(e))),e.addEventListener("touchend",(e=>this._fireTouchAction(e))),e.addEventListener("touchmove",(e=>this._fireTouchAction(e))),e.addEventListener("mousedown",(e=>e.preventDefault())),e.addEventListener("vaadin-overlay-outside-click",(e=>{e.preventDefault()}))}disconnectedCallback(){super.disconnectedCallback(),this._overlayOpened=!1}_fireTouchAction(e){this.dispatchEvent(new CustomEvent("vaadin-overlay-touch-action",{detail:{sourceEvent:e}}))}_forwardScrollerEvent(e){this.dispatchEvent(new CustomEvent(e.type,{detail:e.detail}))}_openedChanged(e,t){e?(this._scroller.style.maxHeight=getComputedStyle(this).getPropertyValue(`--${this.__hostTagName}-overlay-max-height`)||"65vh",this.dispatchEvent(new CustomEvent("vaadin-combo-box-dropdown-opened",{bubbles:!0,composed:!0}))):t&&!this.__emptyItems&&this.dispatchEvent(new CustomEvent("vaadin-combo-box-dropdown-closed",{bubbles:!0,composed:!0}))}_openedOrItemsChanged(e,t,i){const a=t&&t.length;a||(this.__emptyItems=!0),this._overlayOpened=!(!e||!i&&!a),this.__emptyItems=!1}_getFocusedItem(e){if(e>=0)return this._items[e]}indexOfLabel(e){if(this._items&&e)for(let t=0;t<this._items.length;t++)if(this.getItemLabel(this._items[t]).toString().toLowerCase()===e.toString().toLowerCase())return t;return-1}getItemLabel(e,t){t=t||this._itemLabelPath;let i=e&&t?this.get(t,e):void 0;return null==i&&(i=e?e.toString():""),i}_scrollIntoView(e){this._scroller&&this._scroller.scrollIntoView(e)}adjustScrollPosition(){this.opened&&this._items&&this._scrollIntoView(this._focusedIndex)}__updateScroller(e,t,i,a,n,o,s,r,l){e&&e.setProperties({items:i?t:[],opened:i,loading:a,selectedItem:n,itemIdPath:o,focusedIndex:s,renderer:r,theme:l})}_isOverlayHidden(){return!(this.loading||this._items&&this._items.length)}}customElements.define(Or.is,Or);const Mr=e=>class extends e{static get properties(){return{pageSize:{type:Number,value:50,observer:"_pageSizeChanged"},size:{type:Number,observer:"_sizeChanged"},dataProvider:{type:Object,observer:"_dataProviderChanged"},_pendingRequests:{value:()=>({})},__placeHolder:{value:new Tr},__previousDataProviderFilter:{type:String}}}static get observers(){return["_dataProviderFilterChanged(filter)","_warnDataProviderValue(dataProvider, value)","_ensureFirstPage(opened)"]}ready(){super.ready(),this.$.dropdown.addEventListener("index-requested",(e=>{const t=e.detail.index,i=e.detail.currentScrollerPos,a=Math.floor(1.5*this.pageSize);if(!this._shouldSkipIndex(t,a,i)&&void 0!==t){const e=this._getPageForIndex(t);this._shouldLoadPage(e)&&this._loadPage(e)}}))}_dataProviderFilterChanged(e){void 0!==this.__previousDataProviderFilter||""!==e?this.__previousDataProviderFilter!==e&&(this.__previousDataProviderFilter=e,this._pendingRequests={},this.loading=this._shouldFetchData(),this.size=void 0,this.clearCache()):this.__previousDataProviderFilter=e}_shouldFetchData(){return!!this.dataProvider&&(this.opened||this.filter&&this.filter.length)}_ensureFirstPage(e){e&&this._shouldLoadPage(0)&&this._loadPage(0)}_shouldSkipIndex(e,t,i){return 0!==i&&e>=i-t&&e<=i+t}_shouldLoadPage(e){if(!this.filteredItems||this._forceNextRequest)return this._forceNextRequest=!1,!0;const t=this.filteredItems[e*this.pageSize];return void 0!==t?t instanceof Tr:void 0===this.size}_loadPage(e){if(!this._pendingRequests[e]&&this.dataProvider){this.loading=!0;const t={page:e,pageSize:this.pageSize,filter:this.filter},i=(a,n)=>{if(this._pendingRequests[e]===i){const i=this.filteredItems?[...this.filteredItems]:[];i.splice(t.page*t.pageSize,a.length,...a),this.filteredItems=i,this._isValidValue(this.value)&&this._getItemValue(this.selectedItem)!==this.value&&this._selectItemForValue(this.value),this.opened||this.hasAttribute("focused")||this._commitValue(),this.size=n,delete this._pendingRequests[e],0===Object.keys(this._pendingRequests).length&&(this.loading=!1)}};this._pendingRequests[e]||(this._pendingRequests[e]=i,this.dataProvider(t,i))}}_getPageForIndex(e){return Math.floor(e/this.pageSize)}clearCache(){if(!this.dataProvider)return;this._pendingRequests={};const e=[];for(let t=0;t<(this.size||0);t++)e.push(this.__placeHolder);this.filteredItems=e,this._shouldFetchData()?(this._forceNextRequest=!1,this._loadPage(0)):this._forceNextRequest=!0}_sizeChanged(e=0){const t=(this.filteredItems||[]).slice(0,e);for(let i=0;i<e;i++)t[i]=void 0!==t[i]?t[i]:this.__placeHolder;this.filteredItems=t,this._flushPendingRequests(e)}_pageSizeChanged(e,t){if(Math.floor(e)!==e||e<1)throw this.pageSize=t,new Error("`pageSize` value must be an integer > 0");this.clearCache()}_dataProviderChanged(e,t){this._ensureItemsOrDataProvider((()=>{this.dataProvider=t})),this.clearCache()}_ensureItemsOrDataProvider(e){if(void 0!==this.items&&void 0!==this.dataProvider)throw e(),new Error("Using `items` and `dataProvider` together is not supported");this.dataProvider&&!this.filteredItems&&(this.filteredItems=[])}_warnDataProviderValue(e,t){if(e&&""!==t&&(void 0===this.selectedItem||null===this.selectedItem)){const e=this._indexOfValue(t,this.filteredItems);(e<0||!this._getItemLabel(this.filteredItems[e]))&&console.warn("Warning: unable to determine the label for the provided `value`. Nothing to display in the text field. This usually happens when setting an initial `value` before any items are returned from the `dataProvider` callback. Consider setting `selectedItem` instead of `value`")}}_flushPendingRequests(e){if(this._pendingRequests){const t=Math.ceil(e/this.pageSize),i=Object.keys(this._pendingRequests);for(let a=0;a<i.length;a++){const n=parseInt(i[a]);n>=t&&this._pendingRequests[n]([],e)}}}},Pr=l((e=>class extends e{static get properties(){return{disabled:{type:Boolean,value:!1,observer:"_disabledChanged",reflectToAttribute:!0}}}_disabledChanged(e){this._setAriaDisabled(e)}_setAriaDisabled(e){e?this.setAttribute("aria-disabled","true"):this.removeAttribute("aria-disabled")}click(){this.disabled||super.click()}})),Fr=l((e=>class extends e{ready(){super.ready(),this.addEventListener("keydown",(e=>{this._onKeyDown(e)})),this.addEventListener("keyup",(e=>{this._onKeyUp(e)}))}_onKeyDown(e){switch(e.key){case"Enter":this._onEnter(e);break;case"Escape":this._onEscape(e)}}_onKeyUp(e){}_onEnter(e){}_onEscape(e){}}));const Dr=l((e=>class extends e{static get properties(){return{inputElement:{type:Object,readOnly:!0,observer:"_inputElementChanged"},type:{type:String,readOnly:!0},value:{type:String,value:"",observer:"_valueChanged",notify:!0}}}constructor(){super(),this._boundOnInput=this._onInput.bind(this),this._boundOnChange=this._onChange.bind(this)}clear(){this.value=""}_addInputListeners(e){e.addEventListener("input",this._boundOnInput),e.addEventListener("change",this._boundOnChange)}_removeInputListeners(e){e.removeEventListener("input",this._boundOnInput),e.removeEventListener("change",this._boundOnChange)}_forwardInputValue(e){this.inputElement&&(this.inputElement.value=null!=e?e:"")}_inputElementChanged(e,t){e?this._addInputListeners(e):t&&this._removeInputListeners(t)}_onInput(e){this.__userInput=e.isTrusted,this.value=e.target.value,this.__userInput=!1}_onChange(e){}_toggleHasValue(e){this.toggleAttribute("has-value",e)}_valueChanged(e,t){this._toggleHasValue(""!==e&&null!=e),""===e&&void 0===t||this.__userInput||this._forwardInputValue(e)}}));class Br{constructor(e){this.host=e,e.addEventListener("opened-changed",(()=>{e.opened||this.__setVirtualKeyboardEnabled(!1)})),e.addEventListener("blur",(()=>this.__setVirtualKeyboardEnabled(!0))),e.addEventListener("touchstart",(()=>this.__setVirtualKeyboardEnabled(!0)))}__setVirtualKeyboardEnabled(e){this.host.inputElement&&(this.host.inputElement.inputMode=e?"":"none")}}const Nr=e=>class extends(Rs(Fr(Dr(Pr(e))))){static get properties(){return{opened:{type:Boolean,notify:!0,value:!1,reflectToAttribute:!0,observer:"_openedChanged"},autoOpenDisabled:{type:Boolean},readonly:{type:Boolean,value:!1,reflectToAttribute:!0},renderer:Function,items:{type:Array,observer:"_itemsChanged"},allowCustomValue:{type:Boolean,value:!1},filteredItems:{type:Array},_lastCommittedValue:String,loading:{type:Boolean,value:!1,reflectToAttribute:!0,observer:"_loadingChanged"},_focusedIndex:{type:Number,observer:"_focusedIndexChanged",value:-1},filter:{type:String,value:"",notify:!0},selectedItem:{type:Object,notify:!0},itemLabelPath:{type:String,value:"label",observer:"_itemLabelPathChanged"},itemValuePath:{type:String,value:"value"},itemIdPath:String,_toggleElement:{type:Object,observer:"_toggleElementChanged"},_closeOnBlurIsPrevented:Boolean,__restoreFocusOnClose:Boolean}}static get observers(){return["_filterChanged(filter, itemValuePath, itemLabelPath)","_filteredItemsChanged(filteredItems)","_selectedItemChanged(selectedItem, itemValuePath, itemLabelPath)"]}constructor(){super(),this._boundOnFocusout=this._onFocusout.bind(this),this._boundOverlaySelectedItemChanged=this._overlaySelectedItemChanged.bind(this),this._boundOnClearButtonMouseDown=this.__onClearButtonMouseDown.bind(this),this._boundClose=this.close.bind(this),this._boundOnOpened=this._onOpened.bind(this),this._boundOnClick=this._onClick.bind(this),this._boundOnOverlayTouchAction=this._onOverlayTouchAction.bind(this),this._boundOnTouchend=this._onTouchend.bind(this)}get _inputElementValue(){return this.inputElement?this.inputElement[this._propertyForValue]:void 0}set _inputElementValue(e){this.inputElement&&(this.inputElement[this._propertyForValue]=e)}get _nativeInput(){return this.inputElement}_inputElementChanged(e){super._inputElementChanged(e);const t=this._nativeInput;t&&(t.autocomplete="off",t.autocapitalize="off",t.setAttribute("role","combobox"),t.setAttribute("aria-autocomplete","list"),t.setAttribute("aria-expanded",!!this.opened),t.setAttribute("spellcheck","false"),t.setAttribute("autocorrect","off"),this._revertInputValueToValue(),this.clearElement&&this.clearElement.addEventListener("mousedown",this._boundOnClearButtonMouseDown))}ready(){super.ready(),this.addEventListener("focusout",this._boundOnFocusout),this._lastCommittedValue=this.value,this.$.dropdown.addEventListener("selection-changed",this._boundOverlaySelectedItemChanged),this.addEventListener("vaadin-combo-box-dropdown-closed",this._boundClose),this.addEventListener("vaadin-combo-box-dropdown-opened",this._boundOnOpened),this.addEventListener("click",this._boundOnClick),this.$.dropdown.addEventListener("vaadin-overlay-touch-action",this._boundOnOverlayTouchAction),this.addEventListener("touchend",this._boundOnTouchend);const e=()=>{requestAnimationFrame((()=>{this.$.dropdown.$.overlay.bringToFront()}))};var t;this.addEventListener("mousedown",e),this.addEventListener("touchstart",e),t=this,window.Vaadin&&window.Vaadin.templateRendererCallback?window.Vaadin.templateRendererCallback(t):t.querySelector("template")&&console.warn(`WARNING: <template> inside <${t.localName}> is no longer supported. Import @vaadin/polymer-legacy-adapter/template-renderer.js to enable compatibility.`),this.addController(new Br(this))}requestContentUpdate(){this.$.dropdown._scroller&&(this.$.dropdown._scroller.requestContentUpdate(),this._getItemElements().forEach((e=>{e.requestContentUpdate()})))}open(){this.disabled||this.readonly||(this.opened=!0)}close(){this.opened=!1}_focusedIndexChanged(e,t){void 0!==t&&this._updateActiveDescendant(e)}_updateActiveDescendant(e){const t=this._nativeInput;if(!t)return;const i=this._getItemElements().find((t=>t.index===e));i?t.setAttribute("aria-activedescendant",i.id):t.removeAttribute("aria-activedescendant")}_openedChanged(e,t){if(void 0===t)return;e?(this._openedWithFocusRing=this.hasAttribute("focus-ring"),this.hasAttribute("focused")||js||this.focus(),this.__restoreFocusOnClose=!0):(this._onClosed(),this._openedWithFocusRing&&this.hasAttribute("focused")&&this.setAttribute("focus-ring",""));const i=this._nativeInput;i&&(i.setAttribute("aria-expanded",!!e),e?i.setAttribute("aria-controls",this.$.dropdown.scrollerId):i.removeAttribute("aria-controls"))}_onOverlayTouchAction(){this._closeOnBlurIsPrevented=!0,this.inputElement.blur(),this._closeOnBlurIsPrevented=!1}_isClearButton(e){return e.composedPath()[0]===this.clearElement}_handleClearButtonClick(e){e.preventDefault(),this._clear(),this.opened&&this.requestContentUpdate()}_onToggleButtonClick(e){e.preventDefault(),this.opened?this.close():this.open()}_onHostClick(e){this.autoOpenDisabled||(e.preventDefault(),this.open())}_onClick(e){this._closeOnBlurIsPrevented=!0;const t=e.composedPath();this._isClearButton(e)?this._handleClearButtonClick(e):t.indexOf(this._toggleElement)>-1?this._onToggleButtonClick(e):this._onHostClick(e),this._closeOnBlurIsPrevented=!1}_onKeyDown(e){super._onKeyDown(e),"Tab"===e.key?this.__restoreFocusOnClose=!1:"ArrowDown"===e.key?(this._closeOnBlurIsPrevented=!0,this._onArrowDown(),this._closeOnBlurIsPrevented=!1,e.preventDefault()):"ArrowUp"===e.key&&(this._closeOnBlurIsPrevented=!0,this._onArrowUp(),this._closeOnBlurIsPrevented=!1,e.preventDefault())}_getItemLabel(e){return this.$.dropdown.getItemLabel(e)}_getItemValue(e){let t=e&&this.itemValuePath?this.get(this.itemValuePath,e):void 0;return void 0===t&&(t=e?e.toString():""),t}_onArrowDown(){if(this.opened){const e=this._getOverlayItems();e&&(this._focusedIndex=Math.min(e.length-1,this._focusedIndex+1),this._prefillFocusedItemLabel())}else this.open()}_onArrowUp(){if(this.opened){if(this._focusedIndex>-1)this._focusedIndex=Math.max(0,this._focusedIndex-1);else{const e=this._getOverlayItems();e&&(this._focusedIndex=e.length-1)}this._prefillFocusedItemLabel()}else this.open()}_prefillFocusedItemLabel(){this._focusedIndex>-1&&(this._inputElementValue=this._getItemLabel(this.$.dropdown.focusedItem),this._markAllSelectionRange())}_setSelectionRange(e,t){this.hasAttribute("focused")&&this.inputElement.setSelectionRange(e,t)}_markAllSelectionRange(){void 0!==this._inputElementValue&&this._setSelectionRange(0,this._inputElementValue.length)}_clearSelectionRange(){if(void 0!==this._inputElementValue){const e=this._inputElementValue?this._inputElementValue.length:0;this._setSelectionRange(e,e)}}_closeOrCommit(){this.opened||this.loading?this.close():this._commitValue()}_onEnter(e){if(!this.allowCustomValue&&""!==this._inputElementValue&&this._focusedIndex<0)return e.preventDefault(),void e.stopPropagation();this.opened&&(e.preventDefault(),e.stopPropagation()),this._closeOrCommit()}_onEscape(e){this.autoOpenDisabled?this.opened||this.value!==this._inputElementValue&&this._inputElementValue.length>0?(e.stopPropagation(),this._focusedIndex=-1,this.cancel()):this.clearButtonVisible&&!this.opened&&this.value&&(e.stopPropagation(),this._clear()):this.opened?(e.stopPropagation(),this._focusedIndex>-1?(this._focusedIndex=-1,this._revertInputValue()):this.cancel()):this.clearButtonVisible&&this.value&&(e.stopPropagation(),this._clear())}_toggleElementChanged(e){e&&(e.addEventListener("mousedown",(e=>e.preventDefault())),e.addEventListener("click",(()=>{js&&!this.hasAttribute("focused")&&document.activeElement.blur()})))}_clear(){this.selectedItem=null,this.allowCustomValue&&(this.value=""),this._detectAndDispatchChange()}cancel(){this._revertInputValueToValue(),this._lastCommittedValue=this.value,this._closeOrCommit()}_onOpened(){requestAnimationFrame((()=>{this.$.dropdown.adjustScrollPosition(),this._updateActiveDescendant(this._focusedIndex)})),this._lastCommittedValue=this.value}_onClosed(){this.loading&&!this.allowCustomValue||this._commitValue()}_commitValue(){const e=this._getOverlayItems();if(e&&this._focusedIndex>-1){const t=e[this._focusedIndex];this.selectedItem!==t&&(this.selectedItem=t),this._inputElementValue=this._getItemLabel(this.selectedItem)}else if(""===this._inputElementValue||void 0===this._inputElementValue)this.selectedItem=null,this.allowCustomValue&&(this.value="");else{const e=e=>e&&e.toLowerCase&&e.toLowerCase(),t=[...this.filteredItems||[],this.selectedItem].find((t=>e(this._getItemLabel(t))===e(this._inputElementValue)));if(this.allowCustomValue&&!t){const e=this._inputElementValue;this._lastCustomValue=e;const t=new CustomEvent("custom-value-set",{detail:e,composed:!0,cancelable:!0,bubbles:!0});this.dispatchEvent(t),t.defaultPrevented||(this._selectItemForValue(e),this.value=e)}else this.allowCustomValue||this.opened||!t?this._inputElementValue=this.selectedItem?this._getItemLabel(this.selectedItem):this.value||"":this.value=this._getItemValue(t)}this._detectAndDispatchChange(),this._clearSelectionRange(),this.filter=""}get _propertyForValue(){return"value"}_onInput(e){this.opened||this._isClearButton(e)||this.autoOpenDisabled||this.open();const t=this._inputElementValue;this.filter===t?this._filterChanged(this.filter,this.itemValuePath,this.itemLabelPath):this.filter=t}_onChange(e){e.stopPropagation()}_itemLabelPathChanged(e){"string"!=typeof e&&console.error("You should set itemLabelPath to a valid string")}_filterChanged(e,t,i){void 0!==e&&(this.$.dropdown._scrollIntoView(0),this.items?this.filteredItems=this._filterItems(this.items,e):this._filteredItemsChanged(this.filteredItems))}_loadingChanged(e){e&&(this._focusedIndex=-1)}_revertInputValue(){""!==this.filter?this._inputElementValue=this.filter:this._revertInputValueToValue(),this._clearSelectionRange()}_revertInputValueToValue(){this.allowCustomValue&&!this.selectedItem?this._inputElementValue=this.value:this._inputElementValue=this._getItemLabel(this.selectedItem)}_selectedItemChanged(e){if(null==e)this.filteredItems&&(this.allowCustomValue||(this.value=""),this._toggleHasValue(""!==this.value),this._inputElementValue=this.value);else{const t=this._getItemValue(e);if(this.value!==t&&(this.value=t,this.value!==t))return;this._toggleHasValue(!0),this._inputElementValue=this._getItemLabel(e)}this.$.dropdown._selectedItem=e;const t=this._getOverlayItems();this.filteredItems&&t&&(this._focusedIndex=this.filteredItems.indexOf(e))}_valueChanged(e,t){""===e&&void 0===t||(this._isValidValue(e)?(this._getItemValue(this.selectedItem)!==e&&this._selectItemForValue(e),!this.selectedItem&&this.allowCustomValue&&(this._inputElementValue=e),this._toggleHasValue(""!==this.value)):this.selectedItem=null,this.filter="",this._lastCommittedValue=void 0)}_detectAndDispatchChange(){this.value!==this._lastCommittedValue&&(this.dispatchEvent(new CustomEvent("change",{bubbles:!0})),this._lastCommittedValue=this.value)}_itemsChanged(e,t){this._ensureItemsOrDataProvider((()=>{this.items=t})),e?this.filteredItems=e.slice(0):this.__previousItems&&(this.filteredItems=null);const i=this._indexOfValue(this.value,e);this._focusedIndex=i;const a=i>-1&&e[i];a&&(this.selectedItem=a),this.__previousItems=e}_filteredItemsChanged(e,t,i){this._setOverlayItems(e);const a=this._indexOfValue(this.value,e);null===this.selectedItem&&a>=0&&this._selectItemForValue(this.value);const n=this._inputElementValue;void 0===n||n===this._getItemLabel(this.selectedItem)?this._focusedIndex=this.$.dropdown.indexOfLabel(this._getItemLabel(this.selectedItem)):this._focusedIndex=this.$.dropdown.indexOfLabel(this.filter)}_filterItems(e,t){if(!e)return e;const i=e.filter((e=>(t=t?t.toString().toLowerCase():"",this._getItemLabel(e).toString().toLowerCase().indexOf(t)>-1)));return i}_selectItemForValue(e){const t=this._indexOfValue(e,this.filteredItems),i=this.selectedItem;t>=0?this.selectedItem=this.filteredItems[t]:this.dataProvider&&void 0===this.selectedItem?this.selectedItem=void 0:this.selectedItem=null,null===this.selectedItem&&null===i&&this._selectedItemChanged(this.selectedItem)}_getItemElements(){return Array.from(this.$.dropdown._scroller.querySelectorAll("vaadin-combo-box-item"))}_getOverlayItems(){return this.$.dropdown._items}_setOverlayItems(e){this.$.dropdown.set("_items",e)}_indexOfValue(e,t){return t&&this._isValidValue(e)?t.findIndex((t=>!(t instanceof Tr)&&this._getItemValue(t)===e)):-1}_isValidValue(e){return null!=e}_overlaySelectedItemChanged(e){e.stopPropagation(),e.detail.item instanceof Tr||(this.opened?(this._focusedIndex=this.filteredItems.indexOf(e.detail.item),this.close()):this.selectedItem!==e.detail.item&&(this.selectedItem=e.detail.item,this._detectAndDispatchChange()))}__onClearButtonMouseDown(e){e.preventDefault(),this.inputElement.focus()}_onFocusout(e){if(!e.relatedTarget||!this._getItemElements().includes(e.relatedTarget))if(e.relatedTarget!==this.$.dropdown.$.overlay){if(!this.readonly&&!this._closeOnBlurIsPrevented){if(!this.opened&&this.allowCustomValue&&this._inputElementValue===this._lastCustomValue)return void delete this._lastCustomValue;this._closeOrCommit()}}else e.composedPath()[0].focus()}_onTouchend(e){this.clearElement&&e.composedPath()[0]===this.clearElement&&(e.preventDefault(),this._clear())}validate(){return!(this.invalid=!this.checkValidity())}checkValidity(){return super.checkValidity?super.checkValidity():!this.required||!!this.value}};class Vr extends(Mr(Nr(zs(d)))){static get is(){return"vaadin-combo-box-light"}static get template(){return c`
      <style>
        :host([opened]) {
          pointer-events: auto;
        }
      </style>

      <slot></slot>

      <vaadin-combo-box-dropdown
        id="dropdown"
        opened="[[opened]]"
        position-target="[[inputElement]]"
        restore-focus-on-close="[[__restoreFocusOnClose]]"
        restore-focus-node="[[inputElement]]"
        renderer="[[renderer]]"
        _focused-index="[[_focusedIndex]]"
        _item-id-path="[[itemIdPath]]"
        _item-label-path="[[itemLabelPath]]"
        loading="[[loading]]"
        theme="[[_theme]]"
      ></vaadin-combo-box-dropdown>
    `}static get properties(){return{attrForValue:{type:String,value:"value"}}}get clearElement(){return this.querySelector(".clear-button")}ready(){super.ready(),this._toggleElement=this.querySelector(".toggle-button"),Dn(this,(()=>{this._setInputElement(this.querySelector("vaadin-text-field,.input")),this._revertInputValue()}))}checkValidity(){return this.inputElement.validate?this.inputElement.validate():super.checkValidity()}get _propertyForValue(){return p(this.attrForValue)}get _nativeInput(){const e=this.inputElement;if(e){if(e instanceof HTMLInputElement)return e;const t=e.querySelector("input");if(t)return t;if(e.shadowRoot){const t=e.shadowRoot.querySelector("input");if(t)return t}}}_isClearButton(e){return super._isClearButton(e)||"input"===e.type&&!e.isTrusted||"clear-button"===e.composedPath()[0].getAttribute("part")}_onChange(e){super._onChange(e),this._isClearButton(e)&&this._clear()}}customElements.define(Vr.is,Vr);const qr={};class jr extends t{constructor(e){if(super(e),this.previousValue=qr,e.type!==i.ELEMENT)throw new Error("renderer only supports binding to element")}render(e,t){return v}update(e,[t,i]){var a;const n=this.previousValue===qr;if(!this.hasChanged(i))return v;this.previousValue=Array.isArray(i)?Array.from(i):i;const o=e.element;if(n){const i=null===(a=e.options)||void 0===a?void 0:a.host;this.addRenderer(o,t,{host:i})}else this.runRenderer(o);return v}hasChanged(e){let t=!0;return Array.isArray(e)?Array.isArray(this.previousValue)&&this.previousValue.length===e.length&&e.every(((e,t)=>e===this.previousValue[t]))&&(t=!1):this.previousValue===e&&(t=!1),t}}const Rr=e(class extends jr{addRenderer(e,t,i){e.renderer=(e,a,n)=>{m(t.call(i.host,n.item,n,a),e,i)}}runRenderer(e){e.requestContentUpdate()}});$s("vaadin-combo-box-item",r`
    :host {
      padding: 0;
    }
    :host([focused]:not([disabled])) {
      background-color: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.12);
    }
    :host([selected]:not([disabled])) {
      background-color: transparent;
      color: var(--mdc-theme-primary);
      --mdc-ripple-color: var(--mdc-theme-primary);
      --mdc-theme-text-primary-on-background: var(--mdc-theme-primary);
    }
    :host([selected]:not([disabled])):before {
      background-color: var(--mdc-theme-primary);
      opacity: 0.12;
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }
    :host([selected][focused]:not([disabled])):before {
      opacity: 0.24;
    }
    :host(:hover:not([disabled])) {
      background-color: transparent;
    }
    [part="content"] {
      width: 100%;
    }
    [part="checkmark"] {
      display: none;
    }
  `),f([A("ha-combo-box")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"placeholder",value:void 0},{kind:"field",decorators:[_()],key:"validationMessage",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({attribute:"error-message"})],key:"errorMessage",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"invalid",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"icon",value:void 0},{kind:"field",decorators:[_()],key:"items",value:void 0},{kind:"field",decorators:[_()],key:"filteredItems",value:void 0},{kind:"field",decorators:[_({attribute:"allow-custom-value",type:Boolean})],key:"allowCustomValue",value:void 0},{kind:"field",decorators:[_({attribute:"item-value-path"})],key:"itemValuePath",value:void 0},{kind:"field",decorators:[_({attribute:"item-label-path"})],key:"itemLabelPath",value:void 0},{kind:"field",decorators:[_({attribute:"item-id-path"})],key:"itemIdPath",value:void 0},{kind:"field",decorators:[_()],key:"renderer",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0,attribute:"opened"})],key:"_opened",value:void 0},{kind:"field",decorators:[y("vaadin-combo-box-light",!0)],key:"_comboBox",value:void 0},{kind:"field",key:"_overlayMutationObserver",value:void 0},{kind:"method",key:"open",value:function(){this.updateComplete.then((()=>{var e;null===(e=this._comboBox)||void 0===e||e.open()}))}},{kind:"method",key:"focus",value:function(){this.updateComplete.then((()=>{var e,t;null===(e=this._comboBox)||void 0===e||null===(t=e.inputElement)||void 0===t||t.focus()}))}},{kind:"method",key:"disconnectedCallback",value:function(){k(b(i.prototype),"disconnectedCallback",this).call(this),this._overlayMutationObserver&&(this._overlayMutationObserver.disconnect(),this._overlayMutationObserver=void 0)}},{kind:"get",key:"selectedItem",value:function(){return this._comboBox.selectedItem}},{kind:"method",key:"setInputValue",value:function(e){this._comboBox.value=e}},{kind:"method",key:"render",value:function(){var e,t,i,a;return x`
      <vaadin-combo-box-light
        .itemValuePath=${this.itemValuePath}
        .itemIdPath=${this.itemIdPath}
        .itemLabelPath=${this.itemLabelPath}
        .items=${this.items}
        .value=${this.value||""}
        .filteredItems=${this.filteredItems}
        .allowCustomValue=${this.allowCustomValue}
        .disabled=${this.disabled}
        .required=${this.required}
        ${i=this.renderer||this._defaultRowRenderer,Rr(i,a)}
        @opened-changed=${this._openedChanged}
        @filter-changed=${this._filterChanged}
        @value-changed=${this._valueChanged}
        attr-for-value="value"
      >
        <ha-textfield
          .label=${this.label}
          .placeholder=${this.placeholder}
          .disabled=${this.disabled}
          .required=${this.required}
          .validationMessage=${this.validationMessage}
          .errorMessage=${this.errorMessage}
          class="input"
          autocapitalize="none"
          autocomplete="off"
          autocorrect="off"
          spellcheck="false"
          .suffix=${x`<div style="width: 28px;"></div>`}
          .icon=${this.icon}
          .invalid=${this.invalid}
          .helper=${this.helper}
          helperPersistent
        >
          <slot name="icon" slot="leadingIcon"></slot>
        </ha-textfield>
        ${this.value?x`<ha-svg-icon
              aria-label=${null===(e=this.hass)||void 0===e?void 0:e.localize("ui.components.combo-box.clear")}
              class="clear-button"
              .path=${$}
              @click=${this._clearValue}
            ></ha-svg-icon>`:""}
        <ha-svg-icon
          aria-label=${null===(t=this.hass)||void 0===t?void 0:t.localize("ui.components.combo-box.show")}
          class="toggle-button"
          .path=${this._opened?w:C}
          @click=${this._toggleOpen}
        ></ha-svg-icon>
      </vaadin-combo-box-light>
    `}},{kind:"field",key:"_defaultRowRenderer",value(){return e=>x`<mwc-list-item>
      ${this.itemLabelPath?e[this.itemLabelPath]:e}
    </mwc-list-item>`}},{kind:"method",key:"_clearValue",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:void 0})}},{kind:"method",key:"_toggleOpen",value:function(e){var t,i;this._opened?(null===(t=this._comboBox)||void 0===t||t.close(),e.stopPropagation()):null===(i=this._comboBox)||void 0===i||i.inputElement.focus()}},{kind:"method",key:"_openedChanged",value:function(e){const t=e.detail.value;if(setTimeout((()=>{this._opened=t}),0),o(this,e.type,e.detail),t&&"MutationObserver"in window&&!this._overlayMutationObserver){const e=document.querySelector("vaadin-combo-box-overlay");if(!e)return;this._overlayMutationObserver=new MutationObserver((t=>{t.forEach((t=>{var i;"attributes"===t.type&&"inert"===t.attributeName?(null===(i=this._overlayMutationObserver)||void 0===i||i.disconnect(),this._overlayMutationObserver=void 0,e.inert=!1):"childList"===t.type&&t.removedNodes.forEach((e=>{var t;"VAADIN-COMBO-BOX-OVERLAY"===e.nodeName&&(null===(t=this._overlayMutationObserver)||void 0===t||t.disconnect(),this._overlayMutationObserver=void 0)}))}))})),this._overlayMutationObserver.observe(e,{attributes:!0}),this._overlayMutationObserver.observe(document.body,{childList:!0})}}},{kind:"method",key:"_filterChanged",value:function(e){o(this,e.type,e.detail,{composed:!1})}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;t!==this.value&&o(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      :host {
        display: block;
        width: 100%;
      }
      vaadin-combo-box-light {
        position: relative;
      }
      ha-textfield {
        width: 100%;
      }
      ha-textfield > ha-icon-button {
        --mdc-icon-button-size: 24px;
        padding: 2px;
        color: var(--secondary-text-color);
      }
      ha-svg-icon {
        color: var(--input-dropdown-icon-color);
        position: absolute;
        cursor: pointer;
      }
      .toggle-button {
        right: 12px;
        top: -10px;
        inset-inline-start: initial;
        inset-inline-end: 12px;
        direction: var(--direction);
      }
      :host([opened]) .toggle-button {
        color: var(--primary-color);
      }
      .clear-button {
        --mdc-icon-size: 20px;
        top: -7px;
        right: 36px;
        inset-inline-start: initial;
        inset-inline-end: 36px;
        direction: var(--direction);
      }
    `}}]}}),g);const Ur=["unavailable","unknown"],Hr=e=>gs(e.entity_id),Gr=r`
  ha-state-icon[data-domain="alert"][data-state="on"],
  ha-state-icon[data-domain="automation"][data-state="on"],
  ha-state-icon[data-domain="binary_sensor"][data-state="on"],
  ha-state-icon[data-domain="calendar"][data-state="on"],
  ha-state-icon[data-domain="camera"][data-state="streaming"],
  ha-state-icon[data-domain="cover"][data-state="open"],
  ha-state-icon[data-domain="device_tracker"][data-state="home"],
  ha-state-icon[data-domain="fan"][data-state="on"],
  ha-state-icon[data-domain="humidifier"][data-state="on"],
  ha-state-icon[data-domain="light"][data-state="on"],
  ha-state-icon[data-domain="input_boolean"][data-state="on"],
  ha-state-icon[data-domain="lock"][data-state="unlocked"],
  ha-state-icon[data-domain="media_player"][data-state="on"],
  ha-state-icon[data-domain="media_player"][data-state="paused"],
  ha-state-icon[data-domain="media_player"][data-state="playing"],
  ha-state-icon[data-domain="remote"][data-state="on"],
  ha-state-icon[data-domain="script"][data-state="on"],
  ha-state-icon[data-domain="sun"][data-state="above_horizon"],
  ha-state-icon[data-domain="switch"][data-state="on"],
  ha-state-icon[data-domain="timer"][data-state="active"],
  ha-state-icon[data-domain="vacuum"][data-state="cleaning"],
  ha-state-icon[data-domain="group"][data-state="on"],
  ha-state-icon[data-domain="group"][data-state="home"],
  ha-state-icon[data-domain="group"][data-state="open"],
  ha-state-icon[data-domain="group"][data-state="locked"],
  ha-state-icon[data-domain="group"][data-state="problem"] {
    color: var(--paper-item-icon-active-color, #fdd835);
  }

  ha-state-icon[data-domain="climate"][data-state="cooling"] {
    color: var(--cool-color, var(--state-climate-cool-color));
  }

  ha-state-icon[data-domain="climate"][data-state="heating"] {
    color: var(--heat-color, var(--state-climate-heat-color));
  }

  ha-state-icon[data-domain="climate"][data-state="drying"] {
    color: var(--dry-color, var(--state-climate-dry-color));
  }

  ha-state-icon[data-domain="alarm_control_panel"] {
    color: var(--alarm-color-armed, var(--label-badge-red));
  }
  ha-state-icon[data-domain="alarm_control_panel"][data-state="disarmed"] {
    color: var(--alarm-color-disarmed, var(--label-badge-green));
  }
  ha-state-icon[data-domain="alarm_control_panel"][data-state="pending"],
  ha-state-icon[data-domain="alarm_control_panel"][data-state="arming"] {
    color: var(--alarm-color-pending, var(--label-badge-yellow));
    animation: pulse 1s infinite;
  }
  ha-state-icon[data-domain="alarm_control_panel"][data-state="triggered"] {
    color: var(--alarm-color-triggered, var(--label-badge-red));
    animation: pulse 1s infinite;
  }

  @keyframes pulse {
    0% {
      opacity: 1;
    }
    50% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }

  ha-state-icon[data-domain="plant"][data-state="problem"] {
    color: var(--state-icon-error-color);
  }

  /* Color the icon if unavailable */
  ha-state-icon[data-state="unavailable"] {
    color: var(--state-unavailable-color);
  }
`,Wr=(e,t)=>e.callWS({type:"auth/sign_path",path:t}),Kr=I,Yr={alert:E,air_quality:z,automation:S,calendar:T,camera:L,climate:O,configurator:M,conversation:P,counter:F,demo:D,fan:B,google_assistant:N,group:V,homeassistant:D,homekit:q,image_processing:j,input_button:R,input_datetime:U,input_number:H,input_select:G,input_text:W,light:K,mailbox:Y,notify:Z,number:H,persistent_notification:Q,person:J,plant:X,proximity:ee,remote:te,scene:ie,script:ae,select:G,sensor:ne,siren:oe,simple_alarm:Q,sun:se,timer:re,updater:le,vacuum:de,water_heater:ce,weather:ue,zone:he},Zr={apparent_power:pe,aqi:z,carbon_dioxide:ve,carbon_monoxide:me,current:fe,date:T,energy:ge,frequency:_e,gas:ye,humidity:ke,illuminance:be,monetary:xe,nitrogen_dioxide:$e,nitrogen_monoxide:$e,nitrous_oxide:$e,ozone:$e,pm1:$e,pm10:$e,pm25:$e,power:pe,power_factor:we,pressure:Ce,reactive_power:pe,signal_strength:Ae,sulphur_dioxide:$e,temperature:ce,timestamp:Ie,volatile_organic_compounds:$e,voltage:_e},Qr=(e,t)=>0!=(e.supported_features&t),Jr=e=>Qr(e,4)&&"number"==typeof e.in_progress,Xr=e=>(e=>Jr(e.attributes))(e)||!!e.attributes.in_progress,el={"clear-night":ze,cloudy:ue,exceptional:Se,fog:Te,hail:Le,lightning:Oe,"lightning-rainy":Me,partlycloudy:Pe,pouring:Fe,rainy:De,snowy:Be,"snowy-rainy":Ne,sunny:Ve,windy:qe,"windy-variant":je};r`
  .rain {
    fill: var(--weather-icon-rain-color, #30b3ff);
  }
  .sun {
    fill: var(--weather-icon-sun-color, #fdd93c);
  }
  .moon {
    fill: var(--weather-icon-moon-color, #fcf497);
  }
  .cloud-back {
    fill: var(--weather-icon-cloud-back-color, #d4d4d4);
  }
  .cloud-front {
    fill: var(--weather-icon-cloud-front-color, #f9f9f9);
  }
`;const tl={10:oi,20:si,30:ri,40:li,50:di,60:ci,70:ui,80:hi,90:pi,100:Dt},il={10:vi,20:mi,30:fi,40:gi,50:_i,60:yi,70:ki,80:bi,90:xi,100:Bt},al=(e,t)=>{const i=Number(e);if(isNaN(i))return"off"===e?Dt:"on"===e?ti:ii;const a=10*Math.round(i/10);return t&&i>=10?il[a]:t?ai:i<=5?ni:tl[a]},nl=e=>{const t=null==e?void 0:e.attributes.device_class;if(t&&t in Zr)return Zr[t];if("battery"===t)return e?((e,t)=>{const i=e.state,a=t&&"on"===t.state;return al(i,a)})(e):Dt;const i=null==e?void 0:e.attributes.unit_of_measurement;return"°C"===i||"°F"===i?ce:void 0},ol=(e,t,i)=>{const a=void 0!==i?i:null==t?void 0:t.state;switch(e){case"alarm_control_panel":return(e=>{switch(e){case"armed_away":return Qe;case"armed_vacation":return Ze;case"armed_home":return Ye;case"armed_night":return Ke;case"armed_custom_bypass":return We;case"pending":return Ge;case"triggered":return He;case"disarmed":return Ue;default:return Re}})(a);case"binary_sensor":return((e,t)=>{const i="off"===e;switch(null==t?void 0:t.attributes.device_class){case"battery":return i?Dt:Nt;case"battery_charging":return i?Dt:Bt;case"carbon_monoxide":return i?Pt:Ft;case"cold":return i?ce:Mt;case"connectivity":return i?Lt:Ot;case"door":return i?St:Tt;case"garage_door":return i?Et:zt;case"power":case"plug":return i?ht:pt;case"gas":case"problem":case"safety":case"tamper":return i?At:It;case"smoke":return i?wt:Ct;case"heat":return i?ce:$t;case"light":return i?be:xt;case"lock":return i?kt:bt;case"moisture":return i?_t:yt;case"motion":return i?ft:gt;case"occupancy":case"presence":return i?ct:ut;case"opening":return i?vt:mt;case"running":return i?lt:dt;case"sound":return i?st:rt;case"update":return i?nt:ot;case"vibration":return i?it:at;case"window":return i?et:tt;default:return i?Je:Xe}})(a,t);case"button":switch(null==t?void 0:t.attributes.device_class){case"restart":return Zi;case"update":return ot;default:return R}case"cover":return((e,t)=>{const i="closed"!==e;switch(null==t?void 0:t.attributes.device_class){case"garage":switch(e){case"opening":return qt;case"closing":return Vt;case"closed":return Et;default:return zt}case"gate":switch(e){case"opening":case"closing":return ei;case"closed":return Xt;default:return Jt}case"door":return i?Tt:St;case"damper":return i?Zt:Qt;case"shutter":switch(e){case"opening":return qt;case"closing":return Vt;case"closed":return Yt;default:return Kt}case"curtain":switch(e){case"opening":return Wt;case"closing":return Gt;case"closed":return Ht;default:return Ut}case"blind":case"shade":switch(e){case"opening":return qt;case"closing":return Vt;case"closed":return Rt;default:return jt}case"window":switch(e){case"opening":return qt;case"closing":return Vt;case"closed":return et;default:return tt}}switch(e){case"opening":return qt;case"closing":return Vt;case"closed":return et;default:return tt}})(a,t);case"device_tracker":return"router"===(null==t?void 0:t.attributes.source_type)?"home"===a?Hi:Gi:["bluetooth","bluetooth_le"].includes(null==t?void 0:t.attributes.source_type)?"home"===a?Wi:Ki:"not_home"===a?Yi:J;case"humidifier":return i&&"off"===i?Ri:Ui;case"input_boolean":return"on"===a?qi:ji;case"input_datetime":if(null==t||!t.attributes.has_date)return Ie;if(!t.attributes.has_time)return T;break;case"lock":switch(a){case"unlocked":return bt;case"jammed":return Vi;case"locking":case"unlocking":return Ni;default:return kt}case"media_player":switch(null==t?void 0:t.attributes.device_class){case"speaker":switch(a){case"playing":return Bi;case"paused":return Di;case"off":return Fi;default:return Pi}case"tv":switch(a){case"playing":return Mi;case"paused":return Oi;case"off":return Li;default:return Ti}default:switch(a){case"playing":case"paused":return Si;case"off":return zi;default:return Ei}}case"switch":switch(null==t?void 0:t.attributes.device_class){case"outlet":return"on"===a?pt:ht;case"switch":return"on"===a?Ai:Ii;default:return Ai}case"sensor":{const e=nl(t);if(e)return e;break}case"sun":return"above_horizon"===(null==t?void 0:t.state)?Yr[e]:ze;case"switch_as_x":return Ci;case"threshold":return wi;case"update":return"on"===a?Xr(t)?$i:ot:nt;case"weather":return((e,t)=>e?t&&"partlycloudy"===e?Ee:el[e]:void 0)(null==t?void 0:t.state)}if(e in Yr)return Yr[e]},sl=e=>e?((e,t,i)=>ol(e,t,i)||(console.warn(`Unable to find icon for domain ${e}`),Kr))(gs(e.entity_id),e):Kr;f([A("ha-state-icon")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"state",value:void 0},{kind:"field",decorators:[_()],key:"icon",value:void 0},{kind:"method",key:"render",value:function(){var e,t;return this.icon||null!==(e=this.state)&&void 0!==e&&e.attributes.icon?x`<ha-icon
        .icon=${this.icon||(null===(t=this.state)||void 0===t?void 0:t.attributes.icon)}
      ></ha-icon>`:x`<ha-svg-icon .path=${sl(this.state)}></ha-svg-icon>`}}]}}),g);let rl=f(null,(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"stateObj",value:void 0},{kind:"field",decorators:[_()],key:"overrideIcon",value:void 0},{kind:"field",decorators:[_()],key:"overrideImage",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"stateColor",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0,attribute:"icon"})],key:"_showIcon",value:()=>!0},{kind:"field",decorators:[Qi()],key:"_iconStyle",value:()=>({})},{kind:"method",key:"render",value:function(){const e=this.stateObj;if(!e&&!this.overrideIcon&&!this.overrideImage)return x`<div class="missing">
        <ha-svg-icon .path=${E}></ha-svg-icon>
      </div>`;if(!this._showIcon)return x``;const t=e?Hr(e):void 0;return x`<ha-state-icon
      style=${Ji(this._iconStyle)}
      data-domain=${Xi(this.stateColor||"light"===t&&!1!==this.stateColor?t:void 0)}
      data-state=${e?(e=>{if(Ur.includes(e.state))return e.state;const t=e.entity_id.split(".")[0];let i=e.state;return"climate"===t&&(i=e.attributes.hvac_action),i})(e):""}
      .icon=${this.overrideIcon}
      .state=${e}
    ></ha-state-icon>`}},{kind:"method",key:"willUpdate",value:function(e){if(k(b(i.prototype),"willUpdate",this).call(this,e),!e.has("stateObj")&&!e.has("overrideImage")&&!e.has("overrideIcon"))return;const t=this.stateObj,a={},n={backgroundImage:""};if(this._showIcon=!0,t&&void 0===this.overrideImage)if(!t.attributes.entity_picture_local&&!t.attributes.entity_picture||this.overrideIcon){if("on"===t.state&&(!1!==this.stateColor&&t.attributes.rgb_color&&(a.color=`rgb(${t.attributes.rgb_color.join(",")})`),t.attributes.brightness&&!1!==this.stateColor)){const e=t.attributes.brightness;if("number"!=typeof e){const i=`Type error: state-badge expected number, but type of ${t.entity_id}.attributes.brightness is ${typeof e} (${e})`;console.warn(i)}a.filter=`brightness(${(e+245)/5}%)`}}else{let e=t.attributes.entity_picture_local||t.attributes.entity_picture;this.hass&&(e=this.hass.hassUrl(e)),"camera"===gs(t.entity_id)&&(e=`${e}&width=${80}&height=${80}`),n.backgroundImage=`url(${e})`,this._showIcon=!1}else if(this.overrideImage){let e=this.overrideImage;this.hass&&(e=this.hass.hassUrl(e)),n.backgroundImage=`url(${e})`,this._showIcon=!1}this._iconStyle=a,Object.assign(this.style,n)}},{kind:"get",static:!0,key:"styles",value:function(){return[Gr,r`
        :host {
          position: relative;
          display: inline-block;
          width: 40px;
          color: var(--paper-item-icon-color, #44739e);
          border-radius: 50%;
          height: 40px;
          text-align: center;
          background-size: cover;
          line-height: 40px;
          vertical-align: middle;
          box-sizing: border-box;
        }
        :host(:focus) {
          outline: none;
        }
        :host(:not([icon]):focus) {
          border: 2px solid var(--divider-color);
        }
        :host([icon]:focus) {
          background: var(--divider-color);
        }
        ha-state-icon {
          transition: color 0.3s ease-in-out, filter 0.3s ease-in-out;
        }
        .missing {
          color: #fce588;
        }
      `]}}]}}),g);customElements.define("state-badge",rl);const ll=e=>x`<mwc-list-item graphic="avatar" .twoline=${!!e.entity_id}>
    ${e.state?x`<state-badge slot="graphic" .stateObj=${e}></state-badge>`:""}
    <span>${e.friendly_name}</span>
    <span slot="secondary">${e.entity_id}</span>
  </mwc-list-item>`;f([A("ha-entity-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"autofocus",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:void 0},{kind:"field",decorators:[_({type:Boolean,attribute:"allow-custom-entity"})],key:"allowCustomEntity",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-domains"})],key:"includeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"exclude-domains"})],key:"excludeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-device-classes"})],key:"includeDeviceClasses",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-unit-of-measurement"})],key:"includeUnitOfMeasurement",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-entities"})],key:"includeEntities",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"exclude-entities"})],key:"excludeEntities",value:void 0},{kind:"field",decorators:[_()],key:"entityFilter",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"hideClearIcon",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_opened",value:()=>!1},{kind:"field",decorators:[y("ha-combo-box",!0)],key:"comboBox",value:void 0},{kind:"method",key:"open",value:function(){this.updateComplete.then((()=>{var e;null===(e=this.comboBox)||void 0===e||e.open()}))}},{kind:"method",key:"focus",value:function(){this.updateComplete.then((()=>{var e;null===(e=this.comboBox)||void 0===e||e.focus()}))}},{kind:"field",key:"_initedStates",value:()=>!1},{kind:"field",key:"_states",value:()=>[]},{kind:"field",key:"_getStates",value(){return n(((e,t,i,a,n,o,s,r,l)=>{let d=[];if(!t)return[];let c=Object.keys(t.states);return c.length?r?(c=c.filter((e=>this.includeEntities.includes(e))),c.map((e=>({...t.states[e],friendly_name:bo(t.states[e])||e}))).sort(((e,t)=>ys(e.friendly_name,t.friendly_name)))):(l&&(c=c.filter((e=>!l.includes(e)))),i&&(c=c.filter((e=>i.includes(gs(e))))),a&&(c=c.filter((e=>!a.includes(gs(e))))),d=c.map((e=>({...t.states[e],friendly_name:bo(t.states[e])||e}))).sort(((e,t)=>ys(e.friendly_name,t.friendly_name))),o&&(d=d.filter((e=>e.entity_id===this.value||e.attributes.device_class&&o.includes(e.attributes.device_class)))),s&&(d=d.filter((e=>e.entity_id===this.value||e.attributes.unit_of_measurement&&s.includes(e.attributes.unit_of_measurement)))),n&&(d=d.filter((e=>e.entity_id===this.value||n(e)))),d.length?d:[{entity_id:"",state:"",last_changed:"",last_updated:"",context:{id:"",user_id:null,parent_id:null},friendly_name:this.hass.localize("ui.components.entity.entity-picker.no_match"),attributes:{friendly_name:this.hass.localize("ui.components.entity.entity-picker.no_match"),icon:"mdi:magnify"}}]):[{entity_id:"",state:"",last_changed:"",last_updated:"",context:{id:"",user_id:null,parent_id:null},friendly_name:this.hass.localize("ui.components.entity.entity-picker.no_entities"),attributes:{friendly_name:this.hass.localize("ui.components.entity.entity-picker.no_entities"),icon:"mdi:magnify"}}]}))}},{kind:"method",key:"shouldUpdate",value:function(e){return!!(e.has("value")||e.has("label")||e.has("disabled"))||!(!e.has("_opened")&&this._opened)}},{kind:"method",key:"willUpdate",value:function(e){(!this._initedStates||e.has("_opened")&&this._opened)&&(this._states=this._getStates(this._opened,this.hass,this.includeDomains,this.excludeDomains,this.entityFilter,this.includeDeviceClasses,this.includeUnitOfMeasurement,this.includeEntities,this.excludeEntities),this._initedStates&&(this.comboBox.filteredItems=this._states),this._initedStates=!0)}},{kind:"method",key:"render",value:function(){return x`
      <ha-combo-box
        item-value-path="entity_id"
        item-label-path="friendly_name"
        .hass=${this.hass}
        .value=${this._value}
        .label=${void 0===this.label?this.hass.localize("ui.components.entity.entity-picker.entity"):this.label}
        .helper=${this.helper}
        .allowCustomValue=${this.allowCustomEntity}
        .filteredItems=${this._states}
        .renderer=${ll}
        .required=${this.required}
        @opened-changed=${this._openedChanged}
        @value-changed=${this._valueChanged}
        @filter-changed=${this._filterChanged}
      >
      </ha-combo-box>
    `}},{kind:"get",key:"_value",value:function(){return this.value||""}},{kind:"method",key:"_openedChanged",value:function(e){this._opened=e.detail.value}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;t!==this._value&&this._setValue(t)}},{kind:"method",key:"_filterChanged",value:function(e){const t=e.detail.value.toLowerCase();this.comboBox.filteredItems=this._states.filter((e=>e.entity_id.toLowerCase().includes(t)||bo(e).toLowerCase().includes(t)))}},{kind:"method",key:"_setValue",value:function(e){this.value=e,setTimeout((()=>{o(this,"value-changed",{value:e}),o(this,"change")}),0)}}]}}),g);const dl=["scene"];f([A("ha-automation-action-activate_scene")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{service:"scene.turn_on",target:{entity_id:""},metadata:{}}}},{kind:"method",key:"render",value:function(){let e;var t;"scene"in this.action?e=this.action.scene:e=null===(t=this.action.target)||void 0===t?void 0:t.entity_id;return x`
      <ha-entity-picker
        .hass=${this.hass}
        .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.activate_scene.scene")}
        .value=${e}
        @value-changed=${this._entityPicked}
        .includeDomains=${dl}
        allow-custom-entity
      ></ha-entity-picker>
    `}},{kind:"method",key:"_entityPicked",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{service:"scene.turn_on",target:{entity_id:e.detail.value},metadata:{}}})}}]}}),g),f([A("ha-automation-action-choose")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{choose:[{conditions:[],sequence:[]}],default:[]}}},{kind:"method",key:"render",value:function(){const e=this.action;return x`
      ${(e.choose?ko(e.choose):[]).map(((e,t)=>x`<ha-card>
          <ha-icon-button
            .idx=${t}
            @click=${this._removeOption}
            .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.choose.remove_option")}
            .path=${ea}
          ></ha-icon-button>
          <div class="card-content">
            <h2>
              ${this.hass.localize("ui.panel.config.automation.editor.actions.type.choose.option","number",t+1)}:
            </h2>
            <h3>
              ${this.hass.localize("ui.panel.config.automation.editor.actions.type.choose.conditions")}:
            </h3>
            <ha-automation-condition
              .conditions=${e.conditions}
              .hass=${this.hass}
              .idx=${t}
              @value-changed=${this._conditionChanged}
            ></ha-automation-condition>
            <h3>
              ${this.hass.localize("ui.panel.config.automation.editor.actions.type.choose.sequence")}:
            </h3>
            <ha-form
              .hass=${this.hass}
              .schema=${[{name:"sequence",selector:{action:{}}}]}
              .data=${e}
              .idx=${t}
              @value-changed=${this._actionChanged}
            ></ha-form>
          </div>
        </ha-card>`))}
      <mwc-button
        outlined
        .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.choose.add_option")}
        @click=${this._addOption}
      >
        <ha-svg-icon .path=${ta} slot="icon"></ha-svg-icon>
      </mwc-button>
      <h2>
        ${this.hass.localize("ui.panel.config.automation.editor.actions.type.choose.default")}:
      </h2>
      <ha-automation-action
        .actions=${e.default||[]}
        @value-changed=${this._defaultChanged}
        .hass=${this.hass}
      ></ha-automation-action>
    `}},{kind:"method",key:"_conditionChanged",value:function(e){e.stopPropagation();const t=e.detail.value,i=e.target.idx,a=this.action.choose?[...ko(this.action.choose)]:[];a[i].conditions=t,o(this,"value-changed",{value:{...this.action,choose:a}})}},{kind:"method",key:"_actionChanged",value:function(e){e.stopPropagation();const t=e.detail.value.sequence,i=e.target.idx,a=this.action.choose?[...ko(this.action.choose)]:[];a[i].sequence=t,o(this,"value-changed",{value:{...this.action,choose:a}})}},{kind:"method",key:"_addOption",value:function(){const e=this.action.choose?[...ko(this.action.choose)]:[];e.push({conditions:[],sequence:[]}),o(this,"value-changed",{value:{...this.action,choose:e}})}},{kind:"method",key:"_removeOption",value:function(e){const t=e.currentTarget.idx,i=this.action.choose?[...ko(this.action.choose)]:[];i.splice(t,1),o(this,"value-changed",{value:{...this.action,choose:i}})}},{kind:"method",key:"_defaultChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:{...this.action,default:t}})}},{kind:"get",static:!0,key:"styles",value:function(){return[ia,r`
        ha-card {
          margin: 16px 0;
        }
        .add-card mwc-button {
          display: block;
          text-align: center;
        }
        ha-icon-button {
          position: absolute;
          right: 0;
          padding: 4px;
        }
        ha-form::part(root) {
          overflow: visible;
        }
        ha-svg-icon {
          height: 20px;
        }
      `]}}]}}),g);const cl={device:aa,and:na,or:oa,not:sa,state:ra,numeric_state:la,sun:Ve,template:da,time:ca,trigger:ua,zone:he};function ul(e){return null==e}var hl=function(e,t){var i,a="";for(i=0;i<t;i+=1)a+=e;return a},pl=function(e){return 0===e&&Number.NEGATIVE_INFINITY===1/e},vl={isNothing:ul,isObject:function(e){return"object"==typeof e&&null!==e},toArray:function(e){return Array.isArray(e)?e:ul(e)?[]:[e]},repeat:hl,isNegativeZero:pl,extend:function(e,t){var i,a,n,o;if(t)for(i=0,a=(o=Object.keys(t)).length;i<a;i+=1)e[n=o[i]]=t[n];return e}};function ml(e,t){var i="",a=e.reason||"(unknown reason)";return e.mark?(e.mark.name&&(i+='in "'+e.mark.name+'" '),i+="("+(e.mark.line+1)+":"+(e.mark.column+1)+")",!t&&e.mark.snippet&&(i+="\n\n"+e.mark.snippet),a+" "+i):a}function fl(e,t){Error.call(this),this.name="YAMLException",this.reason=e,this.mark=t,this.message=ml(this,!1),Error.captureStackTrace?Error.captureStackTrace(this,this.constructor):this.stack=(new Error).stack||""}fl.prototype=Object.create(Error.prototype),fl.prototype.constructor=fl,fl.prototype.toString=function(e){return this.name+": "+ml(this,e)};var gl=fl;function _l(e,t,i,a,n){var o="",s="",r=Math.floor(n/2)-1;return a-t>r&&(t=a-r+(o=" ... ").length),i-a>r&&(i=a+r-(s=" ...").length),{str:o+e.slice(t,i).replace(/\t/g,"→")+s,pos:a-t+o.length}}function yl(e,t){return vl.repeat(" ",t-e.length)+e}var kl=function(e,t){if(t=Object.create(t||null),!e.buffer)return null;t.maxLength||(t.maxLength=79),"number"!=typeof t.indent&&(t.indent=1),"number"!=typeof t.linesBefore&&(t.linesBefore=3),"number"!=typeof t.linesAfter&&(t.linesAfter=2);for(var i,a=/\r?\n|\r|\0/g,n=[0],o=[],s=-1;i=a.exec(e.buffer);)o.push(i.index),n.push(i.index+i[0].length),e.position<=i.index&&s<0&&(s=n.length-2);s<0&&(s=n.length-1);var r,l,d="",c=Math.min(e.line+t.linesAfter,o.length).toString().length,u=t.maxLength-(t.indent+c+3);for(r=1;r<=t.linesBefore&&!(s-r<0);r++)l=_l(e.buffer,n[s-r],o[s-r],e.position-(n[s]-n[s-r]),u),d=vl.repeat(" ",t.indent)+yl((e.line-r+1).toString(),c)+" | "+l.str+"\n"+d;for(l=_l(e.buffer,n[s],o[s],e.position,u),d+=vl.repeat(" ",t.indent)+yl((e.line+1).toString(),c)+" | "+l.str+"\n",d+=vl.repeat("-",t.indent+c+3+l.pos)+"^\n",r=1;r<=t.linesAfter&&!(s+r>=o.length);r++)l=_l(e.buffer,n[s+r],o[s+r],e.position-(n[s]-n[s+r]),u),d+=vl.repeat(" ",t.indent)+yl((e.line+r+1).toString(),c)+" | "+l.str+"\n";return d.replace(/\n$/,"")},bl=["kind","multi","resolve","construct","instanceOf","predicate","represent","representName","defaultStyle","styleAliases"],xl=["scalar","sequence","mapping"];var $l=function(e,t){if(t=t||{},Object.keys(t).forEach((function(t){if(-1===bl.indexOf(t))throw new gl('Unknown option "'+t+'" is met in definition of "'+e+'" YAML type.')})),this.options=t,this.tag=e,this.kind=t.kind||null,this.resolve=t.resolve||function(){return!0},this.construct=t.construct||function(e){return e},this.instanceOf=t.instanceOf||null,this.predicate=t.predicate||null,this.represent=t.represent||null,this.representName=t.representName||null,this.defaultStyle=t.defaultStyle||null,this.multi=t.multi||!1,this.styleAliases=function(e){var t={};return null!==e&&Object.keys(e).forEach((function(i){e[i].forEach((function(e){t[String(e)]=i}))})),t}(t.styleAliases||null),-1===xl.indexOf(this.kind))throw new gl('Unknown kind "'+this.kind+'" is specified for "'+e+'" YAML type.')};function wl(e,t){var i=[];return e[t].forEach((function(e){var t=i.length;i.forEach((function(i,a){i.tag===e.tag&&i.kind===e.kind&&i.multi===e.multi&&(t=a)})),i[t]=e})),i}function Cl(e){return this.extend(e)}Cl.prototype.extend=function(e){var t=[],i=[];if(e instanceof $l)i.push(e);else if(Array.isArray(e))i=i.concat(e);else{if(!e||!Array.isArray(e.implicit)&&!Array.isArray(e.explicit))throw new gl("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");e.implicit&&(t=t.concat(e.implicit)),e.explicit&&(i=i.concat(e.explicit))}t.forEach((function(e){if(!(e instanceof $l))throw new gl("Specified list of YAML types (or a single Type object) contains a non-Type object.");if(e.loadKind&&"scalar"!==e.loadKind)throw new gl("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");if(e.multi)throw new gl("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.")})),i.forEach((function(e){if(!(e instanceof $l))throw new gl("Specified list of YAML types (or a single Type object) contains a non-Type object.")}));var a=Object.create(Cl.prototype);return a.implicit=(this.implicit||[]).concat(t),a.explicit=(this.explicit||[]).concat(i),a.compiledImplicit=wl(a,"implicit"),a.compiledExplicit=wl(a,"explicit"),a.compiledTypeMap=function(){var e,t,i={scalar:{},sequence:{},mapping:{},fallback:{},multi:{scalar:[],sequence:[],mapping:[],fallback:[]}};function a(e){e.multi?(i.multi[e.kind].push(e),i.multi.fallback.push(e)):i[e.kind][e.tag]=i.fallback[e.tag]=e}for(e=0,t=arguments.length;e<t;e+=1)arguments[e].forEach(a);return i}(a.compiledImplicit,a.compiledExplicit),a};var Al=new Cl({explicit:[new $l("tag:yaml.org,2002:str",{kind:"scalar",construct:function(e){return null!==e?e:""}}),new $l("tag:yaml.org,2002:seq",{kind:"sequence",construct:function(e){return null!==e?e:[]}}),new $l("tag:yaml.org,2002:map",{kind:"mapping",construct:function(e){return null!==e?e:{}}})]});var Il=new $l("tag:yaml.org,2002:null",{kind:"scalar",resolve:function(e){if(null===e)return!0;var t=e.length;return 1===t&&"~"===e||4===t&&("null"===e||"Null"===e||"NULL"===e)},construct:function(){return null},predicate:function(e){return null===e},represent:{canonical:function(){return"~"},lowercase:function(){return"null"},uppercase:function(){return"NULL"},camelcase:function(){return"Null"},empty:function(){return""}},defaultStyle:"lowercase"});var El=new $l("tag:yaml.org,2002:bool",{kind:"scalar",resolve:function(e){if(null===e)return!1;var t=e.length;return 4===t&&("true"===e||"True"===e||"TRUE"===e)||5===t&&("false"===e||"False"===e||"FALSE"===e)},construct:function(e){return"true"===e||"True"===e||"TRUE"===e},predicate:function(e){return"[object Boolean]"===Object.prototype.toString.call(e)},represent:{lowercase:function(e){return e?"true":"false"},uppercase:function(e){return e?"TRUE":"FALSE"},camelcase:function(e){return e?"True":"False"}},defaultStyle:"lowercase"});function zl(e){return 48<=e&&e<=57||65<=e&&e<=70||97<=e&&e<=102}function Sl(e){return 48<=e&&e<=55}function Tl(e){return 48<=e&&e<=57}var Ll=new $l("tag:yaml.org,2002:int",{kind:"scalar",resolve:function(e){if(null===e)return!1;var t,i=e.length,a=0,n=!1;if(!i)return!1;if("-"!==(t=e[a])&&"+"!==t||(t=e[++a]),"0"===t){if(a+1===i)return!0;if("b"===(t=e[++a])){for(a++;a<i;a++)if("_"!==(t=e[a])){if("0"!==t&&"1"!==t)return!1;n=!0}return n&&"_"!==t}if("x"===t){for(a++;a<i;a++)if("_"!==(t=e[a])){if(!zl(e.charCodeAt(a)))return!1;n=!0}return n&&"_"!==t}if("o"===t){for(a++;a<i;a++)if("_"!==(t=e[a])){if(!Sl(e.charCodeAt(a)))return!1;n=!0}return n&&"_"!==t}}if("_"===t)return!1;for(;a<i;a++)if("_"!==(t=e[a])){if(!Tl(e.charCodeAt(a)))return!1;n=!0}return!(!n||"_"===t)},construct:function(e){var t,i=e,a=1;if(-1!==i.indexOf("_")&&(i=i.replace(/_/g,"")),"-"!==(t=i[0])&&"+"!==t||("-"===t&&(a=-1),t=(i=i.slice(1))[0]),"0"===i)return 0;if("0"===t){if("b"===i[1])return a*parseInt(i.slice(2),2);if("x"===i[1])return a*parseInt(i.slice(2),16);if("o"===i[1])return a*parseInt(i.slice(2),8)}return a*parseInt(i,10)},predicate:function(e){return"[object Number]"===Object.prototype.toString.call(e)&&e%1==0&&!vl.isNegativeZero(e)},represent:{binary:function(e){return e>=0?"0b"+e.toString(2):"-0b"+e.toString(2).slice(1)},octal:function(e){return e>=0?"0o"+e.toString(8):"-0o"+e.toString(8).slice(1)},decimal:function(e){return e.toString(10)},hexadecimal:function(e){return e>=0?"0x"+e.toString(16).toUpperCase():"-0x"+e.toString(16).toUpperCase().slice(1)}},defaultStyle:"decimal",styleAliases:{binary:[2,"bin"],octal:[8,"oct"],decimal:[10,"dec"],hexadecimal:[16,"hex"]}}),Ol=new RegExp("^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");var Ml=/^[-+]?[0-9]+e/;var Pl=new $l("tag:yaml.org,2002:float",{kind:"scalar",resolve:function(e){return null!==e&&!(!Ol.test(e)||"_"===e[e.length-1])},construct:function(e){var t,i;return i="-"===(t=e.replace(/_/g,"").toLowerCase())[0]?-1:1,"+-".indexOf(t[0])>=0&&(t=t.slice(1)),".inf"===t?1===i?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY:".nan"===t?NaN:i*parseFloat(t,10)},predicate:function(e){return"[object Number]"===Object.prototype.toString.call(e)&&(e%1!=0||vl.isNegativeZero(e))},represent:function(e,t){var i;if(isNaN(e))switch(t){case"lowercase":return".nan";case"uppercase":return".NAN";case"camelcase":return".NaN"}else if(Number.POSITIVE_INFINITY===e)switch(t){case"lowercase":return".inf";case"uppercase":return".INF";case"camelcase":return".Inf"}else if(Number.NEGATIVE_INFINITY===e)switch(t){case"lowercase":return"-.inf";case"uppercase":return"-.INF";case"camelcase":return"-.Inf"}else if(vl.isNegativeZero(e))return"-0.0";return i=e.toString(10),Ml.test(i)?i.replace("e",".e"):i},defaultStyle:"lowercase"}),Fl=Al.extend({implicit:[Il,El,Ll,Pl]}),Dl=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"),Bl=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$");var Nl=new $l("tag:yaml.org,2002:timestamp",{kind:"scalar",resolve:function(e){return null!==e&&(null!==Dl.exec(e)||null!==Bl.exec(e))},construct:function(e){var t,i,a,n,o,s,r,l,d=0,c=null;if(null===(t=Dl.exec(e))&&(t=Bl.exec(e)),null===t)throw new Error("Date resolve error");if(i=+t[1],a=+t[2]-1,n=+t[3],!t[4])return new Date(Date.UTC(i,a,n));if(o=+t[4],s=+t[5],r=+t[6],t[7]){for(d=t[7].slice(0,3);d.length<3;)d+="0";d=+d}return t[9]&&(c=6e4*(60*+t[10]+ +(t[11]||0)),"-"===t[9]&&(c=-c)),l=new Date(Date.UTC(i,a,n,o,s,r,d)),c&&l.setTime(l.getTime()-c),l},instanceOf:Date,represent:function(e){return e.toISOString()}});var Vl=new $l("tag:yaml.org,2002:merge",{kind:"scalar",resolve:function(e){return"<<"===e||null===e}}),ql="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\n\r";var jl=new $l("tag:yaml.org,2002:binary",{kind:"scalar",resolve:function(e){if(null===e)return!1;var t,i,a=0,n=e.length,o=ql;for(i=0;i<n;i++)if(!((t=o.indexOf(e.charAt(i)))>64)){if(t<0)return!1;a+=6}return a%8==0},construct:function(e){var t,i,a=e.replace(/[\r\n=]/g,""),n=a.length,o=ql,s=0,r=[];for(t=0;t<n;t++)t%4==0&&t&&(r.push(s>>16&255),r.push(s>>8&255),r.push(255&s)),s=s<<6|o.indexOf(a.charAt(t));return 0===(i=n%4*6)?(r.push(s>>16&255),r.push(s>>8&255),r.push(255&s)):18===i?(r.push(s>>10&255),r.push(s>>2&255)):12===i&&r.push(s>>4&255),new Uint8Array(r)},predicate:function(e){return"[object Uint8Array]"===Object.prototype.toString.call(e)},represent:function(e){var t,i,a="",n=0,o=e.length,s=ql;for(t=0;t<o;t++)t%3==0&&t&&(a+=s[n>>18&63],a+=s[n>>12&63],a+=s[n>>6&63],a+=s[63&n]),n=(n<<8)+e[t];return 0===(i=o%3)?(a+=s[n>>18&63],a+=s[n>>12&63],a+=s[n>>6&63],a+=s[63&n]):2===i?(a+=s[n>>10&63],a+=s[n>>4&63],a+=s[n<<2&63],a+=s[64]):1===i&&(a+=s[n>>2&63],a+=s[n<<4&63],a+=s[64],a+=s[64]),a}}),Rl=Object.prototype.hasOwnProperty,Ul=Object.prototype.toString;var Hl=new $l("tag:yaml.org,2002:omap",{kind:"sequence",resolve:function(e){if(null===e)return!0;var t,i,a,n,o,s=[],r=e;for(t=0,i=r.length;t<i;t+=1){if(a=r[t],o=!1,"[object Object]"!==Ul.call(a))return!1;for(n in a)if(Rl.call(a,n)){if(o)return!1;o=!0}if(!o)return!1;if(-1!==s.indexOf(n))return!1;s.push(n)}return!0},construct:function(e){return null!==e?e:[]}}),Gl=Object.prototype.toString;var Wl=new $l("tag:yaml.org,2002:pairs",{kind:"sequence",resolve:function(e){if(null===e)return!0;var t,i,a,n,o,s=e;for(o=new Array(s.length),t=0,i=s.length;t<i;t+=1){if(a=s[t],"[object Object]"!==Gl.call(a))return!1;if(1!==(n=Object.keys(a)).length)return!1;o[t]=[n[0],a[n[0]]]}return!0},construct:function(e){if(null===e)return[];var t,i,a,n,o,s=e;for(o=new Array(s.length),t=0,i=s.length;t<i;t+=1)a=s[t],n=Object.keys(a),o[t]=[n[0],a[n[0]]];return o}}),Kl=Object.prototype.hasOwnProperty;var Yl=new $l("tag:yaml.org,2002:set",{kind:"mapping",resolve:function(e){if(null===e)return!0;var t,i=e;for(t in i)if(Kl.call(i,t)&&null!==i[t])return!1;return!0},construct:function(e){return null!==e?e:{}}}),Zl=Fl.extend({implicit:[Nl,Vl],explicit:[jl,Hl,Wl,Yl]}),Ql=Object.prototype.hasOwnProperty,Jl=/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/,Xl=/[\x85\u2028\u2029]/,ed=/[,\[\]\{\}]/,td=/^(?:!|!!|![a-z\-]+!)$/i,id=/^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;function ad(e){return Object.prototype.toString.call(e)}function nd(e){return 10===e||13===e}function od(e){return 9===e||32===e}function sd(e){return 9===e||32===e||10===e||13===e}function rd(e){return 44===e||91===e||93===e||123===e||125===e}function ld(e){var t;return 48<=e&&e<=57?e-48:97<=(t=32|e)&&t<=102?t-97+10:-1}function dd(e){return 120===e?2:117===e?4:85===e?8:0}function cd(e){return 48<=e&&e<=57?e-48:-1}function ud(e){return 48===e?"\0":97===e?"":98===e?"\b":116===e||9===e?"\t":110===e?"\n":118===e?"\v":102===e?"\f":114===e?"\r":101===e?"":32===e?" ":34===e?'"':47===e?"/":92===e?"\\":78===e?"":95===e?" ":76===e?"\u2028":80===e?"\u2029":""}function hd(e){return e<=65535?String.fromCharCode(e):String.fromCharCode(55296+(e-65536>>10),56320+(e-65536&1023))}for(var pd=new Array(256),vd=new Array(256),md=0;md<256;md++)pd[md]=ud(md)?1:0,vd[md]=ud(md);function fd(e,t){this.input=e,this.filename=t.filename||null,this.schema=t.schema||Zl,this.onWarning=t.onWarning||null,this.legacy=t.legacy||!1,this.json=t.json||!1,this.listener=t.listener||null,this.implicitTypes=this.schema.compiledImplicit,this.typeMap=this.schema.compiledTypeMap,this.length=e.length,this.position=0,this.line=0,this.lineStart=0,this.lineIndent=0,this.firstTabInLine=-1,this.documents=[]}function gd(e,t){var i={name:e.filename,buffer:e.input.slice(0,-1),position:e.position,line:e.line,column:e.position-e.lineStart};return i.snippet=kl(i),new gl(t,i)}function _d(e,t){throw gd(e,t)}function yd(e,t){e.onWarning&&e.onWarning.call(null,gd(e,t))}var kd={YAML:function(e,t,i){var a,n,o;null!==e.version&&_d(e,"duplication of %YAML directive"),1!==i.length&&_d(e,"YAML directive accepts exactly one argument"),null===(a=/^([0-9]+)\.([0-9]+)$/.exec(i[0]))&&_d(e,"ill-formed argument of the YAML directive"),n=parseInt(a[1],10),o=parseInt(a[2],10),1!==n&&_d(e,"unacceptable YAML version of the document"),e.version=i[0],e.checkLineBreaks=o<2,1!==o&&2!==o&&yd(e,"unsupported YAML version of the document")},TAG:function(e,t,i){var a,n;2!==i.length&&_d(e,"TAG directive accepts exactly two arguments"),a=i[0],n=i[1],td.test(a)||_d(e,"ill-formed tag handle (first argument) of the TAG directive"),Ql.call(e.tagMap,a)&&_d(e,'there is a previously declared suffix for "'+a+'" tag handle'),id.test(n)||_d(e,"ill-formed tag prefix (second argument) of the TAG directive");try{n=decodeURIComponent(n)}catch(t){_d(e,"tag prefix is malformed: "+n)}e.tagMap[a]=n}};function bd(e,t,i,a){var n,o,s,r;if(t<i){if(r=e.input.slice(t,i),a)for(n=0,o=r.length;n<o;n+=1)9===(s=r.charCodeAt(n))||32<=s&&s<=1114111||_d(e,"expected valid JSON character");else Jl.test(r)&&_d(e,"the stream contains non-printable characters");e.result+=r}}function xd(e,t,i,a){var n,o,s,r;for(vl.isObject(i)||_d(e,"cannot merge mappings; the provided source object is unacceptable"),s=0,r=(n=Object.keys(i)).length;s<r;s+=1)o=n[s],Ql.call(t,o)||(t[o]=i[o],a[o]=!0)}function $d(e,t,i,a,n,o,s,r,l){var d,c;if(Array.isArray(n))for(d=0,c=(n=Array.prototype.slice.call(n)).length;d<c;d+=1)Array.isArray(n[d])&&_d(e,"nested arrays are not supported inside keys"),"object"==typeof n&&"[object Object]"===ad(n[d])&&(n[d]="[object Object]");if("object"==typeof n&&"[object Object]"===ad(n)&&(n="[object Object]"),n=String(n),null===t&&(t={}),"tag:yaml.org,2002:merge"===a)if(Array.isArray(o))for(d=0,c=o.length;d<c;d+=1)xd(e,t,o[d],i);else xd(e,t,o,i);else e.json||Ql.call(i,n)||!Ql.call(t,n)||(e.line=s||e.line,e.lineStart=r||e.lineStart,e.position=l||e.position,_d(e,"duplicated mapping key")),"__proto__"===n?Object.defineProperty(t,n,{configurable:!0,enumerable:!0,writable:!0,value:o}):t[n]=o,delete i[n];return t}function wd(e){var t;10===(t=e.input.charCodeAt(e.position))?e.position++:13===t?(e.position++,10===e.input.charCodeAt(e.position)&&e.position++):_d(e,"a line break is expected"),e.line+=1,e.lineStart=e.position,e.firstTabInLine=-1}function Cd(e,t,i){for(var a=0,n=e.input.charCodeAt(e.position);0!==n;){for(;od(n);)9===n&&-1===e.firstTabInLine&&(e.firstTabInLine=e.position),n=e.input.charCodeAt(++e.position);if(t&&35===n)do{n=e.input.charCodeAt(++e.position)}while(10!==n&&13!==n&&0!==n);if(!nd(n))break;for(wd(e),n=e.input.charCodeAt(e.position),a++,e.lineIndent=0;32===n;)e.lineIndent++,n=e.input.charCodeAt(++e.position)}return-1!==i&&0!==a&&e.lineIndent<i&&yd(e,"deficient indentation"),a}function Ad(e){var t,i=e.position;return!(45!==(t=e.input.charCodeAt(i))&&46!==t||t!==e.input.charCodeAt(i+1)||t!==e.input.charCodeAt(i+2)||(i+=3,0!==(t=e.input.charCodeAt(i))&&!sd(t)))}function Id(e,t){1===t?e.result+=" ":t>1&&(e.result+=vl.repeat("\n",t-1))}function Ed(e,t){var i,a,n=e.tag,o=e.anchor,s=[],r=!1;if(-1!==e.firstTabInLine)return!1;for(null!==e.anchor&&(e.anchorMap[e.anchor]=s),a=e.input.charCodeAt(e.position);0!==a&&(-1!==e.firstTabInLine&&(e.position=e.firstTabInLine,_d(e,"tab characters must not be used in indentation")),45===a)&&sd(e.input.charCodeAt(e.position+1));)if(r=!0,e.position++,Cd(e,!0,-1)&&e.lineIndent<=t)s.push(null),a=e.input.charCodeAt(e.position);else if(i=e.line,Td(e,t,3,!1,!0),s.push(e.result),Cd(e,!0,-1),a=e.input.charCodeAt(e.position),(e.line===i||e.lineIndent>t)&&0!==a)_d(e,"bad indentation of a sequence entry");else if(e.lineIndent<t)break;return!!r&&(e.tag=n,e.anchor=o,e.kind="sequence",e.result=s,!0)}function zd(e){var t,i,a,n,o=!1,s=!1;if(33!==(n=e.input.charCodeAt(e.position)))return!1;if(null!==e.tag&&_d(e,"duplication of a tag property"),60===(n=e.input.charCodeAt(++e.position))?(o=!0,n=e.input.charCodeAt(++e.position)):33===n?(s=!0,i="!!",n=e.input.charCodeAt(++e.position)):i="!",t=e.position,o){do{n=e.input.charCodeAt(++e.position)}while(0!==n&&62!==n);e.position<e.length?(a=e.input.slice(t,e.position),n=e.input.charCodeAt(++e.position)):_d(e,"unexpected end of the stream within a verbatim tag")}else{for(;0!==n&&!sd(n);)33===n&&(s?_d(e,"tag suffix cannot contain exclamation marks"):(i=e.input.slice(t-1,e.position+1),td.test(i)||_d(e,"named tag handle cannot contain such characters"),s=!0,t=e.position+1)),n=e.input.charCodeAt(++e.position);a=e.input.slice(t,e.position),ed.test(a)&&_d(e,"tag suffix cannot contain flow indicator characters")}a&&!id.test(a)&&_d(e,"tag name cannot contain such characters: "+a);try{a=decodeURIComponent(a)}catch(t){_d(e,"tag name is malformed: "+a)}return o?e.tag=a:Ql.call(e.tagMap,i)?e.tag=e.tagMap[i]+a:"!"===i?e.tag="!"+a:"!!"===i?e.tag="tag:yaml.org,2002:"+a:_d(e,'undeclared tag handle "'+i+'"'),!0}function Sd(e){var t,i;if(38!==(i=e.input.charCodeAt(e.position)))return!1;for(null!==e.anchor&&_d(e,"duplication of an anchor property"),i=e.input.charCodeAt(++e.position),t=e.position;0!==i&&!sd(i)&&!rd(i);)i=e.input.charCodeAt(++e.position);return e.position===t&&_d(e,"name of an anchor node must contain at least one character"),e.anchor=e.input.slice(t,e.position),!0}function Td(e,t,i,a,n){var o,s,r,l,d,c,u,h,p,v=1,m=!1,f=!1;if(null!==e.listener&&e.listener("open",e),e.tag=null,e.anchor=null,e.kind=null,e.result=null,o=s=r=4===i||3===i,a&&Cd(e,!0,-1)&&(m=!0,e.lineIndent>t?v=1:e.lineIndent===t?v=0:e.lineIndent<t&&(v=-1)),1===v)for(;zd(e)||Sd(e);)Cd(e,!0,-1)?(m=!0,r=o,e.lineIndent>t?v=1:e.lineIndent===t?v=0:e.lineIndent<t&&(v=-1)):r=!1;if(r&&(r=m||n),1!==v&&4!==i||(h=1===i||2===i?t:t+1,p=e.position-e.lineStart,1===v?r&&(Ed(e,p)||function(e,t,i){var a,n,o,s,r,l,d,c=e.tag,u=e.anchor,h={},p=Object.create(null),v=null,m=null,f=null,g=!1,_=!1;if(-1!==e.firstTabInLine)return!1;for(null!==e.anchor&&(e.anchorMap[e.anchor]=h),d=e.input.charCodeAt(e.position);0!==d;){if(g||-1===e.firstTabInLine||(e.position=e.firstTabInLine,_d(e,"tab characters must not be used in indentation")),a=e.input.charCodeAt(e.position+1),o=e.line,63!==d&&58!==d||!sd(a)){if(s=e.line,r=e.lineStart,l=e.position,!Td(e,i,2,!1,!0))break;if(e.line===o){for(d=e.input.charCodeAt(e.position);od(d);)d=e.input.charCodeAt(++e.position);if(58===d)sd(d=e.input.charCodeAt(++e.position))||_d(e,"a whitespace character is expected after the key-value separator within a block mapping"),g&&($d(e,h,p,v,m,null,s,r,l),v=m=f=null),_=!0,g=!1,n=!1,v=e.tag,m=e.result;else{if(!_)return e.tag=c,e.anchor=u,!0;_d(e,"can not read an implicit mapping pair; a colon is missed")}}else{if(!_)return e.tag=c,e.anchor=u,!0;_d(e,"can not read a block mapping entry; a multiline key may not be an implicit key")}}else 63===d?(g&&($d(e,h,p,v,m,null,s,r,l),v=m=f=null),_=!0,g=!0,n=!0):g?(g=!1,n=!0):_d(e,"incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"),e.position+=1,d=a;if((e.line===o||e.lineIndent>t)&&(g&&(s=e.line,r=e.lineStart,l=e.position),Td(e,t,4,!0,n)&&(g?m=e.result:f=e.result),g||($d(e,h,p,v,m,f,s,r,l),v=m=f=null),Cd(e,!0,-1),d=e.input.charCodeAt(e.position)),(e.line===o||e.lineIndent>t)&&0!==d)_d(e,"bad indentation of a mapping entry");else if(e.lineIndent<t)break}return g&&$d(e,h,p,v,m,null,s,r,l),_&&(e.tag=c,e.anchor=u,e.kind="mapping",e.result=h),_}(e,p,h))||function(e,t){var i,a,n,o,s,r,l,d,c,u,h,p,v=!0,m=e.tag,f=e.anchor,g=Object.create(null);if(91===(p=e.input.charCodeAt(e.position)))s=93,d=!1,o=[];else{if(123!==p)return!1;s=125,d=!0,o={}}for(null!==e.anchor&&(e.anchorMap[e.anchor]=o),p=e.input.charCodeAt(++e.position);0!==p;){if(Cd(e,!0,t),(p=e.input.charCodeAt(e.position))===s)return e.position++,e.tag=m,e.anchor=f,e.kind=d?"mapping":"sequence",e.result=o,!0;v?44===p&&_d(e,"expected the node content, but found ','"):_d(e,"missed comma between flow collection entries"),h=null,r=l=!1,63===p&&sd(e.input.charCodeAt(e.position+1))&&(r=l=!0,e.position++,Cd(e,!0,t)),i=e.line,a=e.lineStart,n=e.position,Td(e,t,1,!1,!0),u=e.tag,c=e.result,Cd(e,!0,t),p=e.input.charCodeAt(e.position),!l&&e.line!==i||58!==p||(r=!0,p=e.input.charCodeAt(++e.position),Cd(e,!0,t),Td(e,t,1,!1,!0),h=e.result),d?$d(e,o,g,u,c,h,i,a,n):r?o.push($d(e,null,g,u,c,h,i,a,n)):o.push(c),Cd(e,!0,t),44===(p=e.input.charCodeAt(e.position))?(v=!0,p=e.input.charCodeAt(++e.position)):v=!1}_d(e,"unexpected end of the stream within a flow collection")}(e,h)?f=!0:(s&&function(e,t){var i,a,n,o,s=1,r=!1,l=!1,d=t,c=0,u=!1;if(124===(o=e.input.charCodeAt(e.position)))a=!1;else{if(62!==o)return!1;a=!0}for(e.kind="scalar",e.result="";0!==o;)if(43===(o=e.input.charCodeAt(++e.position))||45===o)1===s?s=43===o?3:2:_d(e,"repeat of a chomping mode identifier");else{if(!((n=cd(o))>=0))break;0===n?_d(e,"bad explicit indentation width of a block scalar; it cannot be less than one"):l?_d(e,"repeat of an indentation width identifier"):(d=t+n-1,l=!0)}if(od(o)){do{o=e.input.charCodeAt(++e.position)}while(od(o));if(35===o)do{o=e.input.charCodeAt(++e.position)}while(!nd(o)&&0!==o)}for(;0!==o;){for(wd(e),e.lineIndent=0,o=e.input.charCodeAt(e.position);(!l||e.lineIndent<d)&&32===o;)e.lineIndent++,o=e.input.charCodeAt(++e.position);if(!l&&e.lineIndent>d&&(d=e.lineIndent),nd(o))c++;else{if(e.lineIndent<d){3===s?e.result+=vl.repeat("\n",r?1+c:c):1===s&&r&&(e.result+="\n");break}for(a?od(o)?(u=!0,e.result+=vl.repeat("\n",r?1+c:c)):u?(u=!1,e.result+=vl.repeat("\n",c+1)):0===c?r&&(e.result+=" "):e.result+=vl.repeat("\n",c):e.result+=vl.repeat("\n",r?1+c:c),r=!0,l=!0,c=0,i=e.position;!nd(o)&&0!==o;)o=e.input.charCodeAt(++e.position);bd(e,i,e.position,!1)}}return!0}(e,h)||function(e,t){var i,a,n;if(39!==(i=e.input.charCodeAt(e.position)))return!1;for(e.kind="scalar",e.result="",e.position++,a=n=e.position;0!==(i=e.input.charCodeAt(e.position));)if(39===i){if(bd(e,a,e.position,!0),39!==(i=e.input.charCodeAt(++e.position)))return!0;a=e.position,e.position++,n=e.position}else nd(i)?(bd(e,a,n,!0),Id(e,Cd(e,!1,t)),a=n=e.position):e.position===e.lineStart&&Ad(e)?_d(e,"unexpected end of the document within a single quoted scalar"):(e.position++,n=e.position);_d(e,"unexpected end of the stream within a single quoted scalar")}(e,h)||function(e,t){var i,a,n,o,s,r;if(34!==(r=e.input.charCodeAt(e.position)))return!1;for(e.kind="scalar",e.result="",e.position++,i=a=e.position;0!==(r=e.input.charCodeAt(e.position));){if(34===r)return bd(e,i,e.position,!0),e.position++,!0;if(92===r){if(bd(e,i,e.position,!0),nd(r=e.input.charCodeAt(++e.position)))Cd(e,!1,t);else if(r<256&&pd[r])e.result+=vd[r],e.position++;else if((s=dd(r))>0){for(n=s,o=0;n>0;n--)(s=ld(r=e.input.charCodeAt(++e.position)))>=0?o=(o<<4)+s:_d(e,"expected hexadecimal character");e.result+=hd(o),e.position++}else _d(e,"unknown escape sequence");i=a=e.position}else nd(r)?(bd(e,i,a,!0),Id(e,Cd(e,!1,t)),i=a=e.position):e.position===e.lineStart&&Ad(e)?_d(e,"unexpected end of the document within a double quoted scalar"):(e.position++,a=e.position)}_d(e,"unexpected end of the stream within a double quoted scalar")}(e,h)?f=!0:!function(e){var t,i,a;if(42!==(a=e.input.charCodeAt(e.position)))return!1;for(a=e.input.charCodeAt(++e.position),t=e.position;0!==a&&!sd(a)&&!rd(a);)a=e.input.charCodeAt(++e.position);return e.position===t&&_d(e,"name of an alias node must contain at least one character"),i=e.input.slice(t,e.position),Ql.call(e.anchorMap,i)||_d(e,'unidentified alias "'+i+'"'),e.result=e.anchorMap[i],Cd(e,!0,-1),!0}(e)?function(e,t,i){var a,n,o,s,r,l,d,c,u=e.kind,h=e.result;if(sd(c=e.input.charCodeAt(e.position))||rd(c)||35===c||38===c||42===c||33===c||124===c||62===c||39===c||34===c||37===c||64===c||96===c)return!1;if((63===c||45===c)&&(sd(a=e.input.charCodeAt(e.position+1))||i&&rd(a)))return!1;for(e.kind="scalar",e.result="",n=o=e.position,s=!1;0!==c;){if(58===c){if(sd(a=e.input.charCodeAt(e.position+1))||i&&rd(a))break}else if(35===c){if(sd(e.input.charCodeAt(e.position-1)))break}else{if(e.position===e.lineStart&&Ad(e)||i&&rd(c))break;if(nd(c)){if(r=e.line,l=e.lineStart,d=e.lineIndent,Cd(e,!1,-1),e.lineIndent>=t){s=!0,c=e.input.charCodeAt(e.position);continue}e.position=o,e.line=r,e.lineStart=l,e.lineIndent=d;break}}s&&(bd(e,n,o,!1),Id(e,e.line-r),n=o=e.position,s=!1),od(c)||(o=e.position+1),c=e.input.charCodeAt(++e.position)}return bd(e,n,o,!1),!!e.result||(e.kind=u,e.result=h,!1)}(e,h,1===i)&&(f=!0,null===e.tag&&(e.tag="?")):(f=!0,null===e.tag&&null===e.anchor||_d(e,"alias node should not have any properties")),null!==e.anchor&&(e.anchorMap[e.anchor]=e.result)):0===v&&(f=r&&Ed(e,p))),null===e.tag)null!==e.anchor&&(e.anchorMap[e.anchor]=e.result);else if("?"===e.tag){for(null!==e.result&&"scalar"!==e.kind&&_d(e,'unacceptable node kind for !<?> tag; it should be "scalar", not "'+e.kind+'"'),l=0,d=e.implicitTypes.length;l<d;l+=1)if((u=e.implicitTypes[l]).resolve(e.result)){e.result=u.construct(e.result),e.tag=u.tag,null!==e.anchor&&(e.anchorMap[e.anchor]=e.result);break}}else if("!"!==e.tag){if(Ql.call(e.typeMap[e.kind||"fallback"],e.tag))u=e.typeMap[e.kind||"fallback"][e.tag];else for(u=null,l=0,d=(c=e.typeMap.multi[e.kind||"fallback"]).length;l<d;l+=1)if(e.tag.slice(0,c[l].tag.length)===c[l].tag){u=c[l];break}u||_d(e,"unknown tag !<"+e.tag+">"),null!==e.result&&u.kind!==e.kind&&_d(e,"unacceptable node kind for !<"+e.tag+'> tag; it should be "'+u.kind+'", not "'+e.kind+'"'),u.resolve(e.result,e.tag)?(e.result=u.construct(e.result,e.tag),null!==e.anchor&&(e.anchorMap[e.anchor]=e.result)):_d(e,"cannot resolve a node with !<"+e.tag+"> explicit tag")}return null!==e.listener&&e.listener("close",e),null!==e.tag||null!==e.anchor||f}function Ld(e){var t,i,a,n,o=e.position,s=!1;for(e.version=null,e.checkLineBreaks=e.legacy,e.tagMap=Object.create(null),e.anchorMap=Object.create(null);0!==(n=e.input.charCodeAt(e.position))&&(Cd(e,!0,-1),n=e.input.charCodeAt(e.position),!(e.lineIndent>0||37!==n));){for(s=!0,n=e.input.charCodeAt(++e.position),t=e.position;0!==n&&!sd(n);)n=e.input.charCodeAt(++e.position);for(a=[],(i=e.input.slice(t,e.position)).length<1&&_d(e,"directive name must not be less than one character in length");0!==n;){for(;od(n);)n=e.input.charCodeAt(++e.position);if(35===n){do{n=e.input.charCodeAt(++e.position)}while(0!==n&&!nd(n));break}if(nd(n))break;for(t=e.position;0!==n&&!sd(n);)n=e.input.charCodeAt(++e.position);a.push(e.input.slice(t,e.position))}0!==n&&wd(e),Ql.call(kd,i)?kd[i](e,i,a):yd(e,'unknown document directive "'+i+'"')}Cd(e,!0,-1),0===e.lineIndent&&45===e.input.charCodeAt(e.position)&&45===e.input.charCodeAt(e.position+1)&&45===e.input.charCodeAt(e.position+2)?(e.position+=3,Cd(e,!0,-1)):s&&_d(e,"directives end mark is expected"),Td(e,e.lineIndent-1,4,!1,!0),Cd(e,!0,-1),e.checkLineBreaks&&Xl.test(e.input.slice(o,e.position))&&yd(e,"non-ASCII line breaks are interpreted as content"),e.documents.push(e.result),e.position===e.lineStart&&Ad(e)?46===e.input.charCodeAt(e.position)&&(e.position+=3,Cd(e,!0,-1)):e.position<e.length-1&&_d(e,"end of the stream or a document separator is expected")}function Od(e,t){t=t||{},0!==(e=String(e)).length&&(10!==e.charCodeAt(e.length-1)&&13!==e.charCodeAt(e.length-1)&&(e+="\n"),65279===e.charCodeAt(0)&&(e=e.slice(1)));var i=new fd(e,t),a=e.indexOf("\0");for(-1!==a&&(i.position=a,_d(i,"null byte is not allowed in input")),i.input+="\0";32===i.input.charCodeAt(i.position);)i.lineIndent+=1,i.position+=1;for(;i.position<i.length-1;)Ld(i);return i.documents}var Md={loadAll:function(e,t,i){null!==t&&"object"==typeof t&&void 0===i&&(i=t,t=null);var a=Od(e,i);if("function"!=typeof t)return a;for(var n=0,o=a.length;n<o;n+=1)t(a[n])},load:function(e,t){var i=Od(e,t);if(0!==i.length){if(1===i.length)return i[0];throw new gl("expected a single document in the stream, but found more")}}},Pd=Object.prototype.toString,Fd=Object.prototype.hasOwnProperty,Dd={0:"\\0",7:"\\a",8:"\\b",9:"\\t",10:"\\n",11:"\\v",12:"\\f",13:"\\r",27:"\\e",34:'\\"',92:"\\\\",133:"\\N",160:"\\_",8232:"\\L",8233:"\\P"},Bd=["y","Y","yes","Yes","YES","on","On","ON","n","N","no","No","NO","off","Off","OFF"],Nd=/^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;function Vd(e){var t,i,a;if(t=e.toString(16).toUpperCase(),e<=255)i="x",a=2;else if(e<=65535)i="u",a=4;else{if(!(e<=4294967295))throw new gl("code point within a string may not be greater than 0xFFFFFFFF");i="U",a=8}return"\\"+i+vl.repeat("0",a-t.length)+t}function qd(e){this.schema=e.schema||Zl,this.indent=Math.max(1,e.indent||2),this.noArrayIndent=e.noArrayIndent||!1,this.skipInvalid=e.skipInvalid||!1,this.flowLevel=vl.isNothing(e.flowLevel)?-1:e.flowLevel,this.styleMap=function(e,t){var i,a,n,o,s,r,l;if(null===t)return{};for(i={},n=0,o=(a=Object.keys(t)).length;n<o;n+=1)s=a[n],r=String(t[s]),"!!"===s.slice(0,2)&&(s="tag:yaml.org,2002:"+s.slice(2)),(l=e.compiledTypeMap.fallback[s])&&Fd.call(l.styleAliases,r)&&(r=l.styleAliases[r]),i[s]=r;return i}(this.schema,e.styles||null),this.sortKeys=e.sortKeys||!1,this.lineWidth=e.lineWidth||80,this.noRefs=e.noRefs||!1,this.noCompatMode=e.noCompatMode||!1,this.condenseFlow=e.condenseFlow||!1,this.quotingType='"'===e.quotingType?2:1,this.forceQuotes=e.forceQuotes||!1,this.replacer="function"==typeof e.replacer?e.replacer:null,this.implicitTypes=this.schema.compiledImplicit,this.explicitTypes=this.schema.compiledExplicit,this.tag=null,this.result="",this.duplicates=[],this.usedDuplicates=null}function jd(e,t){for(var i,a=vl.repeat(" ",t),n=0,o=-1,s="",r=e.length;n<r;)-1===(o=e.indexOf("\n",n))?(i=e.slice(n),n=r):(i=e.slice(n,o+1),n=o+1),i.length&&"\n"!==i&&(s+=a),s+=i;return s}function Rd(e,t){return"\n"+vl.repeat(" ",e.indent*t)}function Ud(e){return 32===e||9===e}function Hd(e){return 32<=e&&e<=126||161<=e&&e<=55295&&8232!==e&&8233!==e||57344<=e&&e<=65533&&65279!==e||65536<=e&&e<=1114111}function Gd(e){return Hd(e)&&65279!==e&&13!==e&&10!==e}function Wd(e,t,i){var a=Gd(e),n=a&&!Ud(e);return(i?a:a&&44!==e&&91!==e&&93!==e&&123!==e&&125!==e)&&35!==e&&!(58===t&&!n)||Gd(t)&&!Ud(t)&&35===e||58===t&&n}function Kd(e,t){var i,a=e.charCodeAt(t);return a>=55296&&a<=56319&&t+1<e.length&&(i=e.charCodeAt(t+1))>=56320&&i<=57343?1024*(a-55296)+i-56320+65536:a}function Yd(e){return/^\n* /.test(e)}function Zd(e,t,i,a,n,o,s,r){var l,d=0,c=null,u=!1,h=!1,p=-1!==a,v=-1,m=function(e){return Hd(e)&&65279!==e&&!Ud(e)&&45!==e&&63!==e&&58!==e&&44!==e&&91!==e&&93!==e&&123!==e&&125!==e&&35!==e&&38!==e&&42!==e&&33!==e&&124!==e&&61!==e&&62!==e&&39!==e&&34!==e&&37!==e&&64!==e&&96!==e}(Kd(e,0))&&function(e){return!Ud(e)&&58!==e}(Kd(e,e.length-1));if(t||s)for(l=0;l<e.length;d>=65536?l+=2:l++){if(!Hd(d=Kd(e,l)))return 5;m=m&&Wd(d,c,r),c=d}else{for(l=0;l<e.length;d>=65536?l+=2:l++){if(10===(d=Kd(e,l)))u=!0,p&&(h=h||l-v-1>a&&" "!==e[v+1],v=l);else if(!Hd(d))return 5;m=m&&Wd(d,c,r),c=d}h=h||p&&l-v-1>a&&" "!==e[v+1]}return u||h?i>9&&Yd(e)?5:s?2===o?5:2:h?4:3:!m||s||n(e)?2===o?5:2:1}function Qd(e,t,i,a,n){e.dump=function(){if(0===t.length)return 2===e.quotingType?'""':"''";if(!e.noCompatMode&&(-1!==Bd.indexOf(t)||Nd.test(t)))return 2===e.quotingType?'"'+t+'"':"'"+t+"'";var o=e.indent*Math.max(1,i),s=-1===e.lineWidth?-1:Math.max(Math.min(e.lineWidth,40),e.lineWidth-o),r=a||e.flowLevel>-1&&i>=e.flowLevel;switch(Zd(t,r,e.indent,s,(function(t){return function(e,t){var i,a;for(i=0,a=e.implicitTypes.length;i<a;i+=1)if(e.implicitTypes[i].resolve(t))return!0;return!1}(e,t)}),e.quotingType,e.forceQuotes&&!a,n)){case 1:return t;case 2:return"'"+t.replace(/'/g,"''")+"'";case 3:return"|"+Jd(t,e.indent)+Xd(jd(t,o));case 4:return">"+Jd(t,e.indent)+Xd(jd(function(e,t){var i,a,n=/(\n+)([^\n]*)/g,o=(r=e.indexOf("\n"),r=-1!==r?r:e.length,n.lastIndex=r,ec(e.slice(0,r),t)),s="\n"===e[0]||" "===e[0];var r;for(;a=n.exec(e);){var l=a[1],d=a[2];i=" "===d[0],o+=l+(s||i||""===d?"":"\n")+ec(d,t),s=i}return o}(t,s),o));case 5:return'"'+function(e){for(var t,i="",a=0,n=0;n<e.length;a>=65536?n+=2:n++)a=Kd(e,n),!(t=Dd[a])&&Hd(a)?(i+=e[n],a>=65536&&(i+=e[n+1])):i+=t||Vd(a);return i}(t)+'"';default:throw new gl("impossible error: invalid scalar style")}}()}function Jd(e,t){var i=Yd(e)?String(t):"",a="\n"===e[e.length-1];return i+(a&&("\n"===e[e.length-2]||"\n"===e)?"+":a?"":"-")+"\n"}function Xd(e){return"\n"===e[e.length-1]?e.slice(0,-1):e}function ec(e,t){if(""===e||" "===e[0])return e;for(var i,a,n=/ [^ ]/g,o=0,s=0,r=0,l="";i=n.exec(e);)(r=i.index)-o>t&&(a=s>o?s:r,l+="\n"+e.slice(o,a),o=a+1),s=r;return l+="\n",e.length-o>t&&s>o?l+=e.slice(o,s)+"\n"+e.slice(s+1):l+=e.slice(o),l.slice(1)}function tc(e,t,i,a){var n,o,s,r="",l=e.tag;for(n=0,o=i.length;n<o;n+=1)s=i[n],e.replacer&&(s=e.replacer.call(i,String(n),s)),(ac(e,t+1,s,!0,!0,!1,!0)||void 0===s&&ac(e,t+1,null,!0,!0,!1,!0))&&(a&&""===r||(r+=Rd(e,t)),e.dump&&10===e.dump.charCodeAt(0)?r+="-":r+="- ",r+=e.dump);e.tag=l,e.dump=r||"[]"}function ic(e,t,i){var a,n,o,s,r,l;for(o=0,s=(n=i?e.explicitTypes:e.implicitTypes).length;o<s;o+=1)if(((r=n[o]).instanceOf||r.predicate)&&(!r.instanceOf||"object"==typeof t&&t instanceof r.instanceOf)&&(!r.predicate||r.predicate(t))){if(i?r.multi&&r.representName?e.tag=r.representName(t):e.tag=r.tag:e.tag="?",r.represent){if(l=e.styleMap[r.tag]||r.defaultStyle,"[object Function]"===Pd.call(r.represent))a=r.represent(t,l);else{if(!Fd.call(r.represent,l))throw new gl("!<"+r.tag+'> tag resolver accepts not "'+l+'" style');a=r.represent[l](t,l)}e.dump=a}return!0}return!1}function ac(e,t,i,a,n,o,s){e.tag=null,e.dump=i,ic(e,i,!1)||ic(e,i,!0);var r,l=Pd.call(e.dump),d=a;a&&(a=e.flowLevel<0||e.flowLevel>t);var c,u,h="[object Object]"===l||"[object Array]"===l;if(h&&(u=-1!==(c=e.duplicates.indexOf(i))),(null!==e.tag&&"?"!==e.tag||u||2!==e.indent&&t>0)&&(n=!1),u&&e.usedDuplicates[c])e.dump="*ref_"+c;else{if(h&&u&&!e.usedDuplicates[c]&&(e.usedDuplicates[c]=!0),"[object Object]"===l)a&&0!==Object.keys(e.dump).length?(!function(e,t,i,a){var n,o,s,r,l,d,c="",u=e.tag,h=Object.keys(i);if(!0===e.sortKeys)h.sort();else if("function"==typeof e.sortKeys)h.sort(e.sortKeys);else if(e.sortKeys)throw new gl("sortKeys must be a boolean or a function");for(n=0,o=h.length;n<o;n+=1)d="",a&&""===c||(d+=Rd(e,t)),r=i[s=h[n]],e.replacer&&(r=e.replacer.call(i,s,r)),ac(e,t+1,s,!0,!0,!0)&&((l=null!==e.tag&&"?"!==e.tag||e.dump&&e.dump.length>1024)&&(e.dump&&10===e.dump.charCodeAt(0)?d+="?":d+="? "),d+=e.dump,l&&(d+=Rd(e,t)),ac(e,t+1,r,!0,l)&&(e.dump&&10===e.dump.charCodeAt(0)?d+=":":d+=": ",c+=d+=e.dump));e.tag=u,e.dump=c||"{}"}(e,t,e.dump,n),u&&(e.dump="&ref_"+c+e.dump)):(!function(e,t,i){var a,n,o,s,r,l="",d=e.tag,c=Object.keys(i);for(a=0,n=c.length;a<n;a+=1)r="",""!==l&&(r+=", "),e.condenseFlow&&(r+='"'),s=i[o=c[a]],e.replacer&&(s=e.replacer.call(i,o,s)),ac(e,t,o,!1,!1)&&(e.dump.length>1024&&(r+="? "),r+=e.dump+(e.condenseFlow?'"':"")+":"+(e.condenseFlow?"":" "),ac(e,t,s,!1,!1)&&(l+=r+=e.dump));e.tag=d,e.dump="{"+l+"}"}(e,t,e.dump),u&&(e.dump="&ref_"+c+" "+e.dump));else if("[object Array]"===l)a&&0!==e.dump.length?(e.noArrayIndent&&!s&&t>0?tc(e,t-1,e.dump,n):tc(e,t,e.dump,n),u&&(e.dump="&ref_"+c+e.dump)):(!function(e,t,i){var a,n,o,s="",r=e.tag;for(a=0,n=i.length;a<n;a+=1)o=i[a],e.replacer&&(o=e.replacer.call(i,String(a),o)),(ac(e,t,o,!1,!1)||void 0===o&&ac(e,t,null,!1,!1))&&(""!==s&&(s+=","+(e.condenseFlow?"":" ")),s+=e.dump);e.tag=r,e.dump="["+s+"]"}(e,t,e.dump),u&&(e.dump="&ref_"+c+" "+e.dump));else{if("[object String]"!==l){if("[object Undefined]"===l)return!1;if(e.skipInvalid)return!1;throw new gl("unacceptable kind of an object to dump "+l)}"?"!==e.tag&&Qd(e,e.dump,t,o,d)}null!==e.tag&&"?"!==e.tag&&(r=encodeURI("!"===e.tag[0]?e.tag.slice(1):e.tag).replace(/!/g,"%21"),r="!"===e.tag[0]?"!"+r:"tag:yaml.org,2002:"===r.slice(0,18)?"!!"+r.slice(18):"!<"+r+">",e.dump=r+" "+e.dump)}return!0}function nc(e,t){var i,a,n=[],o=[];for(oc(e,n,o),i=0,a=o.length;i<a;i+=1)t.duplicates.push(n[o[i]]);t.usedDuplicates=new Array(a)}function oc(e,t,i){var a,n,o;if(null!==e&&"object"==typeof e)if(-1!==(n=t.indexOf(e)))-1===i.indexOf(n)&&i.push(n);else if(t.push(e),Array.isArray(e))for(n=0,o=e.length;n<o;n+=1)oc(e[n],t,i);else for(n=0,o=(a=Object.keys(e)).length;n<o;n+=1)oc(e[a[n]],t,i)}var sc=Zl,rc=Md.load,lc={dump:function(e,t){var i=new qd(t=t||{});i.noRefs||nc(e,i);var a=e;return i.replacer&&(a=i.replacer.call({"":a},"",a)),ac(i,0,a,!0,!0)?i.dump+"\n":""}}.dump;let dc;const cc={key:"Mod-s",run:e=>(o(e.dom,"editor-save"),!0)},uc=e=>{const t=document.createElement("ha-icon");return t.icon=e.label,t};f([A("ha-code-editor")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",key:"codemirror",value:void 0},{kind:"field",decorators:[_()],key:"mode",value:()=>"yaml"},{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"autofocus",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"readOnly",value:()=>!1},{kind:"field",decorators:[_({type:Boolean,attribute:"autocomplete-entities"})],key:"autocompleteEntities",value:()=>!1},{kind:"field",decorators:[_({type:Boolean,attribute:"autocomplete-icons"})],key:"autocompleteIcons",value:()=>!1},{kind:"field",decorators:[_()],key:"error",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_value",value:()=>""},{kind:"field",key:"_loadedCodeMirror",value:void 0},{kind:"field",key:"_iconList",value:void 0},{kind:"set",key:"value",value:function(e){this._value=e}},{kind:"get",key:"value",value:function(){return this.codemirror?this.codemirror.state.doc.toString():this._value}},{kind:"get",key:"hasComments",value:function(){if(!this.codemirror||!this._loadedCodeMirror)return!1;const e=this._loadedCodeMirror.HighlightStyle.get(this.codemirror.state,this._loadedCodeMirror.tags.comment);return!!this.shadowRoot.querySelector(`span.${e}`)}},{kind:"method",key:"connectedCallback",value:function(){k(b(i.prototype),"connectedCallback",this).call(this),this.codemirror&&!1!==this.autofocus&&this.codemirror.focus()}},{kind:"method",key:"update",value:function(e){k(b(i.prototype),"update",this).call(this,e),this.codemirror&&(e.has("mode")&&this.codemirror.dispatch({effects:this._loadedCodeMirror.langCompartment.reconfigure(this._mode)}),e.has("readOnly")&&this.codemirror.dispatch({effects:this._loadedCodeMirror.readonlyCompartment.reconfigure(this._loadedCodeMirror.EditorView.editable.of(!this.readOnly))}),e.has("_value")&&this._value!==this.value&&this.codemirror.dispatch({changes:{from:0,to:this.codemirror.state.doc.length,insert:this._value}}),e.has("error")&&this.classList.toggle("error-state",this.error))}},{kind:"method",key:"firstUpdated",value:function(e){k(b(i.prototype),"firstUpdated",this).call(this,e),this._blockKeyboardShortcuts(),this._load()}},{kind:"get",key:"_mode",value:function(){return this._loadedCodeMirror.langs[this.mode]}},{kind:"method",key:"_load",value:async function(){this._loadedCodeMirror=await(async()=>(dc||(dc=import("./c.10c7d0ce.js")),dc))();const e=[this._loadedCodeMirror.lineNumbers(),this._loadedCodeMirror.EditorState.allowMultipleSelections.of(!0),this._loadedCodeMirror.history(),this._loadedCodeMirror.highlightSelectionMatches(),this._loadedCodeMirror.highlightActiveLine(),this._loadedCodeMirror.drawSelection(),this._loadedCodeMirror.rectangularSelection(),this._loadedCodeMirror.keymap.of([...this._loadedCodeMirror.defaultKeymap,...this._loadedCodeMirror.searchKeymap,...this._loadedCodeMirror.historyKeymap,...this._loadedCodeMirror.tabKeyBindings,cc]),this._loadedCodeMirror.langCompartment.of(this._mode),this._loadedCodeMirror.theme,this._loadedCodeMirror.Prec.fallback(this._loadedCodeMirror.highlightStyle),this._loadedCodeMirror.readonlyCompartment.of(this._loadedCodeMirror.EditorView.editable.of(!this.readOnly)),this._loadedCodeMirror.EditorView.updateListener.of((e=>this._onUpdate(e)))];if(!this.readOnly){const t=[];this.autocompleteEntities&&this.hass&&t.push(this._entityCompletions.bind(this)),this.autocompleteIcons&&t.push(this._mdiCompletions.bind(this)),t.length>0&&e.push(this._loadedCodeMirror.autocompletion({override:t,maxRenderedOptions:10}))}this.codemirror=new this._loadedCodeMirror.EditorView({state:this._loadedCodeMirror.EditorState.create({doc:this._value,extensions:e}),root:this.shadowRoot,parent:this.shadowRoot})}},{kind:"field",key:"_getStates",value:()=>n((e=>{if(!e)return[];return Object.keys(e).map((t=>({type:"variable",label:t,detail:e[t].attributes.friendly_name,info:`State: ${e[t].state}`})))}))},{kind:"method",key:"_entityCompletions",value:function(e){const t=e.matchBefore(/[a-z_]{3,}\.\w*/);if(!t||t.from===t.to&&!e.explicit)return null;const i=this._getStates(this.hass.states);return i&&i.length?{from:Number(t.from),options:i,span:/^[a-z_]{3,}\.\w*$/}:null}},{kind:"field",key:"_getIconItems",value(){return async()=>{if(!this._iconList){let e;e=[],this._iconList=e.map((e=>({type:"variable",label:`mdi:${e.name}`,detail:e.keywords.join(", "),info:uc})))}return this._iconList}}},{kind:"method",key:"_mdiCompletions",value:async function(e){const t=e.matchBefore(/mdi:\S*/);if(!t||t.from===t.to&&!e.explicit)return null;const i=await this._getIconItems();return{from:Number(t.from),options:i,span:/^mdi:\S*$/}}},{kind:"method",key:"_blockKeyboardShortcuts",value:function(){this.addEventListener("keydown",(e=>e.stopPropagation()))}},{kind:"method",key:"_onUpdate",value:function(e){if(!e.docChanged)return;const t=this.value;t!==this._value&&(this._value=t,o(this,"value-changed",{value:this._value}))}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      :host(.error-state) .cm-gutters {
        border-color: var(--error-state-color, red);
      }
    `}}]}}),ha);f([A("ha-yaml-editor")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"yamlSchema",value:()=>sc},{kind:"field",decorators:[_()],key:"defaultValue",value:void 0},{kind:"field",decorators:[_()],key:"isValid",value:()=>!0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"readOnly",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_yaml",value:()=>""},{kind:"method",key:"setValue",value:function(e){try{this._yaml=e&&!(e=>{if("object"!=typeof e)return!1;for(const t in e)if(Object.prototype.hasOwnProperty.call(e,t))return!1;return!0})(e)?lc(e,{schema:this.yamlSchema,quotingType:'"'}):""}catch(t){console.error(t,e),alert(`There was an error converting to YAML: ${t}`)}}},{kind:"method",key:"firstUpdated",value:function(){this.defaultValue&&this.setValue(this.defaultValue)}},{kind:"method",key:"render",value:function(){return void 0===this._yaml?x``:x`
      ${this.label?x`<p>${this.label}${this.required?" *":""}</p>`:""}
      <ha-code-editor
        .hass=${this.hass}
        .value=${this._yaml}
        .readOnly=${this.readOnly}
        mode="yaml"
        autocomplete-entities
        autocomplete-icons
        .error=${!1===this.isValid}
        @value-changed=${this._onChange}
        dir="ltr"
      ></ha-code-editor>
    `}},{kind:"method",key:"_onChange",value:function(e){let t;e.stopPropagation(),this._yaml=e.detail.value;let i=!0;if(this._yaml)try{t=rc(this._yaml,{schema:this.yamlSchema})}catch(e){i=!1}else t={};this.value=t,this.isValid=i,o(this,"value-changed",{value:t,isValid:i})}},{kind:"get",key:"yaml",value:function(){return this._yaml}}]}}),g);f([A("ha-progress-button")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"progress",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"raised",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_result",value:void 0},{kind:"method",key:"render",value:function(){const e=this._result||this.progress;return x`
      <mwc-button
        ?raised=${this.raised}
        .disabled=${this.disabled||this.progress}
        @click=${this._buttonTapped}
        class=${this._result||""}
      >
        <slot></slot>
      </mwc-button>
      ${e?x`
            <div class="progress">
              ${"success"===this._result?x`<ha-svg-icon .path=${pa}></ha-svg-icon>`:"error"===this._result?x`<ha-svg-icon .path=${va}></ha-svg-icon>`:this.progress?x`
                    <ha-circular-progress
                      size="small"
                      active
                    ></ha-circular-progress>
                  `:""}
            </div>
          `:""}
    `}},{kind:"method",key:"actionSuccess",value:function(){this._setResult("success")}},{kind:"method",key:"actionError",value:function(){this._setResult("error")}},{kind:"method",key:"_setResult",value:function(e){this._result=e,setTimeout((()=>{this._result=void 0}),2e3)}},{kind:"method",key:"_buttonTapped",value:function(e){this.progress&&e.stopPropagation()}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      :host {
        outline: none;
        display: inline-block;
        position: relative;
      }

      mwc-button {
        transition: all 1s;
      }

      mwc-button.success {
        --mdc-theme-primary: white;
        background-color: var(--success-color);
        transition: none;
        border-radius: 4px;
        pointer-events: none;
      }

      mwc-button[raised].success {
        --mdc-theme-primary: var(--success-color);
        --mdc-theme-on-primary: white;
      }

      mwc-button.error {
        --mdc-theme-primary: white;
        background-color: var(--error-color);
        transition: none;
        border-radius: 4px;
        pointer-events: none;
      }

      mwc-button[raised].error {
        --mdc-theme-primary: var(--error-color);
        --mdc-theme-on-primary: white;
      }

      .progress {
        bottom: 4px;
        position: absolute;
        text-align: center;
        top: 4px;
        width: 100%;
      }

      ha-svg-icon {
        color: white;
      }

      mwc-button.success slot,
      mwc-button.error slot {
        visibility: hidden;
      }
    `}}]}}),g);const hc=e=>e.preventDefault();f([A("ha-automation-condition-row")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"condition",value:void 0},{kind:"field",decorators:[Qi()],key:"_yamlMode",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_warnings",value:void 0},{kind:"method",key:"render",value:function(){return this.condition?x`
      <ha-card outlined>
        ${!1===this.condition.enabled?x`<div class="disabled-bar">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.disabled")}
            </div>`:""}

        <ha-expansion-panel leftChevron>
          <div slot="header">
            <ha-svg-icon
              class="condition-icon"
              .path=${cl[this.condition.condition]}
            ></ha-svg-icon>
            ${us(vs(this.condition,this.hass))}
          </div>

          <ha-progress-button slot="icons" @click=${this._testCondition}>
            ${this.hass.localize("ui.panel.config.automation.editor.conditions.test")}
          </ha-progress-button>
          <ha-button-menu
            slot="icons"
            fixed
            corner="BOTTOM_START"
            @action=${this._handleAction}
            @click=${hc}
          >
            <ha-icon-button
              slot="trigger"
              .label=${this.hass.localize("ui.common.menu")}
              .path=${ma}
            >
            </ha-icon-button>

            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.conditions.rename")}
              <ha-svg-icon slot="graphic" .path=${fa}></ha-svg-icon>
            </mwc-list-item>
            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.duplicate")}
              <ha-svg-icon
                slot="graphic"
                .path=${ga}
              ></ha-svg-icon>
            </mwc-list-item>

            <li divider role="separator"></li>

            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.edit_ui")}
              ${this._yamlMode?"":x`<ha-svg-icon
                    slot="graphic"
                    .path=${_a}
                  ></ha-svg-icon>`}
            </mwc-list-item>

            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.edit_yaml")}
              ${this._yamlMode?x`<ha-svg-icon
                    slot="graphic"
                    .path=${_a}
                  ></ha-svg-icon>`:""}
            </mwc-list-item>

            <li divider role="separator"></li>

            <mwc-list-item graphic="icon">
              ${!1===this.condition.enabled?this.hass.localize("ui.panel.config.automation.editor.actions.enable"):this.hass.localize("ui.panel.config.automation.editor.actions.disable")}
              <ha-svg-icon
                slot="graphic"
                .path=${!1===this.condition.enabled?ya:ka}
              ></ha-svg-icon>
            </mwc-list-item>
            <mwc-list-item class="warning" graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.delete")}
              <ha-svg-icon
                class="warning"
                slot="graphic"
                .path=${ea}
              ></ha-svg-icon>
            </mwc-list-item>
          </ha-button-menu>

          <div
            class=${ba({"card-content":!0,disabled:!1===this.condition.enabled})}
          >
            ${this._warnings?x`<ha-alert
                  alert-type="warning"
                  .title=${this.hass.localize("ui.errors.config.editor_not_supported")}
                >
                  ${this._warnings.length>0&&void 0!==this._warnings[0]?x` <ul>
                        ${this._warnings.map((e=>x`<li>${e}</li>`))}
                      </ul>`:""}
                  ${this.hass.localize("ui.errors.config.edit_in_yaml_supported")}
                </ha-alert>`:""}
            <ha-automation-condition-editor
              @ui-mode-not-available=${this._handleUiModeNotAvailable}
              @value-changed=${this._handleChangeEvent}
              .yamlMode=${this._yamlMode}
              .hass=${this.hass}
              .condition=${this.condition}
            ></ha-automation-condition-editor>
          </div>
        </ha-expansion-panel>
      </ha-card>
    `:x``}},{kind:"method",key:"_handleUiModeNotAvailable",value:function(e){e.stopPropagation(),this._warnings=co(this.hass,e.detail).warnings,this._yamlMode||(this._yamlMode=!0)}},{kind:"method",key:"_handleChangeEvent",value:function(e){e.detail.yaml&&(this._warnings=void 0)}},{kind:"method",key:"_handleAction",value:async function(e){switch(e.detail.index){case 0:await this._renameCondition();break;case 1:o(this,"duplicate");break;case 2:this._switchUiMode(),this.expand();break;case 3:this._switchYamlMode(),this.expand();break;case 4:this._onDisable();break;case 5:this._onDelete()}}},{kind:"method",key:"_onDisable",value:function(){var e;const t=!(null===(e=this.condition.enabled)||void 0===e||e),i={...this.condition,enabled:t};o(this,"value-changed",{value:i})}},{kind:"method",key:"_onDelete",value:function(){$n(this,{text:this.hass.localize("ui.panel.config.automation.editor.conditions.delete_confirm"),dismissText:this.hass.localize("ui.common.cancel"),confirmText:this.hass.localize("ui.common.delete"),confirm:()=>{o(this,"value-changed",{value:null})}})}},{kind:"method",key:"_switchUiMode",value:function(){this._warnings=void 0,this._yamlMode=!1}},{kind:"method",key:"_switchYamlMode",value:function(){this._warnings=void 0,this._yamlMode=!0}},{kind:"method",key:"_testCondition",value:async function(e){e.preventDefault();const t=this.condition,i=e.target;if(!i.progress){i.progress=!0;try{const e=await uo(this.hass,{condition:t});if(this.condition!==t)return;if(!e.condition.valid)return void wn(this,{title:this.hass.localize("ui.panel.config.automation.editor.conditions.invalid_condition"),text:e.condition.error});let a;try{a=await((e,t,i)=>e.callWS({type:"test_condition",condition:t,variables:i}))(this.hass,t)}catch(e){if(this.condition!==t)return;return void wn(this,{title:this.hass.localize("ui.panel.config.automation.editor.conditions.test_failed"),text:e.message})}if(this.condition!==t)return;a.result?i.actionSuccess():i.actionError()}finally{i.progress=!1}}}},{kind:"method",key:"_renameCondition",value:async function(){const e=await Cn(this,{title:this.hass.localize("ui.panel.config.automation.editor.conditions.change_alias"),inputLabel:this.hass.localize("ui.panel.config.automation.editor.conditions.alias"),inputType:"string",placeholder:us(vs(this.condition,this.hass,!0)),defaultValue:this.condition.alias,confirmText:this.hass.localize("ui.common.submit")}),t={...this.condition};e?t.alias=e:delete t.alias,o(this,"value-changed",{value:t})}},{kind:"method",key:"expand",value:function(){this.updateComplete.then((()=>{this.shadowRoot.querySelector("ha-expansion-panel").expanded=!0}))}},{kind:"get",static:!0,key:"styles",value:function(){return[ia,r`
        ha-button-menu,
        ha-progress-button {
          --mdc-theme-text-primary-on-background: var(--primary-text-color);
        }
        .disabled {
          opacity: 0.5;
          pointer-events: none;
        }
        ha-expansion-panel {
          --expansion-panel-summary-padding: 0 0 0 8px;
          --expansion-panel-content-padding: 0;
        }
        .condition-icon {
          color: var(--sidebar-icon-color);
          padding-right: 8px;
        }
        .card-content {
          padding: 16px;
        }
        .disabled-bar {
          background: var(--divider-color, #e0e0e0);
          text-align: center;
          border-top-right-radius: var(--ha-card-border-radius);
          border-top-left-radius: var(--ha-card-border-radius);
        }
        mwc-list-item[disabled] {
          --mdc-theme-text-primary-on-background: var(--disabled-text-color);
        }
      `]}}]}}),g);const pc=(e,t)=>e.callWS({type:"device_automation/action/list",device_id:t}),vc=(e,t)=>e.callWS({type:"device_automation/condition/list",device_id:t}),mc=(e,t)=>e.callWS({type:"device_automation/trigger/list",device_id:t}),fc=["device_id","domain","entity_id","type","subtype","event","condition","platform"],gc=(e,t)=>{if(typeof e!=typeof t)return!1;for(const i in e)if(fc.includes(i)&&!Object.is(e[i],t[i]))return!1;for(const i in t)if(fc.includes(i)&&!Object.is(e[i],t[i]))return!1;return!0},_c=(e,t)=>{const i=t.entity_id?e.states[t.entity_id]:void 0;return e.localize(`component.${t.domain}.device_automation.action_type.${t.type}`,"entity_name",i?bo(i):t.entity_id||"<unknown>","subtype",t.subtype?e.localize(`component.${t.domain}.device_automation.action_subtype.${t.subtype}`)||t.subtype:"")||(t.subtype?`"${t.subtype}" ${t.type}`:t.type)},yc=(e,t)=>{const i=t.entity_id?e.states[t.entity_id]:void 0;return e.localize(`component.${t.domain}.device_automation.condition_type.${t.type}`,"entity_name",i?bo(i):t.entity_id||"<unknown>","subtype",t.subtype?e.localize(`component.${t.domain}.device_automation.condition_subtype.${t.subtype}`)||t.subtype:"")||(t.subtype?`"${t.subtype}" ${t.type}`:t.type)},kc=(e,t)=>{const i=t.entity_id?e.states[t.entity_id]:void 0;return e.localize(`component.${t.domain}.device_automation.trigger_type.${t.type}`,"entity_name",i?bo(i):t.entity_id||"<unknown>","subtype",t.subtype?e.localize(`component.${t.domain}.device_automation.trigger_subtype.${t.subtype}`)||t.subtype:"")||(t.subtype?`"${t.subtype}" ${t.type}`:t.type)},bc=(e,t)=>{var i,a,n,o;return null===(i=e.metadata)||void 0===i||!i.secondary||null!==(a=t.metadata)&&void 0!==a&&a.secondary?null!==(n=e.metadata)&&void 0!==n&&n.secondary||null===(o=t.metadata)||void 0===o||!o.secondary?0:-1:1},xc="NO_AUTOMATION",$c="UNKNOWN_AUTOMATION";let wc=f(null,(function(e,t){class i extends t{constructor(t,i,a){super(),e(this),this._localizeDeviceAutomation=t,this._fetchDeviceAutomations=i,this._createNoAutomation=a}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"deviceId",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[Qi()],key:"_automations",value:()=>[]},{kind:"field",decorators:[Qi()],key:"_renderEmpty",value:()=>!1},{kind:"get",key:"NO_AUTOMATION_TEXT",value:function(){return this.hass.localize("ui.panel.config.devices.automation.actions.no_actions")}},{kind:"get",key:"UNKNOWN_AUTOMATION_TEXT",value:function(){return this.hass.localize("ui.panel.config.devices.automation.actions.unknown_action")}},{kind:"field",key:"_localizeDeviceAutomation",value:void 0},{kind:"field",key:"_fetchDeviceAutomations",value:void 0},{kind:"field",key:"_createNoAutomation",value:void 0},{kind:"get",key:"_value",value:function(){if(!this.value)return"";if(!this._automations.length)return xc;const e=this._automations.findIndex((e=>gc(e,this.value)));return-1===e?$c:`${this._automations[e].device_id}_${e}`}},{kind:"method",key:"render",value:function(){if(this._renderEmpty)return x``;const e=this._value;return x`
      <ha-select
        .label=${this.label}
        .value=${e}
        @selected=${this._automationChanged}
        .disabled=${0===this._automations.length}
      >
        ${e===xc?x`<mwc-list-item .value=${xc}>
              ${this.NO_AUTOMATION_TEXT}
            </mwc-list-item>`:""}
        ${e===$c?x`<mwc-list-item .value=${$c}>
              ${this.UNKNOWN_AUTOMATION_TEXT}
            </mwc-list-item>`:""}
        ${this._automations.map(((e,t)=>x`
            <mwc-list-item .value=${`${e.device_id}_${t}`}>
              ${this._localizeDeviceAutomation(this.hass,e)}
            </mwc-list-item>
          `))}
      </ha-select>
    `}},{kind:"method",key:"updated",value:function(e){k(b(i.prototype),"updated",this).call(this,e),e.has("deviceId")&&this._updateDeviceInfo()}},{kind:"method",key:"_updateDeviceInfo",value:async function(){this._automations=this.deviceId?(await this._fetchDeviceAutomations(this.hass,this.deviceId)).sort(bc):[],this.value&&this.value.device_id===this.deviceId||this._setValue(this._automations.length?this._automations[0]:this._createNoAutomation(this.deviceId)),this._renderEmpty=!0,await this.updateComplete,this._renderEmpty=!1}},{kind:"method",key:"_automationChanged",value:function(e){const t=e.target.value;if(!t||[$c,xc].includes(t))return;const[i,a]=t.split("_"),n=this._automations[a];n.device_id===i&&this._setValue(n)}},{kind:"method",key:"_setValue",value:function(e){if(this.value&&gc(e,this.value))return;const t={...e};delete t.metadata,o(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-select {
        display: block;
      }
    `}}]}}),g);f([A("ha-device-condition-picker")],(function(e,t){return{F:class extends t{constructor(){super(yc,vc,(e=>({device_id:e||"",condition:"device",domain:"",entity_id:""}))),e(this)}},d:[{kind:"get",key:"NO_AUTOMATION_TEXT",value:function(){return this.hass.localize("ui.panel.config.devices.automation.conditions.no_conditions")}},{kind:"get",key:"UNKNOWN_AUTOMATION_TEXT",value:function(){return this.hass.localize("ui.panel.config.devices.automation.conditions.unknown_condition")}}]}}),wc);const Cc=e=>e.sendMessagePromise({type:"config/area_registry/list"}).then((e=>e.sort(((e,t)=>_s(e.name,t.name))))),Ac=(e,t)=>e.subscribeEvents(un((()=>Cc(e).then((e=>t.setState(e,!0)))),500,!0),"area_registry_updated"),Ic=(e,t)=>xa("_areaRegistry",Cc,Ac,e,t),Ec=(e,t,i)=>e.name_by_user||e.name||i&&((e,t)=>{for(const i of t||[]){const t="string"==typeof i?i:i.entity_id,a=e.states[t];if(a)return bo(a)}})(t,i)||t.localize("ui.panel.config.devices.unnamed_device","type",t.localize(`ui.panel.config.devices.type.${e.entry_type||"device"}`)),zc=e=>e.sendMessagePromise({type:"config/device_registry/list"}),Sc=(e,t)=>e.subscribeEvents(un((()=>zc(e).then((e=>t.setState(e,!0)))),500,!0),"device_registry_updated"),Tc=(e,t)=>xa("_dr",zc,Sc,e,t),Lc=(e,t)=>{const i={};for(const a of t){const t=e[a.entity_id];null!=t&&t.domain&&null!==a.device_id&&(i[a.device_id]||(i[a.device_id]=[]),i[a.device_id].push(t.domain))}return i},Oc=e=>e.sendMessagePromise({type:"config/entity_registry/list"}),Mc=(e,t)=>e.subscribeEvents(un((()=>Oc(e).then((e=>t.setState(e,!0)))),500,!0),"entity_registry_updated"),Pc=(e,t)=>xa("_entityRegistry",Oc,Mc,e,t),Fc=e=>f(null,(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",key:"hassSubscribeRequiredHostProps",value:void 0},{kind:"field",key:"__unsubs",value:void 0},{kind:"method",key:"connectedCallback",value:function(){k(b(i.prototype),"connectedCallback",this).call(this),this.__checkSubscribed()}},{kind:"method",key:"disconnectedCallback",value:function(){if(k(b(i.prototype),"disconnectedCallback",this).call(this),this.__unsubs){for(;this.__unsubs.length;){const e=this.__unsubs.pop();e instanceof Promise?e.then((e=>e())):e()}this.__unsubs=void 0}}},{kind:"method",key:"updated",value:function(e){if(k(b(i.prototype),"updated",this).call(this,e),e.has("hass"))this.__checkSubscribed();else if(this.hassSubscribeRequiredHostProps)for(const t of e.keys())if(this.hassSubscribeRequiredHostProps.includes(t))return void this.__checkSubscribed()}},{kind:"method",key:"hassSubscribe",value:function(){return[]}},{kind:"method",key:"__checkSubscribed",value:function(){var e;void 0!==this.__unsubs||!this.isConnected||void 0===this.hass||null!==(e=this.hassSubscribeRequiredHostProps)&&void 0!==e&&e.some((e=>void 0===this[e]))||(this.__unsubs=this.hassSubscribe())}}]}}),e),Dc=e=>x`<mwc-list-item
  .twoline=${!!e.area}
>
  <span>${e.name}</span>
  <span slot="secondary">${e.area}</span>
</mwc-list-item>`;f([A("ha-device-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_()],key:"devices",value:void 0},{kind:"field",decorators:[_()],key:"areas",value:void 0},{kind:"field",decorators:[_()],key:"entities",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-domains"})],key:"includeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"exclude-domains"})],key:"excludeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-device-classes"})],key:"includeDeviceClasses",value:void 0},{kind:"field",decorators:[_()],key:"deviceFilter",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:void 0},{kind:"field",decorators:[Qi()],key:"_opened",value:void 0},{kind:"field",decorators:[y("ha-combo-box",!0)],key:"comboBox",value:void 0},{kind:"field",key:"_init",value:()=>!1},{kind:"field",key:"_getDevices",value(){return n(((e,t,i,a,n,o,s)=>{if(!e.length)return[{id:"no_devices",area:"",name:this.hass.localize("ui.components.device-picker.no_devices")}];const r={};if(a||n||o)for(const e of i)e.device_id&&(e.device_id in r||(r[e.device_id]=[]),r[e.device_id].push(e));const l={};for(const e of t)l[e.area_id]=e;let d=e.filter((e=>e.id===this.value||!e.disabled_by));a&&(d=d.filter((e=>{const t=r[e.id];return!(!t||!t.length)&&r[e.id].some((e=>a.includes(gs(e.entity_id))))}))),n&&(d=d.filter((e=>{const t=r[e.id];return!t||!t.length||i.every((e=>!n.includes(gs(e.entity_id))))}))),o&&(d=d.filter((e=>{const t=r[e.id];return!(!t||!t.length)&&r[e.id].some((e=>{const t=this.hass.states[e.entity_id];return!!t&&(t.attributes.device_class&&o.includes(t.attributes.device_class))}))}))),s&&(d=d.filter((e=>e.id===this.value||s(e))));const c=d.map((e=>({id:e.id,name:Ec(e,this.hass,r[e.id]),area:e.area_id&&l[e.area_id]?l[e.area_id].name:this.hass.localize("ui.components.device-picker.no_area")})));return c.length?1===c.length?c:c.sort(((e,t)=>_s(e.name||"",t.name||""))):[{id:"no_devices",area:"",name:this.hass.localize("ui.components.device-picker.no_match")}]}))}},{kind:"method",key:"open",value:function(){var e;null===(e=this.comboBox)||void 0===e||e.open()}},{kind:"method",key:"focus",value:function(){var e;null===(e=this.comboBox)||void 0===e||e.focus()}},{kind:"method",key:"hassSubscribe",value:function(){return[Tc(this.hass.connection,(e=>{this.devices=e})),Ic(this.hass.connection,(e=>{this.areas=e})),Pc(this.hass.connection,(e=>{this.entities=e}))]}},{kind:"method",key:"updated",value:function(e){(!this._init&&this.devices&&this.areas&&this.entities||e.has("_opened")&&this._opened)&&(this._init=!0,this.comboBox.items=this._getDevices(this.devices,this.areas,this.entities,this.includeDomains,this.excludeDomains,this.includeDeviceClasses,this.deviceFilter))}},{kind:"method",key:"render",value:function(){return this.devices&&this.areas&&this.entities?x`
      <ha-combo-box
        .hass=${this.hass}
        .label=${void 0===this.label&&this.hass?this.hass.localize("ui.components.device-picker.device"):this.label}
        .value=${this._value}
        .helper=${this.helper}
        .renderer=${Dc}
        .disabled=${this.disabled}
        .required=${this.required}
        item-value-path="id"
        item-label-path="name"
        @opened-changed=${this._openedChanged}
        @value-changed=${this._deviceChanged}
      ></ha-combo-box>
    `:x``}},{kind:"get",key:"_value",value:function(){return this.value||""}},{kind:"method",key:"_deviceChanged",value:function(e){e.stopPropagation();let t=e.detail.value;"no_devices"===t&&(t=""),t!==this._value&&this._setValue(t)}},{kind:"method",key:"_openedChanged",value:function(e){this._opened=e.detail.value}},{kind:"method",key:"_setValue",value:function(e){this.value=e,setTimeout((()=>{o(this,"value-changed",{value:e}),o(this,"change")}),0)}}]}}),Fc(g)),f([A("ha-automation-condition-device")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({type:Object})],key:"condition",value:void 0},{kind:"field",decorators:[Qi()],key:"_deviceId",value:void 0},{kind:"field",decorators:[Qi()],key:"_capabilities",value:void 0},{kind:"field",key:"_origCondition",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{device_id:"",domain:"",entity_id:""}}},{kind:"field",key:"_extraFieldsData",value:()=>n(((e,t)=>{const i={};return t.extra_fields.forEach((t=>{void 0!==e[t.name]&&(i[t.name]=e[t.name])})),i}))},{kind:"method",key:"render",value:function(){var e;const t=this._deviceId||this.condition.device_id;return x`
      <ha-device-picker
        .value=${t}
        @value-changed=${this._devicePicked}
        .hass=${this.hass}
        label=${this.hass.localize("ui.panel.config.automation.editor.conditions.type.device.label")}
      ></ha-device-picker>
      <ha-device-condition-picker
        .value=${this.condition}
        .deviceId=${t}
        @value-changed=${this._deviceConditionPicked}
        .hass=${this.hass}
        label=${this.hass.localize("ui.panel.config.automation.editor.conditions.type.device.condition")}
      ></ha-device-condition-picker>
      ${null!==(e=this._capabilities)&&void 0!==e&&e.extra_fields?x`
            <ha-form
              .hass=${this.hass}
              .data=${this._extraFieldsData(this.condition,this._capabilities)}
              .schema=${this._capabilities.extra_fields}
              .computeLabel=${this._extraFieldsComputeLabelCallback(this.hass.localize)}
              @value-changed=${this._extraFieldsChanged}
            ></ha-form>
          `:""}
    `}},{kind:"method",key:"firstUpdated",value:function(){this._capabilities||this._getCapabilities(),this.condition&&(this._origCondition=this.condition)}},{kind:"method",key:"updated",value:function(e){const t=e.get("condition");t&&!gc(t,this.condition)&&this._getCapabilities()}},{kind:"method",key:"_getCapabilities",value:async function(){const e=this.condition;this._capabilities=e.domain?await((e,t)=>e.callWS({type:"device_automation/condition/capabilities",condition:t}))(this.hass,e):void 0}},{kind:"method",key:"_devicePicked",value:function(e){e.stopPropagation(),this._deviceId=e.target.value,void 0===this._deviceId&&o(this,"value-changed",{value:{...i.defaultConfig,condition:"device"}})}},{kind:"method",key:"_deviceConditionPicked",value:function(e){e.stopPropagation();let t=e.detail.value;this._origCondition&&gc(this._origCondition,t)&&(t=this._origCondition),o(this,"value-changed",{value:t})}},{kind:"method",key:"_extraFieldsChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.condition,...e.detail.value}})}},{kind:"method",key:"_extraFieldsComputeLabelCallback",value:function(e){return t=>e(`ui.panel.config.automation.editor.conditions.type.device.extra_fields.${t.name}`)||t.name}},{kind:"field",static:!0,key:"styles",value:()=>r`
    ha-device-picker {
      display: block;
      margin-bottom: 24px;
    }
  `}]}}),g),f([A("ha-automation-condition-numeric_state")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"condition",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{entity_id:""}}},{kind:"field",key:"_schema",value:()=>n((e=>[{name:"entity_id",required:!0,selector:{entity:{}}},{name:"attribute",selector:{attribute:{entity_id:e,hide_attributes:["access_token","auto_update","available_modes","away_mode","changed_by","code_format","color_modes","current_activity","device_class","editable","effect_list","effect","entity_picture","fan_mode","fan_modes","fan_speed_list","forecast","friendly_name","frontend_stream_type","has_date","has_time","hs_color","hvac_mode","hvac_modes","icon","media_album_name","media_artist","media_content_type","media_position_updated_at","media_title","next_dawn","next_dusk","next_midnight","next_noon","next_rising","next_setting","operation_list","operation_mode","options","preset_mode","preset_modes","release_notes","release_summary","release_url","restored","rgb_color","rgbw_color","shuffle","sound_mode_list","sound_mode","source_list","source_type","source","state_class","supported_features","swing_mode","swing_mode","swing_modes","title","token","unit_of_measurement","xy_color"]}}},{name:"above",selector:{number:{mode:"box",min:Number.MIN_SAFE_INTEGER,max:Number.MAX_SAFE_INTEGER,step:.1}}},{name:"below",selector:{number:{mode:"box",min:Number.MIN_SAFE_INTEGER,max:Number.MAX_SAFE_INTEGER,step:.1}}},{name:"value_template",selector:{template:{}}}]))},{kind:"method",key:"render",value:function(){const e=this._schema(this.condition.entity_id);return x`
      <ha-form
        .hass=${this.hass}
        .data=${this.condition}
        .schema=${e}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>{switch(e.name){case"entity_id":return this.hass.localize("ui.components.entity.entity-picker.entity");case"attribute":return this.hass.localize("ui.components.entity.entity-attribute-picker.attribute");default:return this.hass.localize(`ui.panel.config.automation.editor.triggers.type.numeric_state.${e.name}`)}}}}]}}),g);const Bc=e=>{if(void 0===e)return;if("object"!=typeof e){if("string"==typeof e||isNaN(e)){const t=(null==e?void 0:e.toString().split(":"))||[];return{hours:Number(t[0])||0,minutes:Number(t[1])||0,seconds:Number(t[2])||0,milliseconds:Number(t[3])||0}}return{seconds:e}}if(!("days"in e))return e;const{days:t,minutes:i,seconds:a,milliseconds:n}=e;let o=e.hours||0;return o=(o||0)+24*(t||0),{hours:o,minutes:i,seconds:a,milliseconds:n}},Nc=no({platform:so(),id:oo(so()),enabled:oo(to())}),Vc=no({days:oo(ao()),hours:oo(ao()),minutes:oo(ao()),seconds:oo(ao())}),qc=no({alias:oo(so()),condition:io("state"),entity_id:oo(so()),attribute:oo(so()),state:oo(so()),for:oo(lo([so(),Vc]))});f([A("ha-automation-condition-state")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"condition",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{entity_id:"",state:""}}},{kind:"field",key:"_schema",value:()=>n(((e,t)=>[{name:"entity_id",required:!0,selector:{entity:{}}},{name:"attribute",selector:{attribute:{entity_id:e,hide_attributes:["access_token","available_modes","color_modes","editable","effect_list","entity_picture","fan_modes","fan_speed_list","forecast","friendly_name","hvac_modes","icon","operation_list","options","preset_modes","sound_mode_list","source_list","state_class","swing_modes","token"]}}},{name:"state",required:!0,selector:{state:{entity_id:e,attribute:t}}},{name:"for",selector:{duration:{}}}]))},{kind:"method",key:"shouldUpdate",value:function(e){if(e.has("condition"))try{Kn(this.condition,qc)}catch(e){return o(this,"ui-mode-not-available",e),!1}return!0}},{kind:"method",key:"render",value:function(){const e=Bc(this.condition.for),t={...this.condition,for:e},i=this._schema(this.condition.entity_id,this.condition.attribute);return x`
      <ha-form
        .hass=${this.hass}
        .data=${t}
        .schema=${i}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;Object.keys(t).forEach((e=>void 0===t[e]||""===t[e]?delete t[e]:{})),t.state||(t.state=""),o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>{switch(e.name){case"entity_id":return this.hass.localize("ui.components.entity.entity-picker.entity");case"attribute":return this.hass.localize("ui.components.entity.entity-attribute-picker.attribute");case"for":return this.hass.localize("ui.panel.config.automation.editor.triggers.type.state.for");default:return this.hass.localize(`ui.panel.config.automation.editor.conditions.type.state.${e.name}`)}}}}]}}),g),f([A("ha-automation-condition-sun")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"condition",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{}}},{kind:"field",key:"_schema",value:()=>n((e=>[{name:"before",type:"select",required:!0,options:[["sunrise",e("ui.panel.config.automation.editor.conditions.type.sun.sunrise")],["sunset",e("ui.panel.config.automation.editor.conditions.type.sun.sunset")]]},{name:"before_offset",selector:{text:{}}},{name:"after",type:"select",required:!0,options:[["sunrise",e("ui.panel.config.automation.editor.conditions.type.sun.sunrise")],["sunset",e("ui.panel.config.automation.editor.conditions.type.sun.sunset")]]},{name:"after_offset",selector:{text:{}}}]))},{kind:"method",key:"render",value:function(){const e=this._schema(this.hass.localize);return x`
      <ha-form
        .schema=${e}
        .data=${this.condition}
        .hass=${this.hass}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.conditions.type.sun.${e.name}`)}}]}}),g);const jc={fromAttribute:e=>null!==e&&(""===e||e),toAttribute:e=>"boolean"==typeof e?e?"":null:e};class Rc extends _n{constructor(){super(...arguments),this.rows=2,this.cols=20,this.charCounter=!1}render(){const e=this.charCounter&&-1!==this.maxLength,t=e&&"internal"===this.charCounter,i=e&&!t,a=!!this.helper||!!this.validationMessage||i,n={"mdc-text-field--disabled":this.disabled,"mdc-text-field--no-label":!this.label,"mdc-text-field--filled":!this.outlined,"mdc-text-field--outlined":this.outlined,"mdc-text-field--end-aligned":this.endAligned,"mdc-text-field--with-internal-counter":t};return x`
      <label class="mdc-text-field mdc-text-field--textarea ${ba(n)}">
        ${this.renderRipple()}
        ${this.outlined?this.renderOutline():this.renderLabel()}
        ${this.renderInput()}
        ${this.renderCharCounter(t)}
        ${this.renderLineRipple()}
      </label>
      ${this.renderHelperText(a,i)}
    `}renderInput(){const e=this.label?"label":void 0,t=-1===this.minLength?void 0:this.minLength,i=-1===this.maxLength?void 0:this.maxLength,a=this.autocapitalize?this.autocapitalize:void 0;return x`
      <textarea
          aria-labelledby=${Xi(e)}
          class="mdc-text-field__input"
          .value="${yn(this.value)}"
          rows="${this.rows}"
          cols="${this.cols}"
          ?disabled="${this.disabled}"
          placeholder="${this.placeholder}"
          ?required="${this.required}"
          ?readonly="${this.readOnly}"
          minlength="${Xi(t)}"
          maxlength="${Xi(i)}"
          name="${Xi(""===this.name?void 0:this.name)}"
          inputmode="${Xi(this.inputMode)}"
          autocapitalize="${Xi(a)}"
          @input="${this.handleInputChange}"
          @blur="${this.onInputBlur}">
      </textarea>`}}$a([y("textarea")],Rc.prototype,"formElement",void 0),$a([_({type:Number})],Rc.prototype,"rows",void 0),$a([_({type:Number})],Rc.prototype,"cols",void 0),$a([_({converter:jc})],Rc.prototype,"charCounter",void 0);const Uc=r`.mdc-text-field{height:100%}.mdc-text-field__input{resize:none}`;f([A("ha-textarea")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"autogrow",value:()=>!1},{kind:"method",key:"updated",value:function(e){k(b(i.prototype),"updated",this).call(this,e),this.autogrow&&e.has("value")&&(this.mdcRoot.dataset.value=this.value+'=​"')}},{kind:"field",static:!0,key:"styles",value:()=>[kn,Uc,r`
      :host([autogrow]) .mdc-text-field {
        position: relative;
        min-height: 74px;
        min-width: 178px;
        max-height: 200px;
      }
      :host([autogrow]) .mdc-text-field:after {
        content: attr(data-value);
        margin-top: 23px;
        margin-bottom: 9px;
        line-height: 1.5rem;
        min-height: 42px;
        padding: 0px 32px 0 16px;
        letter-spacing: var(
          --mdc-typography-subtitle1-letter-spacing,
          0.009375em
        );
        visibility: hidden;
        white-space: pre-wrap;
      }
      :host([autogrow]) .mdc-text-field__input {
        position: absolute;
        height: calc(100% - 32px);
      }
      :host([autogrow]) .mdc-text-field.mdc-text-field--no-label:after {
        margin-top: 16px;
        margin-bottom: 16px;
      }
    `]}]}}),Rc),f([A("ha-automation-condition-template")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"condition",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{value_template:""}}},{kind:"method",key:"render",value:function(){const{value_template:e}=this.condition;return x`
      <p>
        ${this.hass.localize("ui.panel.config.automation.editor.conditions.type.template.value_template")}
        *
      </p>
      <ha-code-editor
        .name=${"value_template"}
        mode="jinja2"
        .hass=${this.hass}
        .value=${e}
        autocomplete-entities
        @value-changed=${this._valueChanged}
        dir="ltr"
      ></ha-code-editor>
    `}},{kind:"method",key:"_valueChanged",value:function(e){((e,t)=>{var i,a,n;t.stopPropagation();const s=null===(i=t.currentTarget)||void 0===i?void 0:i.name;if(!s)return;const r=(null===(a=t.detail)||void 0===a?void 0:a.value)||(null===(n=t.currentTarget)||void 0===n?void 0:n.value);if((e.condition[s]||"")===r)return;let l;r?l={...e.condition,[s]:r}:(l={...e.condition},delete l[s]),o(e,"value-changed",{value:l})})(this,e)}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      p {
        margin-top: 0;
      }
    `}}]}}),g);const Hc=["mon","tue","wed","thu","fri","sat","sun"];f([A("ha-automation-condition-time")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"condition",value:void 0},{kind:"field",decorators:[Qi()],key:"_inputModeBefore",value:void 0},{kind:"field",decorators:[Qi()],key:"_inputModeAfter",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{}}},{kind:"field",key:"_schema",value:()=>n(((e,t,i)=>[{name:"mode_after",type:"select",required:!0,options:[["value",e("ui.panel.config.automation.editor.conditions.type.time.type_value")],["input",e("ui.panel.config.automation.editor.conditions.type.time.type_input")]]},{name:"after",selector:t?{entity:{domain:"input_datetime"}}:{time:{}}},{name:"mode_before",type:"select",required:!0,options:[["value",e("ui.panel.config.automation.editor.conditions.type.time.type_value")],["input",e("ui.panel.config.automation.editor.conditions.type.time.type_input")]]},{name:"before",selector:i?{entity:{domain:"input_datetime"}}:{time:{}}},{type:"multi_select",name:"weekday",options:Hc.map((t=>[t,e(`ui.panel.config.automation.editor.conditions.type.time.weekdays.${t}`)]))}]))},{kind:"method",key:"render",value:function(){var e,t,i,a;const n=null!==(e=this._inputModeBefore)&&void 0!==e?e:null===(t=this.condition.before)||void 0===t?void 0:t.startsWith("input_datetime."),o=null!==(i=this._inputModeAfter)&&void 0!==i?i:null===(a=this.condition.after)||void 0===a?void 0:a.startsWith("input_datetime."),s=this._schema(this.hass.localize,o,n),r={mode_before:n?"input":"value",mode_after:o?"input":"value",...this.condition};return x`
      <ha-form
        .hass=${this.hass}
        .data=${r}
        .schema=${s}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;this._inputModeAfter="input"===t.mode_after,this._inputModeBefore="input"===t.mode_before,delete t.mode_after,delete t.mode_before,Object.keys(t).forEach((e=>void 0===t[e]||""===t[e]?delete t[e]:{})),o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.conditions.type.time.${e.name}`)}}]}}),g),f([A("ha-automation-condition-trigger")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"condition",value:void 0},{kind:"field",decorators:[Qi()],key:"_triggers",value:()=>[]},{kind:"field",key:"_unsub",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{id:""}}},{kind:"method",key:"connectedCallback",value:function(){k(b(i.prototype),"connectedCallback",this).call(this);const e={callback:e=>this._automationUpdated(e)};o(this,"subscribe-automation-config",e),this._unsub=e.unsub}},{kind:"method",key:"disconnectedCallback",value:function(){k(b(i.prototype),"disconnectedCallback",this).call(this),this._unsub&&this._unsub()}},{kind:"method",key:"render",value:function(){const{id:e}=this.condition;return this._triggers.length?x`<ha-select
      .label=${this.hass.localize("ui.panel.config.automation.editor.conditions.type.trigger.id")}
      .value=${e}
      @selected=${this._triggerPicked}
    >
      ${this._triggers.map((e=>x`
            <mwc-list-item .value=${e.id}> ${e.id} </mwc-list-item>
          `))}
    </ha-select>`:this.hass.localize("ui.panel.config.automation.editor.conditions.type.trigger.no_triggers")}},{kind:"method",key:"_automationUpdated",value:function(e){this._triggers=null!=e&&e.trigger?ko(e.trigger).filter((e=>e.id)):[]}},{kind:"method",key:"_triggerPicked",value:function(e){if(e.stopPropagation(),!e.target.value)return;const t=e.target.value;this.condition.id!==t&&o(this,"value-changed",{value:{...this.condition,id:t}})}}]}}),g);const Gc=e=>"latitude"in e.attributes&&"longitude"in e.attributes;function Wc(e){return Gc(e)&&"zone"!==Hr(e)}const Kc=["zone"];f([A("ha-automation-condition-zone")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"condition",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{entity_id:"",zone:""}}},{kind:"method",key:"render",value:function(){const{entity_id:e,zone:t}=this.condition;return x`
      <ha-entity-picker
        .label=${this.hass.localize("ui.panel.config.automation.editor.conditions.type.zone.entity")}
        .value=${e}
        @value-changed=${this._entityPicked}
        .hass=${this.hass}
        allow-custom-entity
        .entityFilter=${Wc}
      ></ha-entity-picker>
      <ha-entity-picker
        .label=${this.hass.localize("ui.panel.config.automation.editor.conditions.type.zone.zone")}
        .value=${t}
        @value-changed=${this._zonePicked}
        .hass=${this.hass}
        allow-custom-entity
        .includeDomains=${Kc}
      ></ha-entity-picker>
      <label id="eventlabel">
        ${this.hass.localize("ui.panel.config.automation.editor.conditions.type.zone.event")}
      </label>
    `}},{kind:"method",key:"_entityPicked",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.condition,entity_id:e.detail.value}})}},{kind:"method",key:"_zonePicked",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.condition,zone:e.detail.value}})}},{kind:"field",static:!0,key:"styles",value:()=>r`
    ha-entity-picker:first-child {
      display: block;
      margin-bottom: 24px;
    }
  `}]}}),g),f([A("ha-automation-condition")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"conditions",value:void 0},{kind:"field",key:"_focusLastConditionOnChange",value:()=>!1},{kind:"field",key:"_conditionKeys",value:()=>new WeakMap},{kind:"method",key:"updated",value:function(e){if(!e.has("conditions"))return;let t;if(Array.isArray(this.conditions)||(t=[this.conditions]),(t||this.conditions).forEach(((e,i)=>{"string"==typeof e&&(t=t||[...this.conditions],t[i]={condition:"template",value_template:e})})),t)o(this,"value-changed",{value:t});else if(this._focusLastConditionOnChange){this._focusLastConditionOnChange=!1;const e=this.shadowRoot.querySelector("ha-automation-condition-row:last-of-type");e.updateComplete.then((()=>{e.expand(),e.scrollIntoView(),e.focus()}))}}},{kind:"method",key:"render",value:function(){return Array.isArray(this.conditions)?x`
      ${Nn(this.conditions,(e=>this._getKey(e)),((e,t)=>x`
          <ha-automation-condition-row
            .index=${t}
            .condition=${e}
            @duplicate=${this._duplicateCondition}
            @value-changed=${this._conditionChanged}
            .hass=${this.hass}
          ></ha-automation-condition-row>
        `))}
      <ha-button-menu fixed @action=${this._addCondition}>
        <mwc-button
          slot="trigger"
          outlined
          .label=${this.hass.localize("ui.panel.config.automation.editor.conditions.add")}
        >
          <ha-svg-icon .path=${ta} slot="icon"></ha-svg-icon>
        </mwc-button>
        ${this._processedTypes(this.hass.localize).map((([e,t,i])=>x`
            <mwc-list-item .value=${e} aria-label=${t} graphic="icon">
              ${t}<ha-svg-icon slot="graphic" .path=${i}></ha-svg-icon
            ></mwc-list-item>
          `))}
      </ha-button-menu>
    `:x``}},{kind:"method",key:"_getKey",value:function(e){return this._conditionKeys.has(e)||this._conditionKeys.set(e,Math.random().toString()),this._conditionKeys.get(e)}},{kind:"method",key:"_addCondition",value:function(e){const t=e.currentTarget.items[e.detail.index].value,i=customElements.get(`ha-automation-condition-${t}`),a=this.conditions.concat({condition:t,...i.defaultConfig});this._focusLastConditionOnChange=!0,o(this,"value-changed",{value:a})}},{kind:"method",key:"_conditionChanged",value:function(e){e.stopPropagation();const t=[...this.conditions],i=e.detail.value,a=e.target.index;if(null===i)t.splice(a,1);else{const e=this._getKey(t[a]);this._conditionKeys.set(i,e),t[a]=i}o(this,"value-changed",{value:t})}},{kind:"method",key:"_duplicateCondition",value:function(e){e.stopPropagation();const t=e.target.index;o(this,"value-changed",{value:this.conditions.concat(Vn(this.conditions[t]))})}},{kind:"field",key:"_processedTypes",value:()=>n((e=>Object.entries(cl).map((([t,i])=>[t,e(`ui.panel.config.automation.editor.conditions.type.${t}.label`),i])).sort(((e,t)=>_s(e[1],t[1])))))},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-automation-condition-row {
        display: block;
        margin-bottom: 16px;
        scroll-margin-top: 48px;
      }
      ha-svg-icon {
        height: 20px;
      }
    `}}]}}),g);let Yc=f([A("ha-automation-condition-logical")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"condition",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{conditions:[]}}},{kind:"method",key:"render",value:function(){return x`
      <ha-automation-condition
        .conditions=${this.condition.conditions||[]}
        @value-changed=${this._valueChanged}
        .hass=${this.hass}
      ></ha-automation-condition>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.condition,conditions:e.detail.value}})}}]}}),g);f([A("ha-automation-condition-and")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[]}}),Yc),f([A("ha-automation-condition-not")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[]}}),Yc),f([A("ha-automation-condition-or")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[]}}),Yc),f([A("ha-automation-condition-editor")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"condition",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"yamlMode",value:()=>!1},{kind:"field",key:"_processedCondition",value:()=>n((e=>(e=>{if("condition"in e&&Array.isArray(e.condition))return{condition:"and",conditions:e.condition};for(const t of["and","or","not"])if(t in e)return{condition:t,conditions:e[t]};return e})(e)))},{kind:"method",key:"render",value:function(){const e=this._processedCondition(this.condition),t=void 0!==customElements.get(`ha-automation-condition-${e.condition}`),i=this.yamlMode||!t;return x`
      ${i?x`
            ${t?"":x`
                  ${this.hass.localize("ui.panel.config.automation.editor.conditions.unsupported_condition","condition",e.condition)}
                `}
            <ha-yaml-editor
              .hass=${this.hass}
              .defaultValue=${this.condition}
              @value-changed=${this._onYamlChange}
            ></ha-yaml-editor>
          `:x`
            <div>
              ${hn(`ha-automation-condition-${e.condition}`,{hass:this.hass,condition:e})}
            </div>
          `}
    `}},{kind:"method",key:"_onYamlChange",value:function(e){e.stopPropagation(),e.detail.isValid&&o(this,"value-changed",{value:e.detail.value,yaml:!0})}},{kind:"field",static:!0,key:"styles",value:()=>ia}]}}),g),f([A("ha-automation-action-condition")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{condition:"state"}}},{kind:"method",key:"render",value:function(){return x`
      <ha-select
        fixedMenuPosition
        .label=${this.hass.localize("ui.panel.config.automation.editor.conditions.type_select")}
        .value=${this.action.condition}
        naturalMenuWidth
        @selected=${this._typeChanged}
      >
        ${this._processedTypes(this.hass.localize).map((([e,t,i])=>x`
            <mwc-list-item .value=${e} aria-label=${t} graphic="icon">
              ${t}<ha-svg-icon slot="graphic" .path=${i}></ha-svg-icon
            ></mwc-list-item>
          `))}
      </ha-select>
      <ha-automation-condition-editor
        .condition=${this.action}
        .hass=${this.hass}
        @value-changed=${this._conditionChanged}
      ></ha-automation-condition-editor>
    `}},{kind:"field",key:"_processedTypes",value:()=>n((e=>Object.entries(cl).map((([t,i])=>[t,e(`ui.panel.config.automation.editor.conditions.type.${t}.label`),i])).sort(((e,t)=>_s(e[1],t[1])))))},{kind:"method",key:"_conditionChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:e.detail.value})}},{kind:"method",key:"_typeChanged",value:function(e){const t=e.target.value;if(!t)return;const i=customElements.get(`ha-automation-condition-${t}`);t!==this.action.condition&&o(this,"value-changed",{value:{condition:t,...i.defaultConfig}})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-select {
        margin-bottom: 24px;
      }
    `}}]}}),g),f([A("ha-automation-action-delay")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"action",value:void 0},{kind:"field",decorators:[Qi()],key:"_timeData",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{delay:""}}},{kind:"method",key:"willUpdate",value:function(e){e.has("action")&&(this.action&&wo(this.action)?o(this,"ui-mode-not-available",Error(this.hass.localize("ui.errors.config.no_template_editor_support"))):this._timeData=Bc(this.action.delay))}},{kind:"method",key:"render",value:function(){return x`<ha-duration-input
      .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.delay.delay")}
      .data=${this._timeData}
      enableMillisecond
      @value-changed=${this._valueChanged}
    ></ha-duration-input>`}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;t&&o(this,"value-changed",{value:{...this.action,delay:t}})}}]}}),g),f([A("ha-device-action-picker")],(function(e,t){return{F:class extends t{constructor(){super(_c,pc,(e=>({device_id:e||"",domain:"",entity_id:""}))),e(this)}},d:[{kind:"get",key:"NO_AUTOMATION_TEXT",value:function(){return this.hass.localize("ui.panel.config.devices.automation.actions.no_actions")}},{kind:"get",key:"UNKNOWN_AUTOMATION_TEXT",value:function(){return this.hass.localize("ui.panel.config.devices.automation.actions.unknown_action")}}]}}),wc),f([A("ha-automation-action-device_id")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({type:Object})],key:"action",value:void 0},{kind:"field",decorators:[Qi()],key:"_deviceId",value:void 0},{kind:"field",decorators:[Qi()],key:"_capabilities",value:void 0},{kind:"field",key:"_origAction",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{device_id:"",domain:"",entity_id:""}}},{kind:"field",key:"_extraFieldsData",value:()=>n(((e,t)=>{const i={};return t.extra_fields.forEach((t=>{void 0!==e[t.name]&&(i[t.name]=e[t.name])})),i}))},{kind:"method",key:"render",value:function(){var e;const t=this._deviceId||this.action.device_id;return x`
      <ha-device-picker
        .value=${t}
        @value-changed=${this._devicePicked}
        .hass=${this.hass}
        label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.device_id.label")}
      ></ha-device-picker>
      <ha-device-action-picker
        .value=${this.action}
        .deviceId=${t}
        @value-changed=${this._deviceActionPicked}
        .hass=${this.hass}
        label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.device_id.action")}
      ></ha-device-action-picker>
      ${null!==(e=this._capabilities)&&void 0!==e&&e.extra_fields?x`
            <ha-form
              .hass=${this.hass}
              .data=${this._extraFieldsData(this.action,this._capabilities)}
              .schema=${this._capabilities.extra_fields}
              .computeLabel=${this._extraFieldsComputeLabelCallback(this.hass.localize)}
              @value-changed=${this._extraFieldsChanged}
            ></ha-form>
          `:""}
    `}},{kind:"method",key:"firstUpdated",value:function(){this._capabilities||this._getCapabilities(),this.action&&(this._origAction=this.action)}},{kind:"method",key:"updated",value:function(e){const t=e.get("action");t&&!gc(t,this.action)&&(this._deviceId=void 0,this._getCapabilities())}},{kind:"method",key:"_getCapabilities",value:async function(){var e,t;this._capabilities=this.action.domain?await(e=this.hass,t=this.action,e.callWS({type:"device_automation/action/capabilities",action:t})):void 0}},{kind:"method",key:"_devicePicked",value:function(e){e.stopPropagation(),this._deviceId=e.target.value,void 0===this._deviceId&&o(this,"value-changed",{value:i.defaultConfig})}},{kind:"method",key:"_deviceActionPicked",value:function(e){e.stopPropagation();let t=e.detail.value;this._origAction&&gc(this._origAction,t)&&(t=this._origAction),o(this,"value-changed",{value:t})}},{kind:"method",key:"_extraFieldsChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.action,...e.detail.value}})}},{kind:"method",key:"_extraFieldsComputeLabelCallback",value:function(e){return t=>e(`ui.panel.config.automation.editor.actions.type.device_id.extra_fields.${t.name}`)||t.name}},{kind:"field",static:!0,key:"styles",value:()=>r`
    ha-device-picker {
      display: block;
      margin-bottom: 16px;
    }
    ha-device-action-picker {
      display: block;
    }
  `}]}}),g);const Zc=(e,t,i)=>e(`component.${t}.title`)||(null==i?void 0:i.name)||t,Qc=e=>x`<mwc-list-item twoline>
  <span>${e.name}</span>
  <span slot="secondary"
    >${e.name===e.service?"":e.service}</span
  >
</mwc-list-item>`;let Jc=f(null,(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[Qi()],key:"_filter",value:void 0},{kind:"method",key:"render",value:function(){return x`
      <ha-combo-box
        .hass=${this.hass}
        .label=${this.hass.localize("ui.components.service-picker.service")}
        .filteredItems=${this._filteredServices(this.hass.localize,this.hass.services,this._filter)}
        .value=${this.value}
        .renderer=${Qc}
        item-value-path="service"
        item-label-path="name"
        allow-custom-value
        @filter-changed=${this._filterChanged}
        @value-changed=${this._valueChanged}
      ></ha-combo-box>
    `}},{kind:"field",key:"_services",value:()=>n(((e,t)=>{if(!t)return[];const i=[];return Object.keys(t).sort().forEach((a=>{const n=Object.keys(t[a]).sort();for(const o of n)i.push({service:`${a}.${o}`,name:`${Zc(e,a)}: ${t[a][o].name||o}`})})),i}))},{kind:"field",key:"_filteredServices",value(){return n(((e,t,i)=>{if(!t)return[];const a=this._services(e,t);return i?a.filter((e=>{var t;return e.service.toLowerCase().includes(i)||(null===(t=e.name)||void 0===t?void 0:t.toLowerCase().includes(i))})):a}))}},{kind:"method",key:"_filterChanged",value:function(e){this._filter=e.detail.value.toLowerCase()}},{kind:"method",key:"_valueChanged",value:function(e){this.value=e.detail.value,o(this,"change"),o(this,"value-changed",{value:this.value})}}]}}),g);customElements.define("ha-service-picker",Jc),f([A("ha-automation-action-event")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"action",value:void 0},{kind:"field",decorators:[y("ha-yaml-editor",!0)],key:"_yamlEditor",value:void 0},{kind:"field",key:"_actionData",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{event:"",event_data:{}}}},{kind:"method",key:"updated",value:function(e){e.has("action")&&(this._actionData&&this._actionData!==this.action.event_data&&this._yamlEditor&&this._yamlEditor.setValue(this.action.event_data),this._actionData=this.action.event_data)}},{kind:"method",key:"render",value:function(){const{event:e,event_data:t}=this.action;return x`
      <ha-textfield
        .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.event.event")}
        .value=${e}
        @change=${this._eventChanged}
      ></ha-textfield>
      <ha-yaml-editor
        .hass=${this.hass}
        .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.event.event_data")}
        .name=${"event_data"}
        .defaultValue=${t}
        @value-changed=${this._dataChanged}
      ></ha-yaml-editor>
    `}},{kind:"method",key:"_dataChanged",value:function(e){e.stopPropagation(),e.detail.isValid&&(this._actionData=e.detail.value,Iu(this,e))}},{kind:"method",key:"_eventChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.action,event:e.target.value}})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-textfield {
        display: block;
      }
    `}}]}}),g),f([A("ha-automation-action-if")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{if:[],then:[]}}},{kind:"method",key:"render",value:function(){const e=this.action;return x`
      <h3>
        ${this.hass.localize("ui.panel.config.automation.editor.actions.type.if.if")}*:
      </h3>
      <ha-automation-condition
        .conditions=${e.if}
        .hass=${this.hass}
        @value-changed=${this._ifChanged}
      ></ha-automation-condition>

      <h3>
        ${this.hass.localize("ui.panel.config.automation.editor.actions.type.if.then")}*:
      </h3>
      <ha-automation-action
        .actions=${e.then}
        @value-changed=${this._thenChanged}
        .hass=${this.hass}
      ></ha-automation-action>

      <h3>
        ${this.hass.localize("ui.panel.config.automation.editor.actions.type.if.else")}:
      </h3>
      <ha-automation-action
        .actions=${e.else||[]}
        @value-changed=${this._elseChanged}
        .hass=${this.hass}
      ></ha-automation-action>
    `}},{kind:"method",key:"_ifChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:{...this.action,if:t}})}},{kind:"method",key:"_thenChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:{...this.action,then:t}})}},{kind:"method",key:"_elseChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:{...this.action,else:t}})}},{kind:"get",static:!0,key:"styles",value:function(){return ia}}]}}),g),f([A("ha-automation-action-parallel")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{parallel:[]}}},{kind:"method",key:"render",value:function(){const e=this.action;return x`
      <ha-automation-action
        .actions=${e.parallel}
        @value-changed=${this._actionsChanged}
        .hass=${this.hass}
      ></ha-automation-action>
    `}},{kind:"method",key:"_actionsChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:{...this.action,parallel:t}})}},{kind:"get",static:!0,key:"styles",value:function(){return ia}}]}}),g);const Xc="browser",eu={album:{icon:wa,layout:"grid"},app:{icon:Ca,layout:"grid"},artist:{icon:Aa,layout:"grid",show_list_images:!0},channel:{icon:Ia,thumbnail_ratio:"portrait",layout:"grid"},composer:{icon:Ea,layout:"grid",show_list_images:!0},contributing_artist:{icon:Aa,layout:"grid",show_list_images:!0},directory:{icon:za,layout:"grid",show_list_images:!0},episode:{icon:Ia,layout:"grid",thumbnail_ratio:"portrait"},game:{icon:Sa,layout:"grid",thumbnail_ratio:"portrait"},genre:{icon:Ta,layout:"grid",show_list_images:!0},image:{icon:La,layout:"grid"},movie:{icon:Oa,thumbnail_ratio:"portrait",layout:"grid"},music:{icon:Ma},playlist:{icon:Pa,layout:"grid",show_list_images:!0},podcast:{icon:Fa,layout:"grid"},season:{icon:Ia,layout:"grid",thumbnail_ratio:"portrait"},track:{icon:Da},tv_show:{icon:Ia,layout:"grid",thumbnail_ratio:"portrait"},url:{icon:Ba},video:{icon:L,layout:"grid"}},tu=(e,t,i,a)=>e.callWS({type:"media_player/browse_media",entity_id:t,media_content_id:i,media_content_type:a}),iu=[{name:"media_content_id",required:!1,selector:{text:{}}},{name:"media_content_type",required:!1,selector:{text:{}}}];f([A("ha-selector-media")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"selector",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"required",value:()=>!0},{kind:"field",decorators:[Qi()],key:"_thumbnailUrl",value:void 0},{kind:"method",key:"willUpdate",value:function(e){if(e.has("value")){var t,i,a,n;const s=null===(t=this.value)||void 0===t||null===(i=t.metadata)||void 0===i?void 0:i.thumbnail;if(s===(null===(a=e.get("value"))||void 0===a||null===(n=a.metadata)||void 0===n?void 0:n.thumbnail))return;if(s&&s.startsWith("/"))this._thumbnailUrl=void 0,Wr(this.hass,s).then((e=>{this._thumbnailUrl=e.path}));else if(s&&s.startsWith("https://brands.home-assistant.io")){var o;this._thumbnailUrl=An({domain:In(s),type:"icon",useFallback:!0,darkOptimized:null===(o=this.hass.themes)||void 0===o?void 0:o.darkMode})}else this._thumbnailUrl=s}}},{kind:"method",key:"render",value:function(){var e,t,i,a,n,o,s,r,l,d,c,u,h;const p=null!==(e=this.value)&&void 0!==e&&e.entity_id?this.hass.states[this.value.entity_id]:void 0,v=!(null!==(t=this.value)&&void 0!==t&&t.entity_id)||p&&((e,t)=>Qr(e.attributes,t))(p,131072);return x`<ha-entity-picker
        .hass=${this.hass}
        .value=${null===(i=this.value)||void 0===i?void 0:i.entity_id}
        .label=${this.label||this.hass.localize("ui.components.selectors.media.pick_media_player")}
        .disabled=${this.disabled}
        .helper=${this.helper}
        .required=${this.required}
        include-domains='["media_player"]'
        allow-custom-entity
        @value-changed=${this._entityChanged}
      ></ha-entity-picker>
      ${v?x`<ha-card
            outlined
            @click=${this._pickMedia}
            class=${this.disabled||null===(a=this.value)||void 0===a||!a.entity_id?"disabled":""}
          >
            <div
              class="thumbnail ${ba({portrait:!(null===(n=this.value)||void 0===n||null===(o=n.metadata)||void 0===o||!o.media_class)&&"portrait"===eu[this.value.metadata.children_media_class||this.value.metadata.media_class].thumbnail_ratio})}"
            >
              ${null!==(s=this.value)&&void 0!==s&&null!==(r=s.metadata)&&void 0!==r&&r.thumbnail?x`
                    <div
                      class="${ba({"centered-image":!!this.value.metadata.media_class&&["app","directory"].includes(this.value.metadata.media_class)})}
                        image"
                      style=${this._thumbnailUrl?`background-image: url(${this._thumbnailUrl});`:""}
                    ></div>
                  `:x`
                    <div class="icon-holder image">
                      <ha-svg-icon
                        class="folder"
                        .path=${null!==(l=this.value)&&void 0!==l&&l.media_content_id?null!==(d=this.value)&&void 0!==d&&null!==(c=d.metadata)&&void 0!==c&&c.media_class?eu["directory"===this.value.metadata.media_class&&this.value.metadata.children_media_class||this.value.metadata.media_class].icon:Na:ta}
                      ></ha-svg-icon>
                    </div>
                  `}
            </div>
            <div class="title">
              ${null!==(u=this.value)&&void 0!==u&&u.media_content_id?(null===(h=this.value.metadata)||void 0===h?void 0:h.title)||this.value.media_content_id:this.hass.localize("ui.components.selectors.media.pick_media")}
            </div>
          </ha-card>`:x`<ha-alert>
              ${this.hass.localize("ui.components.selectors.media.browse_not_supported")}
            </ha-alert>
            <ha-form
              .hass=${this.hass}
              .data=${this.value}
              .schema=${iu}
              .computeLabel=${this._computeLabelCallback}
            ></ha-form>`}`}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.components.selectors.media.${e.name}`)}},{kind:"method",key:"_entityChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{entity_id:e.detail.value,media_content_id:"",media_content_type:""}})}},{kind:"method",key:"_pickMedia",value:function(){var e,t,i;t=this,i={action:"pick",entityId:this.value.entity_id,navigateIds:null===(e=this.value.metadata)||void 0===e?void 0:e.navigateIds,mediaPickedCallback:e=>{var t;o(this,"value-changed",{value:{...this.value,media_content_id:e.item.media_content_id,media_content_type:e.item.media_content_type,metadata:{title:e.item.title,thumbnail:e.item.thumbnail,media_class:e.item.media_class,children_media_class:e.item.children_media_class,navigateIds:null===(t=e.navigateIds)||void 0===t?void 0:t.map((e=>({media_content_type:e.media_content_type,media_content_id:e.media_content_id})))}}})}},o(t,"show-dialog",{dialogTag:"dialog-media-player-browse",dialogImport:()=>import("./c.aa05d073.js").then((function(e){return e.a})),dialogParams:i})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-entity-picker {
        display: block;
        margin-bottom: 16px;
      }
      mwc-button {
        margin-top: 8px;
      }
      ha-alert {
        display: block;
        margin-bottom: 16px;
      }
      ha-card {
        position: relative;
        width: 200px;
        box-sizing: border-box;
        cursor: pointer;
      }
      ha-card.disabled {
        pointer-events: none;
        color: var(--disabled-text-color);
      }
      ha-card .thumbnail {
        width: 100%;
        position: relative;
        box-sizing: border-box;
        transition: padding-bottom 0.1s ease-out;
        padding-bottom: 100%;
      }
      ha-card .thumbnail.portrait {
        padding-bottom: 150%;
      }
      ha-card .image {
        border-radius: 3px 3px 0 0;
      }
      .folder {
        --mdc-icon-size: calc(var(--media-browse-item-size, 175px) * 0.4);
      }
      .title {
        font-size: 16px;
        padding-top: 16px;
        overflow: hidden;
        text-overflow: ellipsis;
        margin-bottom: 16px;
        padding-left: 16px;
        padding-right: 4px;
        white-space: nowrap;
      }
      .image {
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
      }
      .centered-image {
        margin: 0 8px;
        background-size: contain;
      }
      .icon-holder {
        display: flex;
        justify-content: center;
        align-items: center;
      }
    `}}]}}),g),f([A("ha-automation-action-play_media")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"action",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"narrow",value:()=>!1},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{service:"media_player.play_media",target:{entity_id:""},data:{media_content_id:"",media_content_type:""},metadata:{}}}},{kind:"field",key:"_getSelectorValue",value:()=>n((e=>{var t,i,a;return{entity_id:(null===(t=e.target)||void 0===t?void 0:t.entity_id)||e.entity_id,media_content_id:null===(i=e.data)||void 0===i?void 0:i.media_content_id,media_content_type:null===(a=e.data)||void 0===a?void 0:a.media_content_type,metadata:e.metadata}}))},{kind:"method",key:"render",value:function(){return x`
      <ha-selector-media
        .hass=${this.hass}
        .value=${this._getSelectorValue(this.action)}
        @value-changed=${this._valueChanged}
      ></ha-selector-media>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{service:"media_player.play_media",target:{entity_id:e.detail.value.entity_id},data:{media_content_id:e.detail.value.media_content_id,media_content_type:e.detail.value.media_content_type},metadata:e.detail.value.metadata||{}}})}}]}}),g);const au=["count","while","until"],nu=e=>au.find((t=>t in e));f([A("ha-automation-action-repeat")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{repeat:{count:2,sequence:[]}}}},{kind:"method",key:"render",value:function(){const e=this.action.repeat,t=nu(e);return x`
      <ha-select
        .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.repeat.type_select")}
        .value=${t}
        @selected=${this._typeChanged}
      >
        ${au.map((e=>x`
            <mwc-list-item .value=${e}>
              ${this.hass.localize(`ui.panel.config.automation.editor.actions.type.repeat.type.${e}.label`)}
            </mwc-list-item>
          `))}
      </ha-select>
      <div>
        ${"count"===t?x`
              <ha-textfield
                .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.repeat.type.count.label")}
                name="count"
                .value=${e.count||"0"}
                @change=${this._countChanged}
              ></ha-textfield>
            `:"while"===t?x` <h3>
                ${this.hass.localize("ui.panel.config.automation.editor.actions.type.repeat.type.while.conditions")}:
              </h3>
              <ha-automation-condition
                .conditions=${e.while||[]}
                .hass=${this.hass}
                @value-changed=${this._conditionChanged}
              ></ha-automation-condition>`:"until"===t?x` <h3>
                ${this.hass.localize("ui.panel.config.automation.editor.actions.type.repeat.type.until.conditions")}:
              </h3>
              <ha-automation-condition
                .conditions=${e.until||[]}
                .hass=${this.hass}
                @value-changed=${this._conditionChanged}
              ></ha-automation-condition>`:""}
      </div>
      <h3>
        ${this.hass.localize("ui.panel.config.automation.editor.actions.type.repeat.sequence")}:
      </h3>
      <ha-automation-action
        .actions=${e.sequence}
        @value-changed=${this._actionChanged}
        .hass=${this.hass}
      ></ha-automation-action>
    `}},{kind:"method",key:"_typeChanged",value:function(e){const t=e.target.value;if(!t||t===nu(this.action.repeat))return;o(this,"value-changed",{value:{repeat:{[t]:"count"===t?2:[],sequence:this.action.repeat.sequence}}})}},{kind:"method",key:"_conditionChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:{repeat:{...this.action.repeat,[nu(this.action.repeat)]:t}}})}},{kind:"method",key:"_actionChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:{repeat:{...this.action.repeat,sequence:t}}})}},{kind:"method",key:"_countChanged",value:function(e){const t=e.target.value;this.action.repeat.count!==t&&o(this,"value-changed",{value:{repeat:{...this.action.repeat,count:t}}})}},{kind:"get",static:!0,key:"styles",value:function(){return[ia,r`
        ha-textfield {
          margin-top: 16px;
        }
      `]}}]}}),g);const ou=e=>"all"===e||(e=>e.includes("."))(e),su=(e,t)=>`https://${e.config.version.includes("b")?"rc":e.config.version.includes("dev")?"next":"www"}.home-assistant.io${t}`,ru=e=>e.selector&&!e.required&&!("boolean"in e.selector&&e.default);f([A("ha-service-control")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"value",value:void 0},{kind:"field",decorators:[Qi()],key:"_value",value:void 0},{kind:"field",decorators:[_({reflect:!0,type:Boolean})],key:"narrow",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"showAdvanced",value:void 0},{kind:"field",decorators:[Qi()],key:"_checkedKeys",value:()=>new Set},{kind:"field",decorators:[Qi()],key:"_manifest",value:void 0},{kind:"field",decorators:[y("ha-yaml-editor")],key:"_yamlEditor",value:void 0},{kind:"method",key:"willUpdate",value:function(e){var t,i,a,n,s,r,l,d,c,u,h;if(!e.has("value"))return;const p=e.get("value");(null==p?void 0:p.service)!==(null===(t=this.value)||void 0===t?void 0:t.service)&&(this._checkedKeys=new Set);const v=this._getServiceInfo(null===(i=this.value)||void 0===i?void 0:i.service,this.hass.services);var m;null!==(a=this.value)&&void 0!==a&&a.service?null!=p&&p.service&&gs(this.value.service)===gs(p.service)||this._fetchManifest(gs(null===(m=this.value)||void 0===m?void 0:m.service)):this._manifest=void 0;if(v&&"target"in v&&(null!==(n=this.value)&&void 0!==n&&null!==(s=n.data)&&void 0!==s&&s.entity_id||null!==(r=this.value)&&void 0!==r&&null!==(l=r.data)&&void 0!==l&&l.area_id||null!==(d=this.value)&&void 0!==d&&null!==(c=d.data)&&void 0!==c&&c.device_id)){var f,g,_;const e={...this.value.target};!this.value.data.entity_id||null!==(f=this.value.target)&&void 0!==f&&f.entity_id||(e.entity_id=this.value.data.entity_id),!this.value.data.area_id||null!==(g=this.value.target)&&void 0!==g&&g.area_id||(e.area_id=this.value.data.area_id),!this.value.data.device_id||null!==(_=this.value.target)&&void 0!==_&&_.device_id||(e.device_id=this.value.data.device_id),this._value={...this.value,target:e,data:{...this.value.data}},delete this._value.data.entity_id,delete this._value.data.device_id,delete this._value.data.area_id}else this._value=this.value;if((null==p?void 0:p.service)!==(null===(u=this.value)||void 0===u?void 0:u.service)){let e=!1;this._value&&v&&(this._value.data||(this._value.data={}),v.fields.forEach((t=>{t.selector&&t.required&&void 0===t.default&&"boolean"in t.selector&&void 0===this._value.data[t.key]&&(e=!0,this._value.data[t.key]=!1)}))),e&&o(this,"value-changed",{value:{...this._value}})}if(null!==(h=this._value)&&void 0!==h&&h.data){const e=this._yamlEditor;e&&e.value!==this._value.data&&e.setValue(this._value.data)}}},{kind:"field",key:"_getServiceInfo",value:()=>n(((e,t)=>{if(!e||!t)return;const i=gs(e),a=ho(e);if(!(i in t))return;if(!(a in t[i]))return;const n=Object.entries(t[i][a].fields).map((([e,t])=>({key:e,...t,selector:t.selector})));return{...t[i][a],fields:n,hasSelector:n.length?n.filter((e=>e.selector)).map((e=>e.key)):[]}}))},{kind:"method",key:"render",value:function(){var e,t,i,a,n,o,s;const r=this._getServiceInfo(null===(e=this._value)||void 0===e?void 0:e.service,this.hass.services),l=(null==r?void 0:r.fields.length)&&!r.hasSelector.length||r&&Object.keys((null===(t=this._value)||void 0===t?void 0:t.data)||{}).some((e=>!r.hasSelector.includes(e))),d=l&&(null==r?void 0:r.fields.find((e=>"entity_id"===e.key))),c=Boolean(!l&&(null==r?void 0:r.fields.some((e=>ru(e)))));return x`<ha-service-picker
        .hass=${this.hass}
        .value=${null===(i=this._value)||void 0===i?void 0:i.service}
        @value-changed=${this._serviceChanged}
      ></ha-service-picker>
      <div class="description">
        ${null!=r&&r.description?x`<p>${null==r?void 0:r.description}</p>`:""}
        ${this._manifest?x` <a
              href=${this._manifest.is_built_in?su(this.hass,`/integrations/${this._manifest.domain}`):this._manifest.documentation}
              title=${this.hass.localize("ui.components.service-control.integration_doc")}
              target="_blank"
              rel="noreferrer"
            >
              <ha-icon-button
                .path=${Va}
                class="help-icon"
              ></ha-icon-button>
            </a>`:""}
      </div>
      ${r&&"target"in r?x`<ha-settings-row .narrow=${this.narrow}>
            ${c?x`<div slot="prefix" class="checkbox-spacer"></div>`:""}
            <span slot="heading"
              >${this.hass.localize("ui.components.service-control.target")}</span
            >
            <span slot="description"
              >${this.hass.localize("ui.components.service-control.target_description")}</span
            ><ha-selector
              .hass=${this.hass}
              .selector=${r.target?{target:r.target}:{target:{}}}
              @value-changed=${this._targetChanged}
              .value=${null===(a=this._value)||void 0===a?void 0:a.target}
            ></ha-selector
          ></ha-settings-row>`:d?x`<ha-entity-picker
            .hass=${this.hass}
            .value=${null===(n=this._value)||void 0===n||null===(o=n.data)||void 0===o?void 0:o.entity_id}
            .label=${d.description}
            @value-changed=${this._entityPicked}
            allow-custom-entity
          ></ha-entity-picker>`:""}
      ${l?x`<ha-yaml-editor
            .hass=${this.hass}
            .label=${this.hass.localize("ui.components.service-control.data")}
            .name=${"data"}
            .defaultValue=${null===(s=this._value)||void 0===s?void 0:s.data}
            @value-changed=${this._dataChanged}
          ></ha-yaml-editor>`:null==r?void 0:r.fields.map((e=>{var t,i,a,n;const o=ru(e);return e.selector&&(!e.advanced||this.showAdvanced||null!==(t=this._value)&&void 0!==t&&t.data&&void 0!==this._value.data[e.key])?x`<ha-settings-row .narrow=${this.narrow}>
                  ${o?x`<ha-checkbox
                        .key=${e.key}
                        .checked=${this._checkedKeys.has(e.key)||(null===(i=this._value)||void 0===i?void 0:i.data)&&void 0!==this._value.data[e.key]}
                        @change=${this._checkboxChanged}
                        slot="prefix"
                      ></ha-checkbox>`:c?x`<div slot="prefix" class="checkbox-spacer"></div>`:""}
                  <span slot="heading">${e.name||e.key}</span>
                  <span slot="description">${null==e?void 0:e.description}</span>
                  <ha-selector
                    .disabled=${o&&!this._checkedKeys.has(e.key)&&(!(null!==(a=this._value)&&void 0!==a&&a.data)||void 0===this._value.data[e.key])}
                    .hass=${this.hass}
                    .selector=${e.selector}
                    .key=${e.key}
                    @value-changed=${this._serviceDataChanged}
                    .value=${null!==(n=this._value)&&void 0!==n&&n.data&&void 0!==this._value.data[e.key]?this._value.data[e.key]:e.default}
                  ></ha-selector>
                </ha-settings-row>`:""}))}`}},{kind:"method",key:"_checkboxChanged",value:function(e){const t=e.currentTarget.checked,i=e.currentTarget.key;let a;if(t){var n,s,r;this._checkedKeys.add(i);const e=null===(n=this._getServiceInfo(null===(r=this._value)||void 0===r?void 0:r.service,this.hass.services))||void 0===n||null===(s=n.fields.find((e=>e.key===i)))||void 0===s?void 0:s.default;var l;if(e)a={...null===(l=this._value)||void 0===l?void 0:l.data,[i]:e}}else{var d;this._checkedKeys.delete(i),a={...null===(d=this._value)||void 0===d?void 0:d.data},delete a[i]}a&&o(this,"value-changed",{value:{...this._value,data:a}}),this.requestUpdate("_checkedKeys")}},{kind:"method",key:"_serviceChanged",value:function(e){var t;e.stopPropagation(),e.detail.value!==(null===(t=this._value)||void 0===t?void 0:t.service)&&o(this,"value-changed",{value:{service:e.detail.value||""}})}},{kind:"method",key:"_entityPicked",value:function(e){var t,i,a;e.stopPropagation();const n=e.detail.value;if((null===(t=this._value)||void 0===t||null===(i=t.data)||void 0===i?void 0:i.entity_id)===n)return;let s;var r;!n&&null!==(a=this._value)&&void 0!==a&&a.data?(s={...this._value},delete s.data.entity_id):s={...this._value,data:{...null===(r=this._value)||void 0===r?void 0:r.data,entity_id:e.detail.value}};o(this,"value-changed",{value:s})}},{kind:"method",key:"_targetChanged",value:function(e){var t;e.stopPropagation();const i=e.detail.value;if((null===(t=this._value)||void 0===t?void 0:t.target)===i)return;let a;i?a={...this._value,target:e.detail.value}:(a={...this._value},delete a.target),o(this,"value-changed",{value:a})}},{kind:"method",key:"_serviceDataChanged",value:function(e){var t,i,a,n,s;e.stopPropagation();const r=e.currentTarget.key,l=e.detail.value;if((null===(t=this._value)||void 0===t||null===(i=t.data)||void 0===i?void 0:i[r])===l||(null===(a=this._value)||void 0===a||null===(n=a.data)||void 0===n||!n[r])&&(""===l||void 0===l))return;const d={...null===(s=this._value)||void 0===s?void 0:s.data,[r]:l};""!==l&&void 0!==l||delete d[r],o(this,"value-changed",{value:{...this._value,data:d}})}},{kind:"method",key:"_dataChanged",value:function(e){e.stopPropagation(),e.detail.isValid&&o(this,"value-changed",{value:{...this._value,data:e.detail.value}})}},{kind:"method",key:"_fetchManifest",value:async function(e){this._manifest=void 0;try{this._manifest=await((e,t)=>e.callWS({type:"manifest/get",integration:t}))(this.hass,e)}catch(e){}}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-settings-row {
        padding: var(--service-control-padding, 0 16px);
      }
      ha-settings-row {
        --paper-time-input-justify-content: flex-end;
        --settings-row-content-width: 100%;
        --settings-row-prefix-display: contents;
        border-top: var(
          --service-control-items-border-top,
          1px solid var(--divider-color)
        );
      }
      ha-service-picker,
      ha-entity-picker,
      ha-yaml-editor {
        display: block;
        margin: var(--service-control-padding, 0 16px);
      }
      ha-yaml-editor {
        padding: 16px 0;
      }
      p {
        margin: var(--service-control-padding, 0 16px);
        padding: 16px 0;
      }
      .checkbox-spacer {
        width: 32px;
      }
      ha-checkbox {
        margin-left: -16px;
      }
      .help-icon {
        color: var(--secondary-text-color);
      }
      .description {
        justify-content: space-between;
        display: flex;
        align-items: center;
        padding-right: 2px;
      }
    `}}]}}),g);const lu=no({alias:oo(so()),service:oo(so()),entity_id:oo((du=so(),cu="entity ID (domain.entity or all)",uu=ou,new Wn({...du,*refiner(e,t){yield*du.refiner(e,t);const i=Hn(uu(e,t),t,du,e);for(const e of i)yield{...e,refinement:cu}}}))),target:oo(Xn()),data:oo(Xn())});var du,cu,uu;f([A("ha-automation-action-service")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"action",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{service:"",data:{}}}},{kind:"method",key:"willUpdate",value:function(e){if(e.has("action")){try{Kn(this.action,lu)}catch(e){return void o(this,"ui-mode-not-available",e)}this.action&&wo(this.action)?o(this,"ui-mode-not-available",Error(this.hass.localize("ui.errors.config.no_template_editor_support"))):this.action.entity_id?(this._action={...this.action,data:{...this.action.data,entity_id:this.action.entity_id}},delete this._action.entity_id):this._action=this.action}}},{kind:"method",key:"render",value:function(){var e;return x`
      <ha-service-control
        .narrow=${this.narrow}
        .hass=${this.hass}
        .value=${this._action}
        .showAdvanced=${null===(e=this.hass.userData)||void 0===e?void 0:e.showAdvanced}
        @value-changed=${this._actionChanged}
      ></ha-service-control>
    `}},{kind:"method",key:"_actionChanged",value:function(e){e.detail.value===this._action&&e.stopPropagation()}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-service-control {
        display: block;
        margin: 0 -16px;
      }
    `}}]}}),g),f([A("ha-automation-action-stop")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{stop:""}}},{kind:"method",key:"render",value:function(){const{error:e,stop:t}=this.action;return x`
      <ha-textfield
        .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.stop.stop")}
        .value=${t}
        @change=${this._stopChanged}
      ></ha-textfield>
      <ha-formfield
        .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.stop.error")}
      >
        <ha-switch
          .checked=${null!=e&&e}
          @change=${this._errorChanged}
        ></ha-switch>
      </ha-formfield>
    `}},{kind:"method",key:"_stopChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.action,stop:e.target.value}})}},{kind:"method",key:"_errorChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.action,error:e.target.checked}})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-textfield {
        display: block;
        margin-bottom: 24px;
      }
    `}}]}}),g);const hu={calendar:T,device:aa,event:ua,state:ra,geo_location:qa,homeassistant:D,mqtt:Ci,numeric_state:la,sun:Ve,tag:ja,template:da,time:ca,time_pattern:Ra,webhook:Ua,zone:he};f([A("ha-automation-trigger-calendar")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"field",key:"_schema",value:()=>n((e=>[{name:"entity_id",required:!0,selector:{entity:{domain:"calendar"}}},{name:"event",type:"select",required:!0,options:[["start",e("ui.panel.config.automation.editor.triggers.type.calendar.start")],["end",e("ui.panel.config.automation.editor.triggers.type.calendar.end")]]},{name:"offset",selector:{duration:{enable_day:!0}}},{name:"offset_type",type:"select",required:!0,options:[["before",e("ui.panel.config.automation.editor.triggers.type.calendar.before")],["after",e("ui.panel.config.automation.editor.triggers.type.calendar.after")]]}]))},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{event:"start",offset:0}}},{kind:"method",key:"render",value:function(){const e=this._schema(this.hass.localize),t=this.trigger.offset,i=Bc(t);let a="after";("object"==typeof t&&i.hours<0||"string"==typeof t&&t.startsWith("-"))&&(i.hours=Math.abs(i.hours),a="before");const n={...this.trigger,offset:i,offset_type:a};return x`
      <ha-form
        .schema=${e}
        .data=${n}
        .hass=${this.hass}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){var t,i,a;e.stopPropagation();const n=e.detail.value.offset,s="before"===e.detail.value.offset_type?"-":"",r={...e.detail.value,offset:`${s}${null!==(t=n.hours)&&void 0!==t?t:0}:${null!==(i=n.minutes)&&void 0!==i?i:0}:${null!==(a=n.seconds)&&void 0!==a?a:0}`};delete r.offset_type,o(this,"value-changed",{value:r})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.calendar.${e.name}`)}}]}}),g),f([A("ha-device-trigger-picker")],(function(e,t){return{F:class extends t{constructor(){super(kc,mc,(e=>({device_id:e||"",platform:"device",domain:"",entity_id:""}))),e(this)}},d:[{kind:"get",key:"NO_AUTOMATION_TEXT",value:function(){return this.hass.localize("ui.panel.config.devices.automation.triggers.no_triggers")}},{kind:"get",key:"UNKNOWN_AUTOMATION_TEXT",value:function(){return this.hass.localize("ui.panel.config.devices.automation.triggers.unknown_trigger")}}]}}),wc),f([A("ha-automation-trigger-device")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({type:Object})],key:"trigger",value:void 0},{kind:"field",decorators:[Qi()],key:"_deviceId",value:void 0},{kind:"field",decorators:[Qi()],key:"_capabilities",value:void 0},{kind:"field",key:"_origTrigger",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{device_id:"",domain:"",entity_id:""}}},{kind:"field",key:"_extraFieldsData",value:()=>n(((e,t)=>{const i={};return t.extra_fields.forEach((t=>{void 0!==e[t.name]&&(i[t.name]=e[t.name])})),i}))},{kind:"method",key:"render",value:function(){var e;const t=this._deviceId||this.trigger.device_id;return x`
      <ha-device-picker
        .value=${t}
        @value-changed=${this._devicePicked}
        .hass=${this.hass}
        label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.device.label")}
      ></ha-device-picker>
      <ha-device-trigger-picker
        .value=${this.trigger}
        .deviceId=${t}
        @value-changed=${this._deviceTriggerPicked}
        .hass=${this.hass}
        label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.device.trigger")}
      ></ha-device-trigger-picker>
      ${null!==(e=this._capabilities)&&void 0!==e&&e.extra_fields?x`
            <ha-form
              .hass=${this.hass}
              .data=${this._extraFieldsData(this.trigger,this._capabilities)}
              .schema=${this._capabilities.extra_fields}
              .computeLabel=${this._extraFieldsComputeLabelCallback(this.hass.localize)}
              @value-changed=${this._extraFieldsChanged}
            ></ha-form>
          `:""}
    `}},{kind:"method",key:"firstUpdated",value:function(){this._capabilities||this._getCapabilities(),this.trigger&&(this._origTrigger=this.trigger)}},{kind:"method",key:"updated",value:function(e){if(!e.has("trigger"))return;const t=e.get("trigger");t&&!gc(t,this.trigger)&&this._getCapabilities()}},{kind:"method",key:"_getCapabilities",value:async function(){const e=this.trigger;this._capabilities=e.domain?await((e,t)=>e.callWS({type:"device_automation/trigger/capabilities",trigger:t}))(this.hass,e):void 0}},{kind:"method",key:"_devicePicked",value:function(e){e.stopPropagation(),this._deviceId=e.target.value,void 0===this._deviceId&&o(this,"value-changed",{value:{...i.defaultConfig,platform:"device"}})}},{kind:"method",key:"_deviceTriggerPicked",value:function(e){e.stopPropagation();let t=e.detail.value;this._origTrigger&&gc(this._origTrigger,t)&&(t=this._origTrigger),this.trigger.id&&(t.id=this.trigger.id),o(this,"value-changed",{value:t})}},{kind:"method",key:"_extraFieldsChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.trigger,...e.detail.value}})}},{kind:"method",key:"_extraFieldsComputeLabelCallback",value:function(e){return t=>e(`ui.panel.config.automation.editor.triggers.type.device.extra_fields.${t.name}`)||t.name}},{kind:"field",static:!0,key:"styles",value:()=>r`
    ha-device-picker {
      display: block;
      margin-bottom: 24px;
    }
  `}]}}),g);const pu={},vu=e(class extends t{constructor(){super(...arguments),this.nt=pu}render(e,t){return t()}update(e,[t,i]){if(Array.isArray(t)){if(Array.isArray(this.nt)&&this.nt.length===t.length&&t.every(((e,t)=>e===this.nt[t])))return a}else if(this.nt===t)return a;return this.nt=Array.isArray(t)?Array.from(t):t,this.render(t,i)}}),mu=async e=>e.callWS({type:"config/auth/list"});f([A("ha-user-badge")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"user",value:void 0},{kind:"field",decorators:[Qi()],key:"_personPicture",value:void 0},{kind:"field",key:"_personEntityId",value:void 0},{kind:"method",key:"willUpdate",value:function(e){if(k(b(i.prototype),"willUpdate",this).call(this,e),e.has("user"))return void this._getPersonPicture();const t=e.get("hass");if(this._personEntityId&&t&&this.hass.states[this._personEntityId]!==t.states[this._personEntityId]){const e=this.hass.states[this._personEntityId];e?this._personPicture=e.attributes.entity_picture:this._getPersonPicture()}else!this._personEntityId&&t&&this._getPersonPicture()}},{kind:"method",key:"render",value:function(){if(!this.hass||!this.user)return x``;const e=this._personPicture;if(e)return x`<div
        style=${Ji({backgroundImage:`url(${e})`})}
        class="picture"
      ></div>`;const t=(e=>e?e.trim().split(" ").slice(0,3).map((e=>e.substring(0,1))).join(""):"?")(this.user.name);return x`<div
      class="initials ${ba({long:t.length>2})}"
    >
      ${t}
    </div>`}},{kind:"method",key:"_getPersonPicture",value:function(){if(this._personEntityId=void 0,this._personPicture=void 0,this.hass&&this.user)for(const e of Object.values(this.hass.states))if(e.attributes.user_id===this.user.id&&"person"===Hr(e)){this._personEntityId=e.entity_id,this._personPicture=e.attributes.entity_picture;break}}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      :host {
        display: contents;
      }
      .picture {
        width: 40px;
        height: 40px;
        background-size: cover;
        border-radius: 50%;
      }
      .initials {
        display: inline-block;
        box-sizing: border-box;
        width: 40px;
        line-height: 40px;
        border-radius: 50%;
        text-align: center;
        background-color: var(--light-primary-color);
        text-decoration: none;
        color: var(--text-light-primary-color, var(--primary-text-color));
        overflow: hidden;
      }
      .initials.long {
        font-size: 80%;
      }
    `}}]}}),g);let fu=f(null,(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"noUserLabel",value:void 0},{kind:"field",decorators:[_()],key:"value",value:()=>""},{kind:"field",decorators:[_()],key:"users",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",key:"_sortedUsers",value:()=>n((e=>e?e.filter((e=>!e.system_generated)).sort(((e,t)=>_s(e.name,t.name))):[]))},{kind:"method",key:"render",value:function(){var e,t;return x`
      <ha-select
        .label=${this.label}
        .disabled=${this.disabled}
        .value=${this.value}
        @selected=${this._userChanged}
      >
        ${0===(null===(e=this.users)||void 0===e?void 0:e.length)?x`<mwc-list-item value="">
              ${this.noUserLabel||(null===(t=this.hass)||void 0===t?void 0:t.localize("ui.components.user-picker.no_user"))}
            </mwc-list-item>`:""}
        ${this._sortedUsers(this.users).map((e=>x`
            <ha-list-item graphic="avatar" .value=${e.id}>
              <ha-user-badge
                .hass=${this.hass}
                .user=${e}
                slot="graphic"
              ></ha-user-badge>
              ${e.name}
            </ha-list-item>
          `))}
      </ha-select>
    `}},{kind:"method",key:"firstUpdated",value:function(e){k(b(i.prototype),"firstUpdated",this).call(this,e),void 0===this.users&&mu(this.hass).then((e=>{this.users=e}))}},{kind:"method",key:"_userChanged",value:function(e){const t=e.target.value;t!==this.value&&(this.value=t,setTimeout((()=>{o(this,"value-changed",{value:t}),o(this,"change")}),0))}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      :host {
        display: inline-block;
      }
      mwc-list {
        display: block;
      }
    `}}]}}),g);customElements.define("ha-user-picker",fu),f([A("ha-users-picker")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_({attribute:"picked-user-label"})],key:"pickedUserLabel",value:void 0},{kind:"field",decorators:[_({attribute:"pick-user-label"})],key:"pickUserLabel",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"users",value:void 0},{kind:"method",key:"firstUpdated",value:function(e){k(b(i.prototype),"firstUpdated",this).call(this,e),void 0===this.users&&mu(this.hass).then((e=>{this.users=e}))}},{kind:"method",key:"render",value:function(){if(!this.hass||!this.users)return x``;const e=this._notSelectedUsers(this.users,this.value);return x`
      ${vu([e],(()=>{var t;return null===(t=this.value)||void 0===t?void 0:t.map(((t,i)=>x`
            <div>
              <ha-user-picker
                .label=${this.pickedUserLabel}
                .noUserLabel=${this.hass.localize("ui.components.user-picker.remove_user")}
                .index=${i}
                .hass=${this.hass}
                .value=${t}
                .users=${this._notSelectedUsersAndSelected(t,this.users,e)}
                @value-changed=${this._userChanged}
              ></ha-user-picker>
              <ha-icon-button
                .userId=${t}
                .label=${this.hass.localize("ui.components.user-picker.remove_user")}
                .path=${$}
                @click=${this._removeUser}
              >
                ></ha-icon-button
              >
            </div>
          `))}))}
      <ha-user-picker
        .label=${this.pickUserLabel||this.hass.localize("ui.components.user-picker.add_user")}
        .hass=${this.hass}
        .users=${e}
        .disabled=${!(null!=e&&e.length)}
        @value-changed=${this._addUser}
      ></ha-user-picker>
    `}},{kind:"field",key:"_notSelectedUsers",value:()=>n(((e,t)=>t?null==e?void 0:e.filter((e=>!e.system_generated&&!t.includes(e.id))):null==e?void 0:e.filter((e=>!e.system_generated))))},{kind:"field",key:"_notSelectedUsersAndSelected",value:()=>(e,t,i)=>{const a=null==t?void 0:t.find((t=>t.id===e));return a?i?[...i,a]:[a]:i}},{kind:"get",key:"_currentUsers",value:function(){return this.value||[]}},{kind:"method",key:"_updateUsers",value:async function(e){this.value=e,o(this,"value-changed",{value:e})}},{kind:"method",key:"_userChanged",value:function(e){e.stopPropagation();const t=e.currentTarget.index,i=e.detail.value,a=[...this._currentUsers];""===i?a.splice(t,1):a.splice(t,1,i),this._updateUsers(a)}},{kind:"method",key:"_addUser",value:async function(e){e.stopPropagation();const t=e.detail.value;if(e.currentTarget.value="",!t)return;const i=this._currentUsers;i.includes(t)||this._updateUsers([...i,t])}},{kind:"method",key:"_removeUser",value:function(e){const t=e.currentTarget.userId;this._updateUsers(this._currentUsers.filter((e=>e!==t)))}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      :host {
        display: block;
      }
      div {
        display: flex;
        align-items: center;
      }
    `}}]}}),g),f([A("ha-automation-trigger-event")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"trigger",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{event_type:""}}},{kind:"method",key:"render",value:function(){const{event_type:e,event_data:t,context:i}=this.trigger;return x`
      <ha-textfield
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.event.event_type")}
        name="event_type"
        .value=${e}
        @change=${this._valueChanged}
      ></ha-textfield>
      <ha-yaml-editor
        .hass=${this.hass}
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.event.event_data")}
        .name=${"event_data"}
        .defaultValue=${t}
        @value-changed=${this._dataChanged}
      ></ha-yaml-editor>
      <br />
      ${this.hass.localize("ui.panel.config.automation.editor.triggers.type.event.context_users")}
      <ha-users-picker
        .pickedUserLabel=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.event.context_user_picked")}
        .pickUserLabel=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.event.context_user_pick")}
        .hass=${this.hass}
        .value=${this._wrapUsersInArray(null==i?void 0:i.user_id)}
        @value-changed=${this._usersChanged}
      ></ha-users-picker>
    `}},{kind:"method",key:"_wrapUsersInArray",value:function(e){return e?"string"==typeof e?[e]:e:[]}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation(),xu(this,e)}},{kind:"method",key:"_dataChanged",value:function(e){e.stopPropagation(),e.detail.isValid&&xu(this,e)}},{kind:"method",key:"_usersChanged",value:function(e){e.stopPropagation();const t={...this.trigger};!e.detail.value.length&&t.context?delete t.context.user_id:(t.context||(t.context={}),t.context.user_id=e.detail.value),o(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-textfield {
        display: block;
      }
    `}}]}}),g),f([A("ha-automation-trigger-geo_location")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"field",key:"_schema",value:()=>n((e=>[{name:"source",selector:{text:{}}},{name:"zone",selector:{entity:{domain:"zone"}}},{name:"event",type:"select",required:!0,options:[["enter",e("ui.panel.config.automation.editor.triggers.type.geo_location.enter")],["leave",e("ui.panel.config.automation.editor.triggers.type.geo_location.leave")]]}]))},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{source:"",zone:"",event:"enter"}}},{kind:"method",key:"render",value:function(){return x`
      <ha-form
        .schema=${this._schema(this.hass.localize)}
        .data=${this.trigger}
        .hass=${this.hass}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.geo_location.${e.name}`)}}]}}),g),f([A("ha-automation-trigger-homeassistant")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"field",key:"_schema",value:()=>n((e=>[{name:"event",type:"select",required:!0,options:[["start",e("ui.panel.config.automation.editor.triggers.type.homeassistant.start")],["shutdown",e("ui.panel.config.automation.editor.triggers.type.homeassistant.shutdown")]]}]))},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{event:"start"}}},{kind:"method",key:"render",value:function(){return x`
      <ha-form
        .schema=${this._schema(this.hass.localize)}
        .data=${this.trigger}
        .hass=${this.hass}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.homeassistant.${e.name}`)}},{kind:"field",static:!0,key:"styles",value:()=>r`
    label {
      display: flex;
      align-items: center;
    }
  `}]}}),g);const gu=[{name:"topic",required:!0,selector:{text:{}}},{name:"payload",selector:{text:{}}}];f([A("ha-automation-trigger-mqtt")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{topic:""}}},{kind:"method",key:"render",value:function(){return x`
      <ha-form
        .schema=${gu}
        .data=${this.trigger}
        .hass=${this.hass}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.mqtt.${e.name}`)}}]}}),g),f([A("ha-automation-trigger-numeric_state")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"field",key:"_schema",value:()=>n((e=>[{name:"entity_id",required:!0,selector:{entity:{}}},{name:"attribute",selector:{attribute:{entity_id:e,hide_attributes:["access_token","auto_update","available_modes","away_mode","changed_by","code_format","color_modes","current_activity","device_class","editable","effect_list","effect","entity_picture","fan_mode","fan_modes","fan_speed_list","forecast","friendly_name","frontend_stream_type","has_date","has_time","hs_color","hvac_mode","hvac_modes","icon","media_album_name","media_artist","media_content_type","media_position_updated_at","media_title","next_dawn","next_dusk","next_midnight","next_noon","next_rising","next_setting","operation_list","operation_mode","options","preset_mode","preset_modes","release_notes","release_summary","release_url","restored","rgb_color","rgbw_color","shuffle","sound_mode_list","sound_mode","source_list","source_type","source","state_class","supported_features","swing_mode","swing_mode","swing_modes","title","token","unit_of_measurement","xy_color"]}}},{name:"above",selector:{number:{mode:"box",min:Number.MIN_SAFE_INTEGER,max:Number.MAX_SAFE_INTEGER,step:.1}}},{name:"below",selector:{number:{mode:"box",min:Number.MIN_SAFE_INTEGER,max:Number.MAX_SAFE_INTEGER,step:.1}}},{name:"value_template",selector:{template:{}}},{name:"for",selector:{duration:{}}}]))},{kind:"method",key:"willUpdate",value:function(e){e.has("trigger")&&this.trigger&&wo(this.trigger.for)&&o(this,"ui-mode-not-available",Error(this.hass.localize("ui.errors.config.no_template_editor_support")))}},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{entity_id:""}}},{kind:"method",key:"render",value:function(){const e=Bc(this.trigger.for),t={...this.trigger,for:e},i=this._schema(this.trigger.entity_id);return x`
      <ha-form
        .hass=${this.hass}
        .data=${t}
        .schema=${i}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>{switch(e.name){case"entity_id":return this.hass.localize("ui.components.entity.entity-picker.entity");case"attribute":return this.hass.localize("ui.components.entity.entity-attribute-picker.attribute");case"for":return this.hass.localize("ui.panel.config.automation.editor.triggers.type.state.for");default:return this.hass.localize(`ui.panel.config.automation.editor.triggers.type.numeric_state.${e.name}`)}}}}]}}),g);const _u=Qn(Nc,no({alias:oo(so()),platform:io("state"),entity_id:oo(lo([so(),eo(so())])),attribute:oo(so()),from:oo(so()),to:oo(so()),for:oo(lo([so(),Vc]))}));f([A("ha-automation-trigger-state")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{entity_id:[]}}},{kind:"field",key:"_schema",value:()=>n(((e,t)=>[{name:"entity_id",required:!0,selector:{entity:{multiple:!0}}},{name:"attribute",selector:{attribute:{entity_id:e?e[0]:void 0,hide_attributes:["access_token","available_modes","color_modes","device_class","editable","effect_list","entity_picture","fan_modes","fan_speed_list","friendly_name","has_date","has_time","hvac_modes","icon","operation_list","options","preset_modes","sound_mode_list","source_list","state_class","supported_features","swing_modes","token","unit_of_measurement"]}}},{name:"from",selector:{state:{entity_id:e?e[0]:void 0,attribute:t}}},{name:"to",selector:{state:{entity_id:e?e[0]:void 0,attribute:t}}},{name:"for",selector:{duration:{}}}]))},{kind:"method",key:"shouldUpdate",value:function(e){if(!e.has("trigger"))return!0;if(this.trigger.for&&"object"==typeof this.trigger.for&&0===this.trigger.for.milliseconds&&delete this.trigger.for.milliseconds,this.trigger&&wo(this.trigger))return o(this,"ui-mode-not-available",Error(this.hass.localize("ui.errors.config.no_template_editor_support"))),!1;try{Kn(this.trigger,_u)}catch(e){return o(this,"ui-mode-not-available",e),!1}return!0}},{kind:"method",key:"render",value:function(){const e=Bc(this.trigger.for),t={...this.trigger,entity_id:ko(this.trigger.entity_id),for:e},i=this._schema(this.trigger.entity_id,this.trigger.attribute);return x`
      <ha-form
        .hass=${this.hass}
        .data=${t}
        .schema=${i}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;Object.keys(t).forEach((e=>void 0===t[e]||""===t[e]?delete t[e]:{})),o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize("entity_id"===e.name?"ui.components.entity.entity-picker.entity":`ui.panel.config.automation.editor.triggers.type.state.${e.name}`)}}]}}),g),f([A("ha-automation-trigger-sun")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"field",key:"_schema",value:()=>n((e=>[{name:"event",type:"select",required:!0,options:[["sunrise",e("ui.panel.config.automation.editor.triggers.type.sun.sunrise")],["sunset",e("ui.panel.config.automation.editor.triggers.type.sun.sunset")]]},{name:"offset",selector:{text:{}}}]))},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{event:"sunrise",offset:0}}},{kind:"method",key:"render",value:function(){const e=this._schema(this.hass.localize);return x`
      <ha-form
        .schema=${e}
        .data=${this.trigger}
        .hass=${this.hass}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.sun.${e.name}`)}}]}}),g);f([A("ha-automation-trigger-tag")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"trigger",value:void 0},{kind:"field",decorators:[Qi()],key:"_tags",value:()=>[]},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{tag_id:""}}},{kind:"method",key:"firstUpdated",value:function(e){k(b(i.prototype),"firstUpdated",this).call(this,e),this._fetchTags()}},{kind:"method",key:"render",value:function(){const{tag_id:e}=this.trigger;return x`
      <ha-select
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.tag.label")}
        .disabled=${0===this._tags.length}
        .value=${e}
        @selected=${this._tagChanged}
      >
        ${this._tags.map((e=>x`
            <mwc-list-item .value=${e.id}>
              ${e.name||e.id}
            </mwc-list-item>
          `))}
      </ha-select>
    `}},{kind:"method",key:"_fetchTags",value:async function(){this._tags=await(async e=>e.callWS({type:"tag/list"}))(this.hass),this._tags.sort(((e,t)=>ys(e.name||e.id,t.name||t.id)))}},{kind:"method",key:"_tagChanged",value:function(e){o(this,"value-changed",{value:{...this.trigger,tag_id:e.target.value}})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-select {
        display: block;
      }
    `}}]}}),g),f([A("ha-automation-trigger-template")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{value_template:""}}},{kind:"method",key:"render",value:function(){const{value_template:e}=this.trigger;return x`
      <p>
        ${this.hass.localize("ui.panel.config.automation.editor.triggers.type.template.value_template")}
        *
      </p>
      <ha-code-editor
        .name=${"value_template"}
        mode="jinja2"
        .hass=${this.hass}
        .value=${e}
        autocomplete-entities
        @value-changed=${this._valueChanged}
        dir="ltr"
      ></ha-code-editor>
    `}},{kind:"method",key:"_valueChanged",value:function(e){xu(this,e)}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      p {
        margin-top: 0;
      }
    `}}]}}),g),f([A("ha-automation-trigger-time")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"field",decorators:[Qi()],key:"_inputMode",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{at:""}}},{kind:"field",key:"_schema",value:()=>n(((e,t)=>{const i=t?{entity:{domain:"input_datetime"}}:{time:{}};return[{name:"mode",type:"select",required:!0,options:[["value",e("ui.panel.config.automation.editor.triggers.type.time.type_value")],["input",e("ui.panel.config.automation.editor.triggers.type.time.type_input")]]},{name:"at",selector:i}]}))},{kind:"method",key:"willUpdate",value:function(e){e.has("trigger")&&this.trigger&&Array.isArray(this.trigger.at)&&o(this,"ui-mode-not-available",Error(this.hass.localize("ui.errors.config.editor_not_supported")))}},{kind:"method",key:"render",value:function(){var e;const t=this.trigger.at;if(Array.isArray(t))return x``;const i=null!==(e=this._inputMode)&&void 0!==e?e:(null==t?void 0:t.startsWith("input_datetime."))||(null==t?void 0:t.startsWith("sensor.")),a=this._schema(this.hass.localize,i),n={mode:i?"input":"value",...this.trigger};return x`
      <ha-form
        .hass=${this.hass}
        .data=${n}
        .schema=${a}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;this._inputMode="input"===t.mode,delete t.mode,Object.keys(t).forEach((e=>void 0===t[e]||""===t[e]?delete t[e]:{})),o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.time.${e.name}`)}}]}}),g);const yu=[{name:"hours",selector:{text:{}}},{name:"minutes",selector:{text:{}}},{name:"seconds",selector:{text:{}}}];f([A("ha-automation-trigger-time_pattern")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{}}},{kind:"method",key:"render",value:function(){return x`
      <ha-form
        .hass=${this.hass}
        .schema=${yu}
        .data=${this.trigger}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;o(this,"value-changed",{value:t})}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.time_pattern.${e.name}`)}}]}}),g);function ku(e){return Gc(e)&&"zone"!==Hr(e)}f([A("ha-automation-trigger-webhook")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"trigger",value:void 0},{kind:"field",decorators:[Qi()],key:"_config",value:void 0},{kind:"field",key:"_unsub",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{webhook_id:""}}},{kind:"method",key:"connectedCallback",value:function(){k(b(i.prototype),"connectedCallback",this).call(this);const e={callback:e=>{this._config=e}};o(this,"subscribe-automation-config",e),this._unsub=e.unsub}},{kind:"method",key:"disconnectedCallback",value:function(){k(b(i.prototype),"disconnectedCallback",this).call(this),this._unsub&&this._unsub()}},{kind:"method",key:"_generateWebhookId",value:function(){var e;const t=crypto.getRandomValues(new Uint8Array(18)),i=btoa(String.fromCharCode(...t)).replace(/\+/g,"-").replace(/\//g,"_"),a=((e,t="_")=>{const i="àáäâãåăæąçćčđďèéěėëêęğǵḧìíïîįłḿǹńňñòóöôœøṕŕřßşśšșťțùúüûǘůűūųẃẍÿýźžż·/_,:;",a=`aaaaaaaaacccddeeeeeeegghiiiiilmnnnnooooooprrsssssttuuuuuuuuuwxyyzzz${t}${t}${t}${t}${t}${t}`,n=new RegExp(i.split("").join("|"),"g");return e.toString().toLowerCase().replace(/\s+/g,t).replace(n,(e=>a.charAt(i.indexOf(e)))).replace(/&/g,`${t}and${t}`).replace(/[^\w-]+/g,"").replace(/-/g,t).replace(new RegExp(`(${t})\\1+`,"g"),"$1").replace(new RegExp(`^${t}+`),"").replace(new RegExp(`${t}+$`),"")})((null===(e=this._config)||void 0===e?void 0:e.alias)||"","-");return`${a}-${i}`}},{kind:"method",key:"willUpdate",value:function(e){k(b(i.prototype),"willUpdate",this).call(this,e),e.has("trigger")&&""===this.trigger.webhook_id&&(this.trigger.webhook_id=this._generateWebhookId())}},{kind:"method",key:"render",value:function(){const{webhook_id:e}=this.trigger;return x`
      <ha-textfield
        name="webhook_id"
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.webhook.webhook_id")}
        .helper=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.webhook.webhook_id_helper")}
        iconTrailing
        .value=${e||""}
        @input=${this._valueChanged}
      >
        <ha-icon-button
          @click=${this._copyUrl}
          slot="trailingIcon"
          .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.webhook.copy_url")}
          .path=${Ha}
        ></ha-icon-button>
      </ha-textfield>
    `}},{kind:"method",key:"_valueChanged",value:function(e){xu(this,e)}},{kind:"method",key:"_copyUrl",value:async function(e){const t=e.target.parentElement,i=this.hass.hassUrl(`/api/webhook/${t.value}`);await(async e=>{if(navigator.clipboard)try{return void await navigator.clipboard.writeText(e)}catch{}const t=document.createElement("textarea");t.value=e,document.body.appendChild(t),t.select(),document.execCommand("copy"),document.body.removeChild(t)})(i),fs(this,{message:this.hass.localize("ui.common.copied_clipboard")})}},{kind:"field",static:!0,key:"styles",value:()=>r`
    ha-textfield {
      display: block;
    }

    ha-textfield > ha-icon-button {
      --mdc-icon-button-size: 24px;
      --mdc-icon-size: 18px;
    }
  `}]}}),g);const bu=["zone"];f([A("ha-automation-trigger-zone")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"trigger",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{entity_id:"",zone:"",event:"enter"}}},{kind:"method",key:"render",value:function(){const{entity_id:e,zone:t,event:i}=this.trigger;return x`
      <ha-entity-picker
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.entity")}
        .value=${e}
        @value-changed=${this._entityPicked}
        .hass=${this.hass}
        allow-custom-entity
        .entityFilter=${ku}
      ></ha-entity-picker>
      <ha-entity-picker
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.zone")}
        .value=${t}
        @value-changed=${this._zonePicked}
        .hass=${this.hass}
        allow-custom-entity
        .includeDomains=${bu}
      ></ha-entity-picker>

      <label>
        ${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.event")}
        <ha-formfield
          .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.enter")}
        >
          <ha-radio
            name="event"
            value="enter"
            .checked=${"enter"===i}
            @change=${this._radioGroupPicked}
          ></ha-radio>
        </ha-formfield>
        <ha-formfield
          .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.leave")}
        >
          <ha-radio
            name="event"
            value="leave"
            .checked=${"leave"===i}
            @change=${this._radioGroupPicked}
          ></ha-radio>
        </ha-formfield>
      </label>
    `}},{kind:"method",key:"_entityPicked",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.trigger,entity_id:e.detail.value}})}},{kind:"method",key:"_zonePicked",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.trigger,zone:e.detail.value}})}},{kind:"method",key:"_radioGroupPicked",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:{...this.trigger,event:e.target.value}})}},{kind:"field",static:!0,key:"styles",value:()=>r`
    label {
      display: flex;
      align-items: center;
    }
    ha-entity-picker {
      display: block;
      margin-bottom: 24px;
    }
  `}]}}),g);const xu=(e,t)=>{var i,a;t.stopPropagation();const n=null===(i=t.currentTarget)||void 0===i?void 0:i.name;if(!n)return;const s=null===(a=t.target)||void 0===a?void 0:a.value;if((e.trigger[n]||"")===s)return;let r;void 0===s||""===s?(r={...e.trigger},delete r[n]):r={...e.trigger,[n]:s},o(e,"value-changed",{value:r})},$u=e=>e.preventDefault();f([A("ha-automation-trigger-row")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"trigger",value:void 0},{kind:"field",decorators:[Qi()],key:"_warnings",value:void 0},{kind:"field",decorators:[Qi()],key:"_yamlMode",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_requestShowId",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_triggered",value:void 0},{kind:"field",decorators:[Qi()],key:"_triggerColor",value:()=>!1},{kind:"field",decorators:[y("ha-yaml-editor")],key:"_yamlEditor",value:void 0},{kind:"field",key:"_triggerUnsub",value:void 0},{kind:"method",key:"render",value:function(){const e=void 0!==customElements.get(`ha-automation-trigger-${this.trigger.platform}`),t=this._yamlMode||!e,i="id"in this.trigger||this._requestShowId;return x`
      <ha-card outlined>
        ${!1===this.trigger.enabled?x`
              <div class="disabled-bar">
                ${this.hass.localize("ui.panel.config.automation.editor.actions.disabled")}
              </div>
            `:""}

        <ha-expansion-panel leftChevron>
          <div slot="header">
            <ha-svg-icon
              class="trigger-icon"
              .path=${hu[this.trigger.platform]}
            ></ha-svg-icon>
            ${us(ps(this.trigger,this.hass))}
          </div>
          <ha-button-menu
            slot="icons"
            fixed
            corner="BOTTOM_START"
            @action=${this._handleAction}
            @click=${$u}
          >
            <ha-icon-button
              slot="trigger"
              .label=${this.hass.localize("ui.common.menu")}
              .path=${ma}
            ></ha-icon-button>

            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.triggers.rename")}
              <ha-svg-icon slot="graphic" .path=${fa}></ha-svg-icon>
            </mwc-list-item>
            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.duplicate")}
              <ha-svg-icon
                slot="graphic"
                .path=${ga}
              ></ha-svg-icon>
            </mwc-list-item>

            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.triggers.edit_id")}
              <ha-svg-icon slot="graphic" .path=${Ga}></ha-svg-icon>
            </mwc-list-item>

            <li divider role="separator"></li>

            <mwc-list-item .disabled=${!e} graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.edit_ui")}
              ${t?"":x`<ha-svg-icon
                    slot="graphic"
                    .path=${_a}
                  ></ha-svg-icon>`}
            </mwc-list-item>

            <mwc-list-item .disabled=${!e} graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.edit_yaml")}
              ${t?x`<ha-svg-icon
                    slot="graphic"
                    .path=${_a}
                  ></ha-svg-icon>`:""}
            </mwc-list-item>

            <li divider role="separator"></li>

            <mwc-list-item graphic="icon">
              ${!1===this.trigger.enabled?this.hass.localize("ui.panel.config.automation.editor.actions.enable"):this.hass.localize("ui.panel.config.automation.editor.actions.disable")}
              <ha-svg-icon
                slot="graphic"
                .path=${!1===this.trigger.enabled?ya:ka}
              ></ha-svg-icon>
            </mwc-list-item>
            <mwc-list-item class="warning" graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.delete")}
              <ha-svg-icon
                class="warning"
                slot="graphic"
                .path=${ea}
              ></ha-svg-icon>
            </mwc-list-item>
          </ha-button-menu>

          <div
            class=${ba({"card-content":!0,disabled:!1===this.trigger.enabled})}
          >
            ${this._warnings?x`<ha-alert
                  alert-type="warning"
                  .title=${this.hass.localize("ui.errors.config.editor_not_supported")}
                >
                  ${this._warnings.length&&void 0!==this._warnings[0]?x` <ul>
                        ${this._warnings.map((e=>x`<li>${e}</li>`))}
                      </ul>`:""}
                  ${this.hass.localize("ui.errors.config.edit_in_yaml_supported")}
                </ha-alert>`:""}
            ${t?x`
                  ${e?"":x`
                        ${this.hass.localize("ui.panel.config.automation.editor.triggers.unsupported_platform","platform",this.trigger.platform)}
                      `}
                  <ha-yaml-editor
                    .hass=${this.hass}
                    .defaultValue=${this.trigger}
                    @value-changed=${this._onYamlChange}
                  ></ha-yaml-editor>
                `:x`
                  ${i?x`
                        <ha-textfield
                          .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.id")}
                          .value=${this.trigger.id||""}
                          @change=${this._idChanged}
                        >
                        </ha-textfield>
                      `:""}
                  <div @ui-mode-not-available=${this._handleUiModeNotAvailable}>
                    ${hn(`ha-automation-trigger-${this.trigger.platform}`,{hass:this.hass,trigger:this.trigger})}
                  </div>
                `}
          </div>
        </ha-expansion-panel>

        <div
          class="triggered ${ba({active:void 0!==this._triggered,accent:this._triggerColor})}"
          @click=${this._showTriggeredInfo}
        >
          ${this.hass.localize("ui.panel.config.automation.editor.triggers.triggered")}
        </div>
      </ha-card>
    `}},{kind:"method",key:"updated",value:function(e){k(b(i.prototype),"updated",this).call(this,e),e.has("trigger")&&this._subscribeTrigger()}},{kind:"method",key:"connectedCallback",value:function(){k(b(i.prototype),"connectedCallback",this).call(this),this.hasUpdated&&this.trigger&&this._subscribeTrigger()}},{kind:"method",key:"disconnectedCallback",value:function(){k(b(i.prototype),"disconnectedCallback",this).call(this),this._triggerUnsub&&(this._triggerUnsub.then((e=>e())),this._triggerUnsub=void 0),this._doSubscribeTrigger.cancel()}},{kind:"method",key:"_subscribeTrigger",value:function(){this._triggerUnsub&&(this._triggerUnsub.then((e=>e())),this._triggerUnsub=void 0),this._doSubscribeTrigger()}},{kind:"field",key:"_doSubscribeTrigger",value(){return un((async()=>{let e;const t=this.trigger;this._triggerUnsub&&(this._triggerUnsub.then((e=>e())),this._triggerUnsub=void 0);if(!(await uo(this.hass,{trigger:t})).trigger.valid||this.trigger!==t)return;const i=((e,t,i,a)=>e.connection.subscribeMessage(t,{type:"subscribe_trigger",trigger:i,variables:a}))(this.hass,(t=>{void 0!==e?(clearTimeout(e),this._triggerColor=!this._triggerColor):this._triggerColor=!1,this._triggered=t,e=window.setTimeout((()=>{this._triggered=void 0,e=void 0}),5e3)}),t);i.catch((()=>{this._triggerUnsub===i&&(this._triggerUnsub=void 0)})),this._triggerUnsub=i}),5e3)}},{kind:"method",key:"_handleUiModeNotAvailable",value:function(e){this._warnings=co(this.hass,e.detail).warnings,this._yamlMode||(this._yamlMode=!0)}},{kind:"method",key:"_handleAction",value:async function(e){switch(e.detail.index){case 0:await this._renameTrigger();break;case 1:o(this,"duplicate");break;case 2:this._requestShowId=!0,this.expand();break;case 3:this._switchUiMode(),this.expand();break;case 4:this._switchYamlMode(),this.expand();break;case 5:this._onDisable();break;case 6:this._onDelete()}}},{kind:"method",key:"_onDelete",value:function(){$n(this,{text:this.hass.localize("ui.panel.config.automation.editor.triggers.delete_confirm"),dismissText:this.hass.localize("ui.common.cancel"),confirmText:this.hass.localize("ui.common.delete"),confirm:()=>{o(this,"value-changed",{value:null})}})}},{kind:"method",key:"_onDisable",value:function(){var e;const t=!(null===(e=this.trigger.enabled)||void 0===e||e),i={...this.trigger,enabled:t};var a;(o(this,"value-changed",{value:i}),this._yamlMode)&&(null===(a=this._yamlEditor)||void 0===a||a.setValue(i))}},{kind:"method",key:"_idChanged",value:function(e){var t;const i=e.target.value;if(i===(null!==(t=this.trigger.id)&&void 0!==t?t:""))return;this._requestShowId=!0;const a={...this.trigger};i?a.id=i:delete a.id,o(this,"value-changed",{value:a})}},{kind:"method",key:"_onYamlChange",value:function(e){e.stopPropagation(),e.detail.isValid&&(this._warnings=void 0,o(this,"value-changed",{value:e.detail.value}))}},{kind:"method",key:"_switchUiMode",value:function(){this._warnings=void 0,this._yamlMode=!1}},{kind:"method",key:"_switchYamlMode",value:function(){this._warnings=void 0,this._yamlMode=!0}},{kind:"method",key:"_showTriggeredInfo",value:function(){wn(this,{text:x`
        <ha-yaml-editor
          readOnly
          .hass=${this.hass}
          .defaultValue=${this._triggered}
        ></ha-yaml-editor>
      `})}},{kind:"method",key:"_renameTrigger",value:async function(){const e=await Cn(this,{title:this.hass.localize("ui.panel.config.automation.editor.triggers.change_alias"),inputLabel:this.hass.localize("ui.panel.config.automation.editor.triggers.alias"),inputType:"string",placeholder:us(ps(this.trigger,this.hass,!0)),defaultValue:this.trigger.alias,confirmText:this.hass.localize("ui.common.submit")}),t={...this.trigger};var i;(e?t.alias=e:delete t.alias,o(this,"value-changed",{value:t}),this._yamlMode)&&(null===(i=this._yamlEditor)||void 0===i||i.setValue(t))}},{kind:"method",key:"expand",value:function(){this.updateComplete.then((()=>{this.shadowRoot.querySelector("ha-expansion-panel").expanded=!0}))}},{kind:"get",static:!0,key:"styles",value:function(){return[ia,r`
        ha-button-menu {
          --mdc-theme-text-primary-on-background: var(--primary-text-color);
        }
        .disabled {
          opacity: 0.5;
          pointer-events: none;
        }
        ha-expansion-panel {
          --expansion-panel-summary-padding: 0 0 0 8px;
          --expansion-panel-content-padding: 0;
        }
        .trigger-icon {
          color: var(--sidebar-icon-color);
          padding-right: 8px;
        }
        .card-content {
          padding: 16px;
        }
        .disabled-bar {
          background: var(--divider-color, #e0e0e0);
          text-align: center;
          border-top-right-radius: var(--ha-card-border-radius);
          border-top-left-radius: var(--ha-card-border-radius);
        }
        .triggered {
          cursor: pointer;
          position: absolute;
          top: 0px;
          right: 0px;
          left: 0px;
          text-transform: uppercase;
          font-weight: bold;
          font-size: 14px;
          background-color: var(--primary-color);
          color: var(--text-primary-color);
          max-height: 0px;
          overflow: hidden;
          transition: max-height 0.3s;
          text-align: center;
          border-top-right-radius: var(--ha-card-border-radius, 4px);
          border-top-left-radius: var(--ha-card-border-radius, 4px);
        }
        .triggered.active {
          max-height: 100px;
        }
        .triggered:hover {
          opacity: 0.8;
        }
        .triggered.accent {
          background-color: var(--accent-color);
          color: var(--text-accent-color, var(--text-primary-color));
        }
        mwc-list-item[disabled] {
          --mdc-theme-text-primary-on-background: var(--disabled-text-color);
        }
        ha-textfield {
          display: block;
          margin-bottom: 24px;
        }
      `]}}]}}),g),f([A("ha-automation-trigger")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"triggers",value:void 0},{kind:"field",key:"_focusLastTriggerOnChange",value:()=>!1},{kind:"field",key:"_triggerKeys",value:()=>new WeakMap},{kind:"method",key:"render",value:function(){return x`
      ${Nn(this.triggers,(e=>this._getKey(e)),((e,t)=>x`
          <ha-automation-trigger-row
            .index=${t}
            .trigger=${e}
            @duplicate=${this._duplicateTrigger}
            @value-changed=${this._triggerChanged}
            .hass=${this.hass}
          ></ha-automation-trigger-row>
        `))}
      <ha-button-menu @action=${this._addTrigger}>
        <mwc-button
          slot="trigger"
          outlined
          .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.add")}
        >
          <ha-svg-icon .path=${ta} slot="icon"></ha-svg-icon>
        </mwc-button>
        ${this._processedTypes(this.hass.localize).map((([e,t,i])=>x`
            <mwc-list-item .value=${e} aria-label=${t} graphic="icon">
              ${t}<ha-svg-icon slot="graphic" .path=${i}></ha-svg-icon
            ></mwc-list-item>
          `))}
      </ha-button-menu>
    `}},{kind:"method",key:"updated",value:function(e){if(k(b(i.prototype),"updated",this).call(this,e),e.has("triggers")&&this._focusLastTriggerOnChange){this._focusLastTriggerOnChange=!1;const e=this.shadowRoot.querySelector("ha-automation-trigger-row:last-of-type");e.updateComplete.then((()=>{e.expand(),e.scrollIntoView(),e.focus()}))}}},{kind:"method",key:"_getKey",value:function(e){return this._triggerKeys.has(e)||this._triggerKeys.set(e,Math.random().toString()),this._triggerKeys.get(e)}},{kind:"method",key:"_addTrigger",value:function(e){const t=e.currentTarget.items[e.detail.index].value,i=customElements.get(`ha-automation-trigger-${t}`),a=this.triggers.concat({platform:t,...i.defaultConfig});this._focusLastTriggerOnChange=!0,o(this,"value-changed",{value:a})}},{kind:"method",key:"_triggerChanged",value:function(e){e.stopPropagation();const t=[...this.triggers],i=e.detail.value,a=e.target.index;if(null===i)t.splice(a,1);else{const e=this._getKey(t[a]);this._triggerKeys.set(i,e),t[a]=i}o(this,"value-changed",{value:t})}},{kind:"method",key:"_duplicateTrigger",value:function(e){e.stopPropagation();const t=e.target.index;o(this,"value-changed",{value:this.triggers.concat(Vn(this.triggers[t]))})}},{kind:"field",key:"_processedTypes",value:()=>n((e=>Object.entries(hu).map((([t,i])=>[t,e(`ui.panel.config.automation.editor.triggers.type.${t}.label`),i])).sort(((e,t)=>_s(e[1],t[1])))))},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-automation-trigger-row {
        display: block;
        margin-bottom: 16px;
        scroll-margin-top: 48px;
      }
      ha-svg-icon {
        height: 20px;
      }
    `}}]}}),g),f([A("ha-automation-action-wait_for_trigger")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{wait_for_trigger:[]}}},{kind:"method",key:"render",value:function(){var e;const t=Bc(this.action.timeout);return x`
      <ha-duration-input
        .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.wait_for_trigger.timeout")}
        .data=${t}
        enableMillisecond
        @value-changed=${this._timeoutChanged}
      ></ha-duration-input>
      <ha-formfield
        .label=${this.hass.localize("ui.panel.config.automation.editor.actions.type.wait_for_trigger.continue_timeout")}
      >
        <ha-switch
          .checked=${null===(e=this.action.continue_on_timeout)||void 0===e||e}
          @change=${this._continueChanged}
        ></ha-switch>
      </ha-formfield>
      <ha-automation-trigger
        .triggers=${ko(this.action.wait_for_trigger)}
        .hass=${this.hass}
        .name=${"wait_for_trigger"}
        @value-changed=${this._valueChanged}
      ></ha-automation-trigger>
    `}},{kind:"method",key:"_timeoutChanged",value:function(e){e.stopPropagation();const t=e.detail.value;t&&o(this,"value-changed",{value:{...this.action,timeout:t}})}},{kind:"method",key:"_continueChanged",value:function(e){o(this,"value-changed",{value:{...this.action,continue_on_timeout:e.target.checked}})}},{kind:"method",key:"_valueChanged",value:function(e){Iu(this,e)}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-duration-input {
        display: block;
        margin-bottom: 24px;
      }
      ha-automation-trigger {
        display: block;
        margin-top: 24px;
      }
    `}}]}}),g);const wu=[{name:"wait_template",selector:{template:{}}},{name:"timeout",required:!1,selector:{text:{}}},{name:"continue_on_timeout",selector:{boolean:{}}}];f([A("ha-automation-action-wait_template")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"action",value:void 0},{kind:"get",static:!0,key:"defaultConfig",value:function(){return{wait_template:"",continue_on_timeout:!0}}},{kind:"method",key:"render",value:function(){return x`
      <ha-form
        .hass=${this.hass}
        .data=${this.action}
        .schema=${wu}
        .computeLabel=${this._computeLabelCallback}
      ></ha-form>
    `}},{kind:"field",key:"_computeLabelCallback",value(){return e=>this.hass.localize(`ui.panel.config.automation.editor.actions.type.wait_template.${"continue_on_timeout"===e.name?"continue_timeout":e.name}`)}}]}}),g);const Cu={condition:Wa,delay:re,event:ua,play_media:dt,activate_scene:ie,service:Ka,wait_template:Ya,wait_for_trigger:Ya,repeat:Za,choose:Qa,if:Ja,device_id:aa,stop:Xa,parallel:en},Au=e=>{if(e)return"service"in e||"scene"in e?go(e):["and","or","not"].some((t=>t in e))?"condition":Object.keys(Cu).find((t=>t in e))},Iu=(e,t)=>{var i,a;t.stopPropagation();const n=null===(i=t.target)||void 0===i?void 0:i.name;if(!n)return;const s=(null===(a=t.detail)||void 0===a?void 0:a.value)||t.target.value;if((e.action[n]||"")===s)return;let r;s?r={...e.action,[n]:s}:(r={...e.action},delete r[n]),o(e,"value-changed",{value:r})},Eu=e=>e.preventDefault();f([A("ha-automation-action-row")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"action",value:void 0},{kind:"field",decorators:[_()],key:"index",value:void 0},{kind:"field",decorators:[_()],key:"totalActions",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_warnings",value:void 0},{kind:"field",decorators:[Qi()],key:"_uiModeAvailable",value:()=>!0},{kind:"field",decorators:[Qi()],key:"_yamlMode",value:()=>!1},{kind:"field",decorators:[y("ha-yaml-editor")],key:"_yamlEditor",value:void 0},{kind:"method",key:"willUpdate",value:function(e){e.has("action")&&(this._uiModeAvailable=void 0!==Au(this.action),this._uiModeAvailable||this._yamlMode||(this._yamlMode=!0))}},{kind:"method",key:"updated",value:function(e){if(e.has("action")&&this._yamlMode){const e=this._yamlEditor;e&&e.value!==this.action&&e.setValue(this.action)}}},{kind:"method",key:"render",value:function(){const e=Au(this.action),t=this._yamlMode;return x`
      <ha-card outlined>
        ${!1===this.action.enabled?x`<div class="disabled-bar">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.disabled")}
            </div>`:""}
        <ha-expansion-panel leftChevron>
          <div slot="header">
            <ha-svg-icon
              class="action-icon"
              .path=${Cu[e]}
            ></ha-svg-icon>
            ${us(ms(this.hass,this.action))}
          </div>

          ${0!==this.index?x`
                <ha-icon-button
                  slot="icons"
                  .label=${this.hass.localize("ui.panel.config.automation.editor.move_up")}
                  .path=${tn}
                  @click=${this._moveUp}
                ></ha-icon-button>
              `:""}
          ${this.index!==this.totalActions-1?x`
                <ha-icon-button
                  slot="icons"
                  .label=${this.hass.localize("ui.panel.config.automation.editor.move_down")}
                  .path=${an}
                  @click=${this._moveDown}
                ></ha-icon-button>
              `:""}
          <ha-button-menu
            slot="icons"
            fixed
            corner="BOTTOM_START"
            @action=${this._handleAction}
            @click=${Eu}
          >
            <ha-icon-button
              slot="trigger"
              .label=${this.hass.localize("ui.common.menu")}
              .path=${ma}
            ></ha-icon-button>
            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.run")}
              <ha-svg-icon slot="graphic" .path=${dt}></ha-svg-icon>
            </mwc-list-item>

            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.rename")}
              <ha-svg-icon slot="graphic" .path=${fa}></ha-svg-icon>
            </mwc-list-item>
            <mwc-list-item graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.duplicate")}
              <ha-svg-icon
                slot="graphic"
                .path=${ga}
              ></ha-svg-icon>
            </mwc-list-item>

            <li divider role="separator"></li>

            <mwc-list-item .disabled=${!this._uiModeAvailable} graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.edit_ui")}
              ${t?"":x`<ha-svg-icon
                    slot="graphic"
                    .path=${_a}
                  ></ha-svg-icon>`}
            </mwc-list-item>

            <mwc-list-item .disabled=${!this._uiModeAvailable} graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.edit_yaml")}
              ${t?x`<ha-svg-icon
                    slot="graphic"
                    .path=${_a}
                  ></ha-svg-icon>`:""}
            </mwc-list-item>

            <li divider role="separator"></li>

            <mwc-list-item graphic="icon">
              ${!1===this.action.enabled?this.hass.localize("ui.panel.config.automation.editor.actions.enable"):this.hass.localize("ui.panel.config.automation.editor.actions.disable")}
              <ha-svg-icon
                slot="graphic"
                .path=${!1===this.action.enabled?ya:ka}
              ></ha-svg-icon>
            </mwc-list-item>
            <mwc-list-item class="warning" graphic="icon">
              ${this.hass.localize("ui.panel.config.automation.editor.actions.delete")}
              <ha-svg-icon
                class="warning"
                slot="graphic"
                .path=${ea}
              ></ha-svg-icon>
            </mwc-list-item>
          </ha-button-menu>
          <div
            class=${ba({"card-content":!0,disabled:!1===this.action.enabled})}
          >
            ${this._warnings?x`<ha-alert
                  alert-type="warning"
                  .title=${this.hass.localize("ui.errors.config.editor_not_supported")}
                >
                  ${this._warnings.length>0&&void 0!==this._warnings[0]?x` <ul>
                        ${this._warnings.map((e=>x`<li>${e}</li>`))}
                      </ul>`:""}
                  ${this.hass.localize("ui.errors.config.edit_in_yaml_supported")}
                </ha-alert>`:""}
            ${t?x`
                  ${void 0===e?x`
                        ${this.hass.localize("ui.panel.config.automation.editor.actions.unsupported_action","action",e)}
                      `:""}
                  <ha-yaml-editor
                    .hass=${this.hass}
                    .defaultValue=${this.action}
                    @value-changed=${this._onYamlChange}
                  ></ha-yaml-editor>
                `:x`
                  <div @ui-mode-not-available=${this._handleUiModeNotAvailable}>
                    ${hn(`ha-automation-action-${e}`,{hass:this.hass,action:this.action,narrow:this.narrow})}
                  </div>
                `}
          </div>
        </ha-expansion-panel>
      </ha-card>
    `}},{kind:"method",key:"_handleUiModeNotAvailable",value:function(e){e.stopPropagation(),this._warnings=co(this.hass,e.detail).warnings,this._yamlMode||(this._yamlMode=!0)}},{kind:"method",key:"_moveUp",value:function(e){e.preventDefault(),o(this,"move-action",{direction:"up"})}},{kind:"method",key:"_moveDown",value:function(e){e.preventDefault(),o(this,"move-action",{direction:"down"})}},{kind:"method",key:"_handleAction",value:async function(e){switch(e.detail.index){case 0:this._runAction();break;case 1:await this._renameAction();break;case 2:o(this,"duplicate");break;case 3:this._switchUiMode(),this.expand();break;case 4:this._switchYamlMode(),this.expand();break;case 5:this._onDisable();break;case 6:this._onDelete()}}},{kind:"method",key:"_onDisable",value:function(){var e;const t=!(null===(e=this.action.enabled)||void 0===e||e),i={...this.action,enabled:t};var a;(o(this,"value-changed",{value:i}),this._yamlMode)&&(null===(a=this._yamlEditor)||void 0===a||a.setValue(i))}},{kind:"method",key:"_runAction",value:async function(){const e=await uo(this.hass,{action:this.action});if(e.action.valid){try{await(t=this.hass,i=this.action,t.callWS({type:"execute_script",sequence:i}))}catch(e){return void wn(this,{title:this.hass.localize("ui.panel.config.automation.editor.actions.run_action_error"),text:e.message||e})}var t,i;fs(this,{message:this.hass.localize("ui.panel.config.automation.editor.actions.run_action_success")})}else wn(this,{title:this.hass.localize("ui.panel.config.automation.editor.actions.invalid_action"),text:e.action.error})}},{kind:"method",key:"_onDelete",value:function(){$n(this,{text:this.hass.localize("ui.panel.config.automation.editor.actions.delete_confirm"),dismissText:this.hass.localize("ui.common.cancel"),confirmText:this.hass.localize("ui.common.delete"),confirm:()=>{o(this,"value-changed",{value:null})}})}},{kind:"method",key:"_onYamlChange",value:function(e){e.stopPropagation(),e.detail.isValid&&o(this,"value-changed",{value:e.detail.value})}},{kind:"method",key:"_switchUiMode",value:function(){this._warnings=void 0,this._yamlMode=!1}},{kind:"method",key:"_switchYamlMode",value:function(){this._warnings=void 0,this._yamlMode=!0}},{kind:"method",key:"_renameAction",value:async function(){const e=await Cn(this,{title:this.hass.localize("ui.panel.config.automation.editor.actions.change_alias"),inputLabel:this.hass.localize("ui.panel.config.automation.editor.actions.alias"),inputType:"string",placeholder:us(ms(this.hass,this.action,void 0,!0)),defaultValue:this.action.alias,confirmText:this.hass.localize("ui.common.submit")}),t={...this.action};var i;(e?t.alias=e:delete t.alias,o(this,"value-changed",{value:t}),this._yamlMode)&&(null===(i=this._yamlEditor)||void 0===i||i.setValue(t))}},{kind:"method",key:"expand",value:function(){this.updateComplete.then((()=>{this.shadowRoot.querySelector("ha-expansion-panel").expanded=!0}))}},{kind:"get",static:!0,key:"styles",value:function(){return[ia,r`
        ha-button-menu,
        ha-icon-button {
          --mdc-theme-text-primary-on-background: var(--primary-text-color);
        }
        .disabled {
          opacity: 0.5;
          pointer-events: none;
        }
        ha-expansion-panel {
          --expansion-panel-summary-padding: 0 0 0 8px;
          --expansion-panel-content-padding: 0;
        }
        .action-icon {
          color: var(--sidebar-icon-color);
          padding-right: 8px;
        }
        .card-content {
          padding: 16px;
        }
        .disabled-bar {
          background: var(--divider-color, #e0e0e0);
          text-align: center;
          border-top-right-radius: var(--ha-card-border-radius);
          border-top-left-radius: var(--ha-card-border-radius);
        }

        mwc-list-item[disabled] {
          --mdc-theme-text-primary-on-background: var(--disabled-text-color);
        }
        .warning ul {
          margin: 4px 0;
        }
      `]}}]}}),g),f([A("ha-automation-action")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[_()],key:"actions",value:void 0},{kind:"field",key:"_focusLastActionOnChange",value:()=>!1},{kind:"field",key:"_actionKeys",value:()=>new WeakMap},{kind:"method",key:"render",value:function(){return x`
      ${Nn(this.actions,(e=>this._getKey(e)),((e,t)=>x`
          <ha-automation-action-row
            .index=${t}
            .totalActions=${this.actions.length}
            .action=${e}
            .narrow=${this.narrow}
            @duplicate=${this._duplicateAction}
            @move-action=${this._move}
            @value-changed=${this._actionChanged}
            .hass=${this.hass}
          ></ha-automation-action-row>
        `))}
      <ha-button-menu fixed @action=${this._addAction}>
        <mwc-button
          slot="trigger"
          outlined
          .label=${this.hass.localize("ui.panel.config.automation.editor.actions.add")}
        >
          <ha-svg-icon .path=${ta} slot="icon"></ha-svg-icon>
        </mwc-button>
        ${this._processedTypes(this.hass.localize).map((([e,t,i])=>x`
            <mwc-list-item .value=${e} aria-label=${t} graphic="icon">
              ${t}<ha-svg-icon slot="graphic" .path=${i}></ha-svg-icon
            ></mwc-list-item>
          `))}
      </ha-button-menu>
    `}},{kind:"method",key:"updated",value:function(e){if(k(b(i.prototype),"updated",this).call(this,e),e.has("actions")&&this._focusLastActionOnChange){this._focusLastActionOnChange=!1;const e=this.shadowRoot.querySelector("ha-automation-action-row:last-of-type");e.updateComplete.then((()=>{e.expand(),e.scrollIntoView(),e.focus()}))}}},{kind:"method",key:"_getKey",value:function(e){return this._actionKeys.has(e)||this._actionKeys.set(e,Math.random().toString()),this._actionKeys.get(e)}},{kind:"method",key:"_addAction",value:function(e){const t=e.currentTarget.items[e.detail.index].value,i=customElements.get(`ha-automation-action-${t}`),a=this.actions.concat({...i.defaultConfig});this._focusLastActionOnChange=!0,o(this,"value-changed",{value:a})}},{kind:"method",key:"_move",value:function(e){e.stopPropagation();const t=e.target.index,i="up"===e.detail.direction?t-1:t+1,a=this.actions.concat(),n=a.splice(t,1)[0];a.splice(i,0,n),o(this,"value-changed",{value:a})}},{kind:"method",key:"_actionChanged",value:function(e){e.stopPropagation();const t=[...this.actions],i=e.detail.value,a=e.target.index;if(null===i)t.splice(a,1);else{const e=this._getKey(t[a]);this._actionKeys.set(i,e),t[a]=i}o(this,"value-changed",{value:t})}},{kind:"method",key:"_duplicateAction",value:function(e){e.stopPropagation();const t=e.target.index;o(this,"value-changed",{value:this.actions.concat(Vn(this.actions[t]))})}},{kind:"field",key:"_processedTypes",value:()=>n((e=>Object.entries(Cu).map((([t,i])=>[t,e(`ui.panel.config.automation.editor.actions.type.${t}.label`),i])).sort(((e,t)=>_s(e[1],t[1])))))},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-automation-action-row {
        display: block;
        margin-bottom: 16px;
        scroll-margin-top: 48px;
      }
      ha-svg-icon {
        height: 20px;
      }
    `}}]}}),g),f([A("ha-selector-action")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"method",key:"render",value:function(){return x`<ha-automation-action
      .disabled=${this.disabled}
      .actions=${this.value||[]}
      .hass=${this.hass}
    ></ha-automation-action>`}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-automation-action {
        display: block;
        margin-bottom: 16px;
      }
      :host([disabled]) ha-automation-action {
        opacity: var(--light-disabled-opacity);
        pointer-events: none;
      }
    `}}]}}),g);const zu=async e=>((e,t,i,a)=>{const[n,o,s]=e.split(".",3);return Number(n)>t||Number(n)===t&&(void 0===a?Number(o)>=i:Number(o)>i)||void 0!==a&&Number(n)===t&&Number(o)===i&&Number(s)>=a})(e.config.version,2021,2,4)?e.callWS({type:"supervisor/api",endpoint:"/addons",method:"get"}):(await e.callApi("GET","hassio/addons")).data,Su=e=>x`<mwc-list-item twoline graphic="icon">
  <span>${e.name}</span>
  <span slot="secondary">${e.slug}</span>
  ${e.icon?x`<img slot="graphic" .src="/api/hassio/addons/${e.slug}/icon" />`:""}
</mwc-list-item>`;f([A("ha-addon-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:()=>""},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[Qi()],key:"_addons",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!1},{kind:"field",decorators:[y("ha-combo-box")],key:"_comboBox",value:void 0},{kind:"method",key:"open",value:function(){var e;null===(e=this._comboBox)||void 0===e||e.open()}},{kind:"method",key:"focus",value:function(){var e;null===(e=this._comboBox)||void 0===e||e.focus()}},{kind:"method",key:"firstUpdated",value:function(){this._getAddons()}},{kind:"method",key:"render",value:function(){return this._addons?x`
      <ha-combo-box
        .hass=${this.hass}
        .label=${void 0===this.label&&this.hass?this.hass.localize("ui.components.addon-picker.addon"):this.label}
        .value=${this._value}
        .required=${this.required}
        .disabled=${this.disabled}
        .helper=${this.helper}
        .renderer=${Su}
        .items=${this._addons}
        item-value-path="slug"
        item-id-path="slug"
        item-label-path="name"
        @value-changed=${this._addonChanged}
      ></ha-combo-box>
    `:x``}},{kind:"method",key:"_getAddons",value:async function(){try{if(zn(this.hass,"hassio")){const e=await zu(this.hass);this._addons=e.addons.filter((e=>e.version)).sort(((e,t)=>_s(e.name,t.name)))}else wn(this,{title:this.hass.localize("ui.components.addon-picker.error.no_supervisor.title"),text:this.hass.localize("ui.components.addon-picker.error.no_supervisor.description")})}catch(e){wn(this,{title:this.hass.localize("ui.components.addon-picker.error.fetch_addons.title"),text:this.hass.localize("ui.components.addon-picker.error.fetch_addons.description")})}}},{kind:"get",key:"_value",value:function(){return this.value||""}},{kind:"method",key:"_addonChanged",value:function(e){e.stopPropagation();const t=e.detail.value;t!==this._value&&this._setValue(t)}},{kind:"method",key:"_setValue",value:function(e){this.value=e,setTimeout((()=>{o(this,"value-changed",{value:e}),o(this,"change")}),0)}}]}}),g),f([A("ha-selector-addon")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return x`<ha-addon-picker
      .hass=${this.hass}
      .value=${this.value}
      .label=${this.label}
      .helper=${this.helper}
      .disabled=${this.disabled}
      .required=${this.required}
      allow-custom-entity
    ></ha-addon-picker>`}},{kind:"field",static:!0,key:"styles",value:()=>r`
    ha-addon-picker {
      width: 100%;
    }
  `}]}}),g);const Tu=async(e,t,i,a,n,...o)=>{const s=n,r=s[e],l=r=>a&&a(n,r.result)!==r.cacheKey?(s[e]=void 0,Tu(e,t,i,a,n,...o)):r.result;if(r)return r instanceof Promise?r.then(l):l(r);const d=i(n,...o);return s[e]=d,d.then((i=>{s[e]={result:i,cacheKey:null==a?void 0:a(n,i)},setTimeout((()=>{s[e]=void 0}),t)}),(()=>{s[e]=void 0})),d},Lu=(e,t)=>e.callWS({type:"entity/source",entity_id:t}),Ou=(e,t)=>t?Lu(e,t):Tu("_entitySources",3e4,Lu,(e=>Object.keys(e.states).length),e),Mu=(e,t,i)=>{const{manufacturer:a,model:n,integration:o}=e;if(a&&t.manufacturer!==a)return!1;if(n&&t.model!==n)return!1;var s;if(o&&i&&(null==i||null===(s=i[t.id])||void 0===s||!s.includes(o)))return!1;return!0},Pu=(e,t,i)=>{var a;const{domain:n,device_class:o,integration:s}=e;if(n){const e=Hr(t);if(Array.isArray(n)?!n.includes(e):e!==n)return!1}return(!o||t.attributes.device_class===o)&&(!s||(null==i||null===(a=i[t.entity_id])||void 0===a?void 0:a.domain)===s)},Fu=e=>x`<mwc-list-item
  class=${ba({"add-new":"add_new"===e.area_id})}
>
  ${e.name}
</mwc-list-item>`;f([A("ha-area-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_()],key:"placeholder",value:void 0},{kind:"field",decorators:[_({type:Boolean,attribute:"no-add"})],key:"noAdd",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-domains"})],key:"includeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"exclude-domains"})],key:"excludeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-device-classes"})],key:"includeDeviceClasses",value:void 0},{kind:"field",decorators:[_()],key:"deviceFilter",value:void 0},{kind:"field",decorators:[_()],key:"entityFilter",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:void 0},{kind:"field",decorators:[Qi()],key:"_areas",value:void 0},{kind:"field",decorators:[Qi()],key:"_devices",value:void 0},{kind:"field",decorators:[Qi()],key:"_entities",value:void 0},{kind:"field",decorators:[Qi()],key:"_opened",value:void 0},{kind:"field",decorators:[y("ha-combo-box",!0)],key:"comboBox",value:void 0},{kind:"field",key:"_filter",value:void 0},{kind:"field",key:"_init",value:()=>!1},{kind:"method",key:"hassSubscribe",value:function(){return[Ic(this.hass.connection,(e=>{this._areas=e})),Tc(this.hass.connection,(e=>{this._devices=e})),Pc(this.hass.connection,(e=>{this._entities=e}))]}},{kind:"method",key:"open",value:function(){this.updateComplete.then((()=>{var e;null===(e=this.comboBox)||void 0===e||e.open()}))}},{kind:"method",key:"focus",value:function(){this.updateComplete.then((()=>{var e;null===(e=this.comboBox)||void 0===e||e.focus()}))}},{kind:"field",key:"_getAreas",value(){return n(((e,t,i,a,n,o,s,r,l)=>{if(!e.length)return[{area_id:"no_areas",name:this.hass.localize("ui.components.area-picker.no_areas"),picture:null}];const d={};let c,u;if(a||n||o){for(const e of i)e.device_id&&(e.device_id in d||(d[e.device_id]=[]),d[e.device_id].push(e));c=t,u=i.filter((e=>e.area_id))}else s&&(c=t),r&&(u=i.filter((e=>e.area_id)));a&&(c=c.filter((e=>{const t=d[e.id];return!(!t||!t.length)&&d[e.id].some((e=>a.includes(gs(e.entity_id))))})),u=u.filter((e=>a.includes(gs(e.entity_id))))),n&&(c=c.filter((e=>{const t=d[e.id];return!t||!t.length||i.every((e=>!n.includes(gs(e.entity_id))))})),u=u.filter((e=>!n.includes(gs(e.entity_id))))),o&&(c=c.filter((e=>{const t=d[e.id];return!(!t||!t.length)&&d[e.id].some((e=>{const t=this.hass.states[e.entity_id];return!!t&&(t.attributes.device_class&&o.includes(t.attributes.device_class))}))})),u=u.filter((e=>{const t=this.hass.states[e.entity_id];return t.attributes.device_class&&o.includes(t.attributes.device_class)}))),s&&(c=c.filter((e=>s(e)))),r&&(u=u.filter((e=>r(e))));let h,p=e;var v;(c&&(h=c.filter((e=>e.area_id)).map((e=>e.area_id))),u)&&(h=(null!==(v=h)&&void 0!==v?v:[]).concat(u.filter((e=>e.area_id)).map((e=>e.area_id))));return h&&(p=e.filter((e=>h.includes(e.area_id)))),p.length||(p=[{area_id:"no_areas",name:this.hass.localize("ui.components.area-picker.no_match"),picture:null}]),l?p:[...p,{area_id:"add_new",name:this.hass.localize("ui.components.area-picker.add_new"),picture:null}]}))}},{kind:"method",key:"updated",value:function(e){(!this._init&&this._devices&&this._areas&&this._entities||e.has("_opened")&&this._opened)&&(this._init=!0,this.comboBox.items=this._getAreas(this._areas,this._devices,this._entities,this.includeDomains,this.excludeDomains,this.includeDeviceClasses,this.deviceFilter,this.entityFilter,this.noAdd))}},{kind:"method",key:"render",value:function(){var e;return this._devices&&this._areas&&this._entities?x`
      <ha-combo-box
        .hass=${this.hass}
        .helper=${this.helper}
        item-value-path="area_id"
        item-id-path="area_id"
        item-label-path="name"
        .value=${this.value}
        .disabled=${this.disabled}
        .required=${this.required}
        .label=${void 0===this.label&&this.hass?this.hass.localize("ui.components.area-picker.area"):this.label}
        .placeholder=${this.placeholder?null===(e=this._area(this.placeholder))||void 0===e?void 0:e.name:void 0}
        .renderer=${Fu}
        @filter-changed=${this._filterChanged}
        @opened-changed=${this._openedChanged}
        @value-changed=${this._areaChanged}
      >
      </ha-combo-box>
    `:x``}},{kind:"field",key:"_area",value(){return n((e=>{var t;return null===(t=this._areas)||void 0===t?void 0:t.find((t=>t.area_id===e))}))}},{kind:"method",key:"_filterChanged",value:function(e){var t,i;(this._filter=e.detail.value,this._filter)?this.noAdd||0!==(null===(t=this.comboBox._comboBox.filteredItems)||void 0===t?void 0:t.length)?this.comboBox.filteredItems=null===(i=this.comboBox.items)||void 0===i?void 0:i.filter((e=>e.name.toLowerCase().includes(this._filter.toLowerCase()))):this.comboBox.filteredItems=[{area_id:"add_new_suggestion",name:this.hass.localize("ui.components.area-picker.add_new_sugestion",{name:this._filter}),picture:null}]:this.comboBox.filteredItems=this.comboBox.items}},{kind:"get",key:"_value",value:function(){return this.value||""}},{kind:"method",key:"_openedChanged",value:function(e){this._opened=e.detail.value}},{kind:"method",key:"_areaChanged",value:function(e){e.stopPropagation();let t=e.detail.value;"no_areas"===t&&(t=""),["add_new_suggestion","add_new"].includes(t)?(e.target.value=this._value,Cn(this,{title:this.hass.localize("ui.components.area-picker.add_dialog.title"),text:this.hass.localize("ui.components.area-picker.add_dialog.text"),confirmText:this.hass.localize("ui.components.area-picker.add_dialog.add"),inputLabel:this.hass.localize("ui.components.area-picker.add_dialog.name"),defaultValue:"add_new_suggestion"===t?this._filter:void 0,confirm:async e=>{var t,i;if(e)try{const a=await(t=this.hass,i={name:e},t.callWS({type:"config/area_registry/create",...i}));this._areas=[...this._areas,a],this.comboBox.filteredItems=this._getAreas(this._areas,this._devices,this._entities,this.includeDomains,this.excludeDomains,this.includeDeviceClasses,this.deviceFilter,this.entityFilter,this.noAdd),await this.updateComplete,await this.comboBox.updateComplete,this._setValue(a.area_id)}catch(e){wn(this,{title:this.hass.localize("ui.components.area-picker.add_dialog.failed_create_area"),text:e.message})}}})):t!==this._value&&this._setValue(t)}},{kind:"method",key:"_setValue",value:function(e){this.value=e,setTimeout((()=>{o(this,"value-changed",{value:e}),o(this,"change")}),0)}}]}}),Fc(g)),f([A("ha-areas-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_()],key:"placeholder",value:void 0},{kind:"field",decorators:[_({type:Boolean,attribute:"no-add"})],key:"noAdd",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-domains"})],key:"includeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"exclude-domains"})],key:"excludeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-device-classes"})],key:"includeDeviceClasses",value:void 0},{kind:"field",decorators:[_()],key:"deviceFilter",value:void 0},{kind:"field",decorators:[_()],key:"entityFilter",value:void 0},{kind:"field",decorators:[_({attribute:"picked-area-label"})],key:"pickedAreaLabel",value:void 0},{kind:"field",decorators:[_({attribute:"pick-area-label"})],key:"pickAreaLabel",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:void 0},{kind:"method",key:"render",value:function(){if(!this.hass)return x``;const e=this._currentAreas;return x`
      ${e.map((e=>x`
          <div>
            <ha-area-picker
              .curValue=${e}
              .noAdd=${this.noAdd}
              .hass=${this.hass}
              .value=${e}
              .label=${this.pickedAreaLabel}
              .includeDomains=${this.includeDomains}
              .excludeDomains=${this.excludeDomains}
              .includeDeviceClasses=${this.includeDeviceClasses}
              .deviceFilter=${this.deviceFilter}
              .entityFilter=${this.entityFilter}
              .disabled=${this.disabled}
              @value-changed=${this._areaChanged}
            ></ha-area-picker>
          </div>
        `))}
      <div>
        <ha-area-picker
          .noAdd=${this.noAdd}
          .hass=${this.hass}
          .label=${this.pickAreaLabel}
          .helper=${this.helper}
          .includeDomains=${this.includeDomains}
          .excludeDomains=${this.excludeDomains}
          .includeDeviceClasses=${this.includeDeviceClasses}
          .deviceFilter=${this.deviceFilter}
          .entityFilter=${this.entityFilter}
          .disabled=${this.disabled}
          .placeholder=${this.placeholder}
          .required=${this.required&&!e.length}
          @value-changed=${this._addArea}
        ></ha-area-picker>
      </div>
    `}},{kind:"get",key:"_currentAreas",value:function(){return this.value||[]}},{kind:"method",key:"_updateAreas",value:async function(e){this.value=e,o(this,"value-changed",{value:e})}},{kind:"method",key:"_areaChanged",value:function(e){e.stopPropagation();const t=e.currentTarget.curValue,i=e.detail.value;if(i===t)return;const a=this._currentAreas;i&&!a.includes(i)?this._updateAreas(a.map((e=>e===t?i:e))):this._updateAreas(a.filter((e=>e!==t)))}},{kind:"method",key:"_addArea",value:function(e){e.stopPropagation();const t=e.detail.value;if(!t)return;e.currentTarget.value="";const i=this._currentAreas;i.includes(t)||this._updateAreas([...i,t])}},{kind:"field",static:!0,key:"styles",value:()=>r`
    div {
      margin-top: 8px;
    }
  `}]}}),Fc(g)),f([A("ha-selector-area")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"field",decorators:[Qi()],key:"_entitySources",value:void 0},{kind:"field",decorators:[Qi()],key:"_entities",value:void 0},{kind:"field",key:"_deviceIntegrationLookup",value:()=>n(Lc)},{kind:"method",key:"hassSubscribe",value:function(){return[Pc(this.hass.connection,(e=>{this._entities=e.filter((e=>null!==e.device_id))}))]}},{kind:"method",key:"updated",value:function(e){var t,i;e.has("selector")&&(null!==(t=this.selector.area.device)&&void 0!==t&&t.integration||null!==(i=this.selector.area.entity)&&void 0!==i&&i.integration)&&!this._entitySources&&Ou(this.hass).then((e=>{this._entitySources=e}))}},{kind:"method",key:"render",value:function(){var e,t;return(null!==(e=this.selector.area.device)&&void 0!==e&&e.integration||null!==(t=this.selector.area.entity)&&void 0!==t&&t.integration)&&!this._entitySources?x``:this.selector.area.multiple?x`
      <ha-areas-picker
        .hass=${this.hass}
        .value=${this.value}
        .helper=${this.helper}
        .pickAreaLabel=${this.label}
        no-add
        .deviceFilter=${this._filterDevices}
        .entityFilter=${this._filterEntities}
        .disabled=${this.disabled}
        .required=${this.required}
      ></ha-areas-picker>
    `:x`
        <ha-area-picker
          .hass=${this.hass}
          .value=${this.value}
          .label=${this.label}
          .helper=${this.helper}
          no-add
          .deviceFilter=${this._filterDevices}
          .entityFilter=${this._filterEntities}
          .disabled=${this.disabled}
          .required=${this.required}
        ></ha-area-picker>
      `}},{kind:"field",key:"_filterEntities",value(){return e=>!this.selector.area.entity||Pu(this.selector.area.entity,e,this._entitySources)}},{kind:"field",key:"_filterDevices",value(){return e=>{if(!this.selector.area.device)return!0;const t=this._entitySources&&this._entities?this._deviceIntegrationLookup(this._entitySources,this._entities):void 0;return Mu(this.selector.area.device,e,t)}}}]}}),Fc(g)),f([A("ha-entity-attribute-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"entityId",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"hide-attributes"})],key:"hideAttributes",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"autofocus",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!1},{kind:"field",decorators:[_({type:Boolean,attribute:"allow-custom-value"})],key:"allowCustomValue",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"_opened",value:()=>!1},{kind:"field",decorators:[y("ha-combo-box",!0)],key:"_comboBox",value:void 0},{kind:"method",key:"shouldUpdate",value:function(e){return!(!e.has("_opened")&&this._opened)}},{kind:"method",key:"updated",value:function(e){if(e.has("_opened")&&this._opened){const e=this.entityId?this.hass.states[this.entityId]:void 0;this._comboBox.items=e?Object.keys(e.attributes).filter((e=>{var t;return!(null!==(t=this.hideAttributes)&&void 0!==t&&t.includes(e))})).map((e=>({value:e,label:hs(e)}))):[]}}},{kind:"method",key:"render",value:function(){var e;return this.hass?x`
      <ha-combo-box
        .hass=${this.hass}
        .value=${this.value?hs(this.value):""}
        .autofocus=${this.autofocus}
        .label=${null!==(e=this.label)&&void 0!==e?e:this.hass.localize("ui.components.entity.entity-attribute-picker.attribute")}
        .disabled=${this.disabled||!this.entityId}
        .required=${this.required}
        .helper=${this.helper}
        .allowCustomValue=${this.allowCustomValue}
        item-value-path="value"
        item-label-path="label"
        @opened-changed=${this._openedChanged}
        @value-changed=${this._valueChanged}
      >
      </ha-combo-box>
    `:x``}},{kind:"method",key:"_openedChanged",value:function(e){this._opened=e.detail.value}},{kind:"method",key:"_valueChanged",value:function(e){this.value=e.detail.value}}]}}),g),f([A("ha-selector-attribute")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"field",decorators:[_({attribute:!1})],key:"context",value:void 0},{kind:"method",key:"render",value:function(){var e;return x`
      <ha-entity-attribute-picker
        .hass=${this.hass}
        .entityId=${this.selector.attribute.entity_id||(null===(e=this.context)||void 0===e?void 0:e.filter_entity)}
        .hideAttributes=${this.selector.attribute.hide_attributes}
        .value=${this.value}
        .label=${this.label}
        .helper=${this.helper}
        .disabled=${this.disabled}
        .required=${this.required}
        allow-custom-value
      ></ha-entity-attribute-picker>
    `}},{kind:"method",key:"updated",value:function(e){if(k(b(i.prototype),"updated",this).call(this,e),!this.value||this.selector.attribute.entity_id||!e.has("context"))return;const t=e.get("context");if(!this.context||(null==t?void 0:t.filter_entity)===this.context.filter_entity)return;let a=!1;if(this.context.filter_entity){const e=this.hass.states[this.context.filter_entity];e&&this.value in e.attributes||(a=!0)}else a=void 0!==this.value;a&&o(this,"value-changed",{value:void 0})}}]}}),Fc(g)),f([A("ha-selector-boolean")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"method",key:"render",value:function(){return x`
      <ha-formfield alignEnd spaceBetween .label=${this.label}>
        <ha-switch
          .checked=${this.value}
          @change=${this._handleChange}
          .disabled=${this.disabled}
        ></ha-switch>
      </ha-formfield>
      ${this.helper?x`<ha-input-helper-text>${this.helper}</ha-input-helper-text>`:""}
    `}},{kind:"method",key:"_handleChange",value:function(e){const t=e.target.checked;this.value!==t&&o(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-formfield {
        display: flex;
        height: 56px;
        align-items: center;
        --mdc-typography-body2-font-size: 1em;
      }
    `}}]}}),g),f([A("ha-selector-color_rgb")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return x`
      <ha-textfield
        type="color"
        helperPersistent
        .value=${this.value?nn(this.value):""}
        .label=${this.label||""}
        .required=${this.required}
        .helper=${this.helper}
        .disalbled=${this.disabled}
        @change=${this._valueChanged}
      ></ha-textfield>
    `}},{kind:"method",key:"_valueChanged",value:function(e){const t=e.target.value;o(this,"value-changed",{value:on(t)})}},{kind:"field",static:!0,key:"styles",value:()=>r`
    :host {
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
    ha-textfield {
      --text-field-padding: 8px;
      min-width: 75px;
      flex-grow: 1;
      margin: 0 4px;
    }
  `}]}}),g),f([A("ha-config-entry-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"integration",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:()=>""},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[Qi()],key:"_configEntries",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!1},{kind:"field",decorators:[y("ha-combo-box")],key:"_comboBox",value:void 0},{kind:"method",key:"open",value:function(){var e;null===(e=this._comboBox)||void 0===e||e.open()}},{kind:"method",key:"focus",value:function(){var e;null===(e=this._comboBox)||void 0===e||e.focus()}},{kind:"method",key:"firstUpdated",value:function(){this._getConfigEntries()}},{kind:"field",key:"_rowRenderer",value(){return e=>{var t;return x`<mwc-list-item twoline graphic="icon">
    <span
      >${e.title||this.hass.localize("ui.panel.config.integrations.config_entry.unnamed_entry")}</span
    >
    <span slot="secondary">${e.localized_domain_name}</span>
    <img
      slot="graphic"
      src=${An({domain:e.domain,type:"icon",darkOptimized:null===(t=this.hass.themes)||void 0===t?void 0:t.darkMode})}
      referrerpolicy="no-referrer"
      @error=${this._onImageError}
      @load=${this._onImageLoad}
    />
  </mwc-list-item>`}}},{kind:"method",key:"render",value:function(){return this._configEntries?x`
      <ha-combo-box
        .hass=${this.hass}
        .label=${void 0===this.label&&this.hass?this.hass.localize("ui.components.config-entry-picker.config_entry"):this.label}
        .value=${this._value}
        .required=${this.required}
        .disabled=${this.disabled}
        .helper=${this.helper}
        .renderer=${this._rowRenderer}
        .items=${this._configEntries}
        item-value-path="entry_id"
        item-id-path="entry_id"
        item-label-path="title"
        @value-changed=${this._valueChanged}
      ></ha-combo-box>
    `:x``}},{kind:"method",key:"_onImageLoad",value:function(e){e.target.style.visibility="initial"}},{kind:"method",key:"_onImageError",value:function(e){e.target.style.visibility="hidden"}},{kind:"method",key:"_getConfigEntries",value:async function(){Sn(this.hass,{type:"integration",domain:this.integration}).then((e=>{this._configEntries=e.map((e=>({...e,localized_domain_name:Zc(this.hass.localize,e.domain)}))).sort(((e,t)=>ys(e.localized_domain_name+e.title,t.localized_domain_name+t.title)))}))}},{kind:"get",key:"_value",value:function(){return this.value||""}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value;t!==this._value&&this._setValue(t)}},{kind:"method",key:"_setValue",value:function(e){this.value=e,setTimeout((()=>{o(this,"value-changed",{value:e}),o(this,"change")}),0)}}]}}),g),f([A("ha-selector-config_entry")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return x`<ha-config-entry-picker
      .hass=${this.hass}
      .value=${this.value}
      .label=${this.label}
      .helper=${this.helper}
      .disabled=${this.disabled}
      .required=${this.required}
      .integration=${this.selector.config_entry.integration}
      allow-custom-entity
    ></ha-config-entry-picker>`}},{kind:"field",static:!0,key:"styles",value:()=>r`
    ha-config-entry-picker {
      width: 100%;
    }
  `}]}}),g);const Du=()=>import("./c.14dc9dca.js");f([A("ha-date-input")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"locale",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!1},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"method",key:"render",value:function(){return x`<ha-textfield
      .label=${this.label}
      .helper=${this.helper}
      .disabled=${this.disabled}
      iconTrailing
      helperPersistent
      @click=${this._openDialog}
      .value=${this.value?(e=new Date(this.value),t=this.locale,os(t).format(e)):""}
      .required=${this.required}
    >
      <ha-svg-icon slot="trailingIcon" .path=${T}></ha-svg-icon>
    </ha-textfield>`;var e,t}},{kind:"method",key:"_openDialog",value:function(){var e,t;this.disabled||(e=this,t={min:"1970-01-01",value:this.value,onChange:e=>this._valueChanged(e),locale:this.locale.language},o(e,"show-dialog",{dialogTag:"ha-dialog-date-picker",dialogImport:Du,dialogParams:t}))}},{kind:"method",key:"_valueChanged",value:function(e){this.value!==e&&(this.value=e,o(this,"change"),o(this,"value-changed",{value:e}))}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-svg-icon {
        color: var(--secondary-text-color);
      }
    `}}]}}),g),f([A("ha-selector-date")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return x`
      <ha-date-input
        .label=${this.label}
        .locale=${this.hass.locale}
        .disabled=${this.disabled}
        .value=${this.value}
        .required=${this.required}
        .helper=${this.helper}
      >
      </ha-date-input>
    `}}]}}),g),f([A("ha-time-input")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"locale",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!1},{kind:"field",decorators:[_({type:Boolean,attribute:"enable-second"})],key:"enableSecond",value:()=>!1},{kind:"method",key:"render",value:function(){var e;const t=ss(this.locale),i=(null===(e=this.value)||void 0===e?void 0:e.split(":"))||[];let a=i[0];const n=Number(i[0]);return n&&t&&n>12&&n<24&&(a=String(n-12).padStart(2,"0")),t&&0===n&&(a="12"),x`
      <ha-base-time-input
        .label=${this.label}
        .hours=${Number(a)}
        .minutes=${Number(i[1])}
        .seconds=${Number(i[2])}
        .format=${t?12:24}
        .amPm=${t&&n>=12?"PM":"AM"}
        .disabled=${this.disabled}
        @value-changed=${this._timeChanged}
        .enableSecond=${this.enableSecond}
        .required=${this.required}
        .helper=${this.helper}
      ></ha-base-time-input>
    `}},{kind:"method",key:"_timeChanged",value:function(e){e.stopPropagation();const t=e.detail.value,i=ss(this.locale);let a=t.hours||0;t&&i&&("PM"===t.amPm&&a<12&&(a+=12),"AM"===t.amPm&&12===a&&(a=0));const n=`${a.toString().padStart(2,"0")}:${t.minutes?t.minutes.toString().padStart(2,"0"):"00"}:${t.seconds?t.seconds.toString().padStart(2,"0"):"00"}`;n!==this.value&&(this.value=n,o(this,"change"),o(this,"value-changed",{value:n}))}}]}}),g),f([A("ha-selector-datetime")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"field",decorators:[y("ha-date-input")],key:"_dateInput",value:void 0},{kind:"field",decorators:[y("ha-time-input")],key:"_timeInput",value:void 0},{kind:"method",key:"render",value:function(){var e;const t=null===(e=this.value)||void 0===e?void 0:e.split(" ");return x`
      <div class="input">
        <ha-date-input
          .label=${this.label}
          .locale=${this.hass.locale}
          .disabled=${this.disabled}
          .required=${this.required}
          .value=${null==t?void 0:t[0]}
          @value-changed=${this._valueChanged}
        >
        </ha-date-input>
        <ha-time-input
          enable-second
          .value=${(null==t?void 0:t[1])||"0:00:00"}
          .locale=${this.hass.locale}
          .disabled=${this.disabled}
          .required=${this.required}
          @value-changed=${this._valueChanged}
        ></ha-time-input>
      </div>
      ${this.helper?x`<ha-input-helper-text>${this.helper}</ha-input-helper-text>`:""}
    `}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation(),o(this,"value-changed",{value:`${this._dateInput.value} ${this._timeInput.value}`})}},{kind:"field",static:!0,key:"styles",value:()=>r`
    .input {
      display: flex;
      align-items: center;
      flex-direction: row;
    }

    ha-date-input {
      min-width: 150px;
      margin-right: 4px;
    }
  `}]}}),g),f([A("ha-devices-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-domains"})],key:"includeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"exclude-domains"})],key:"excludeDomains",value:void 0},{kind:"field",decorators:[_({attribute:"picked-device-label"}),_({type:Array,attribute:"include-device-classes"})],key:"includeDeviceClasses",value:void 0},{kind:"field",key:"pickedDeviceLabel",value:void 0},{kind:"field",decorators:[_({attribute:"pick-device-label"})],key:"pickDeviceLabel",value:void 0},{kind:"field",decorators:[_()],key:"deviceFilter",value:void 0},{kind:"method",key:"render",value:function(){if(!this.hass)return x``;const e=this._currentDevices;return x`
      ${e.map((e=>x`
          <div>
            <ha-device-picker
              allow-custom-entity
              .curValue=${e}
              .hass=${this.hass}
              .deviceFilter=${this.deviceFilter}
              .includeDomains=${this.includeDomains}
              .excludeDomains=${this.excludeDomains}
              .includeDeviceClasses=${this.includeDeviceClasses}
              .value=${e}
              .label=${this.pickedDeviceLabel}
              .disabled=${this.disabled}
              @value-changed=${this._deviceChanged}
            ></ha-device-picker>
          </div>
        `))}
      <div>
        <ha-device-picker
          allow-custom-entity
          .hass=${this.hass}
          .helper=${this.helper}
          .deviceFilter=${this.deviceFilter}
          .includeDomains=${this.includeDomains}
          .excludeDomains=${this.excludeDomains}
          .includeDeviceClasses=${this.includeDeviceClasses}
          .label=${this.pickDeviceLabel}
          .disabled=${this.disabled}
          .required=${this.required&&!e.length}
          @value-changed=${this._addDevice}
        ></ha-device-picker>
      </div>
    `}},{kind:"get",key:"_currentDevices",value:function(){return this.value||[]}},{kind:"method",key:"_updateDevices",value:async function(e){o(this,"value-changed",{value:e}),this.value=e}},{kind:"method",key:"_deviceChanged",value:function(e){e.stopPropagation();const t=e.currentTarget.curValue,i=e.detail.value;i!==t&&""===i&&(""===i?this._updateDevices(this._currentDevices.filter((e=>e!==t))):this._updateDevices(this._currentDevices.map((e=>e===t?i:e))))}},{kind:"method",key:"_addDevice",value:async function(e){e.stopPropagation();const t=e.detail.value;if(e.currentTarget.value="",!t)return;const i=this._currentDevices;i.includes(t)||this._updateDevices([...i,t])}},{kind:"field",static:!0,key:"styles",value:()=>r`
    div {
      margin-top: 8px;
    }
  `}]}}),g),f([A("ha-selector-device")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[Qi()],key:"_entitySources",value:void 0},{kind:"field",decorators:[Qi()],key:"_entities",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"field",key:"_deviceIntegrationLookup",value:()=>n(Lc)},{kind:"method",key:"hassSubscribe",value:function(){return[Pc(this.hass.connection,(e=>{this._entities=e.filter((e=>null!==e.device_id))}))]}},{kind:"method",key:"updated",value:function(e){k(b(i.prototype),"updated",this).call(this,e),e.has("selector")&&this.selector.device.integration&&!this._entitySources&&Ou(this.hass).then((e=>{this._entitySources=e}))}},{kind:"method",key:"render",value:function(){var e,t,i,a;return this.selector.device.integration&&!this._entitySources?x``:this.selector.device.multiple?x`
      ${this.label?x`<label>${this.label}</label>`:""}
      <ha-devices-picker
        .hass=${this.hass}
        .value=${this.value}
        .helper=${this.helper}
        .deviceFilter=${this._filterDevices}
        .includeDeviceClasses=${null!==(e=this.selector.device.entity)&&void 0!==e&&e.device_class?[this.selector.device.entity.device_class]:void 0}
        .includeDomains=${null!==(t=this.selector.device.entity)&&void 0!==t&&t.domain?[this.selector.device.entity.domain]:void 0}
        .disabled=${this.disabled}
        .required=${this.required}
      ></ha-devices-picker>
    `:x`
        <ha-device-picker
          .hass=${this.hass}
          .value=${this.value}
          .label=${this.label}
          .helper=${this.helper}
          .deviceFilter=${this._filterDevices}
          .includeDeviceClasses=${null!==(i=this.selector.device.entity)&&void 0!==i&&i.device_class?[this.selector.device.entity.device_class]:void 0}
          .includeDomains=${null!==(a=this.selector.device.entity)&&void 0!==a&&a.domain?[this.selector.device.entity.domain]:void 0}
          .disabled=${this.disabled}
          .required=${this.required}
          allow-custom-entity
        ></ha-device-picker>
      `}},{kind:"field",key:"_filterDevices",value(){return e=>{const t=this._entitySources&&this._entities?this._deviceIntegrationLookup(this._entitySources,this._entities):void 0;return Mu(this.selector.device,e,t)}}}]}}),Fc(g)),f([A("ha-selector-duration")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"selector",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return x`
      <ha-duration-input
        .label=${this.label}
        .helper=${this.helper}
        .data=${this.value}
        .disabled=${this.disabled}
        .required=${this.required}
        ?enableDay=${this.selector.duration.enable_day}
      ></ha-duration-input>
    `}}]}}),g);const Bu=/^(\w+)\.(\w+)$/;f([A("ha-entities-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({type:Array})],key:"value",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-domains"})],key:"includeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"exclude-domains"})],key:"excludeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-device-classes"})],key:"includeDeviceClasses",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-unit-of-measurement"})],key:"includeUnitOfMeasurement",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-entities"})],key:"includeEntities",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"exclude-entities"})],key:"excludeEntities",value:void 0},{kind:"field",decorators:[_({attribute:"picked-entity-label"})],key:"pickedEntityLabel",value:void 0},{kind:"field",decorators:[_({attribute:"pick-entity-label"})],key:"pickEntityLabel",value:void 0},{kind:"field",decorators:[_()],key:"entityFilter",value:void 0},{kind:"method",key:"render",value:function(){if(!this.hass)return x``;const e=this._currentEntities;return x`
      ${e.map((e=>x`
          <div>
            <ha-entity-picker
              allow-custom-entity
              .curValue=${e}
              .hass=${this.hass}
              .includeDomains=${this.includeDomains}
              .excludeDomains=${this.excludeDomains}
              .includeEntities=${this.includeEntities}
              .excludeEntities=${this.excludeEntities}
              .includeDeviceClasses=${this.includeDeviceClasses}
              .includeUnitOfMeasurement=${this.includeUnitOfMeasurement}
              .entityFilter=${this._entityFilter}
              .value=${e}
              .label=${this.pickedEntityLabel}
              .disabled=${this.disabled}
              @value-changed=${this._entityChanged}
            ></ha-entity-picker>
          </div>
        `))}
      <div>
        <ha-entity-picker
          allow-custom-entity
          .hass=${this.hass}
          .includeDomains=${this.includeDomains}
          .excludeDomains=${this.excludeDomains}
          .includeEntities=${this.includeEntities}
          .excludeEntities=${this.excludeEntities}
          .includeDeviceClasses=${this.includeDeviceClasses}
          .includeUnitOfMeasurement=${this.includeUnitOfMeasurement}
          .entityFilter=${this._entityFilter}
          .label=${this.pickEntityLabel}
          .helper=${this.helper}
          .disabled=${this.disabled}
          .required=${this.required&&!e.length}
          @value-changed=${this._addEntity}
        ></ha-entity-picker>
      </div>
    `}},{kind:"field",key:"_entityFilter",value(){return e=>(!this.value||!this.value.includes(e.entity_id))&&(!this.entityFilter||this.entityFilter(e))}},{kind:"get",key:"_currentEntities",value:function(){return this.value||[]}},{kind:"method",key:"_updateEntities",value:async function(e){this.value=e,o(this,"value-changed",{value:e})}},{kind:"method",key:"_entityChanged",value:function(e){e.stopPropagation();const t=e.currentTarget.curValue,i=e.detail.value;if(i===t||void 0!==i&&(a=i,!Bu.test(a)))return;var a;const n=this._currentEntities;i&&!n.includes(i)?this._updateEntities(n.map((e=>e===t?i:e))):this._updateEntities(n.filter((e=>e!==t)))}},{kind:"method",key:"_addEntity",value:async function(e){e.stopPropagation();const t=e.detail.value;if(!t)return;if(e.currentTarget.value="",!t)return;const i=this._currentEntities;i.includes(t)||this._updateEntities([...i,t])}},{kind:"field",static:!0,key:"styles",value:()=>r`
    div {
      margin-top: 8px;
    }
  `}]}}),g),f([A("ha-selector-entity")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[Qi()],key:"_entitySources",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return this.selector.entity.multiple?x`
      ${this.label?x`<label>${this.label}</label>`:""}
      <ha-entities-picker
        .hass=${this.hass}
        .value=${this.value}
        .helper=${this.helper}
        .includeEntities=${this.selector.entity.include_entities}
        .excludeEntities=${this.selector.entity.exclude_entities}
        .entityFilter=${this._filterEntities}
        .disabled=${this.disabled}
        .required=${this.required}
      ></ha-entities-picker>
    `:x`<ha-entity-picker
        .hass=${this.hass}
        .value=${this.value}
        .label=${this.label}
        .helper=${this.helper}
        .includeEntities=${this.selector.entity.include_entities}
        .excludeEntities=${this.selector.entity.exclude_entities}
        .entityFilter=${this._filterEntities}
        .disabled=${this.disabled}
        .required=${this.required}
        allow-custom-entity
      ></ha-entity-picker>`}},{kind:"method",key:"updated",value:function(e){k(b(i.prototype),"updated",this).call(this,e),e.has("selector")&&this.selector.entity.integration&&!this._entitySources&&Ou(this.hass).then((e=>{this._entitySources=e}))}},{kind:"field",key:"_filterEntities",value(){return e=>Pu(this.selector.entity,e,this._entitySources)}}]}}),g);f([A("ha-file-upload")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"accept",value:void 0},{kind:"field",decorators:[_()],key:"icon",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:()=>null},{kind:"field",decorators:[_({type:Boolean})],key:"uploading",value:()=>!1},{kind:"field",decorators:[_({type:Boolean,attribute:"auto-open-file-dialog"})],key:"autoOpenFileDialog",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_drag",value:()=>!1},{kind:"field",decorators:[y("#input")],key:"_input",value:void 0},{kind:"method",key:"firstUpdated",value:function(e){k(b(i.prototype),"firstUpdated",this).call(this,e),this.autoOpenFileDialog&&this._openFilePicker()}},{kind:"method",key:"render",value:function(){var e;return x`
      ${this.uploading?x`<ha-circular-progress
            alt="Uploading"
            size="large"
            active
          ></ha-circular-progress>`:x`
            <label
              for="input"
              class="mdc-text-field mdc-text-field--filled ${ba({"mdc-text-field--focused":this._drag,"mdc-text-field--with-leading-icon":Boolean(this.icon),"mdc-text-field--with-trailing-icon":Boolean(this.value)})}"
              @drop=${this._handleDrop}
              @dragenter=${this._handleDragStart}
              @dragover=${this._handleDragStart}
              @dragleave=${this._handleDragEnd}
              @dragend=${this._handleDragEnd}
            >
              <span class="mdc-text-field__ripple"></span>
              <span
                class="mdc-floating-label ${this.value||this._drag?"mdc-floating-label--float-above":""}"
                id="label"
                >${this.label}</span
              >
              ${this.icon?x`<span
                    class="mdc-text-field__icon mdc-text-field__icon--leading"
                    tabindex="-1"
                  >
                    <ha-icon-button
                      @click=${this._openFilePicker}
                      .path=${this.icon}
                    ></ha-icon-button>
                  </span>`:""}
              <div class="value">${this.value}</div>
              <input
                id="input"
                type="file"
                class="mdc-text-field__input file"
                accept=${this.accept}
                @change=${this._handleFilePicked}
                aria-labelledby="label"
              />
              ${this.value?x`<span
                    class="mdc-text-field__icon mdc-text-field__icon--trailing"
                    tabindex="1"
                  >
                    <ha-icon-button
                      slot="suffix"
                      @click=${this._clearValue}
                      .label=${(null===(e=this.hass)||void 0===e?void 0:e.localize("ui.common.close"))||"close"}
                      .path=${$}
                    ></ha-icon-button>
                  </span>`:""}
              <span
                class="mdc-line-ripple ${this._drag?"mdc-line-ripple--active":""}"
              ></span>
            </label>
          `}
    `}},{kind:"method",key:"_openFilePicker",value:function(){var e;null===(e=this._input)||void 0===e||e.click()}},{kind:"method",key:"_handleDrop",value:function(e){var t;e.preventDefault(),e.stopPropagation(),null!==(t=e.dataTransfer)&&void 0!==t&&t.files&&o(this,"file-picked",{files:e.dataTransfer.files}),this._drag=!1}},{kind:"method",key:"_handleDragStart",value:function(e){e.preventDefault(),e.stopPropagation(),this._drag=!0}},{kind:"method",key:"_handleDragEnd",value:function(e){e.preventDefault(),e.stopPropagation(),this._drag=!1}},{kind:"method",key:"_handleFilePicked",value:function(e){o(this,"file-picked",{files:e.target.files})}},{kind:"method",key:"_clearValue",value:function(e){e.preventDefault(),this.value=null,o(this,"change")}},{kind:"get",static:!0,key:"styles",value:function(){return[kn,r`
        :host {
          display: block;
        }
        .mdc-text-field--filled {
          height: auto;
          padding-top: 16px;
          cursor: pointer;
        }
        .mdc-text-field--filled.mdc-text-field--with-trailing-icon {
          padding-top: 28px;
        }
        .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__icon {
          color: var(--secondary-text-color);
        }
        .mdc-text-field--filled.mdc-text-field--with-trailing-icon
          .mdc-text-field__icon {
          align-self: flex-end;
        }
        .mdc-text-field__icon--leading {
          margin-bottom: 12px;
          inset-inline-start: initial;
          inset-inline-end: 0px;
          direction: var(--direction);
        }
        .mdc-text-field--filled .mdc-floating-label--float-above {
          transform: scale(0.75);
          top: 8px;
        }
        .mdc-floating-label {
          inset-inline-start: 16px !important;
          inset-inline-end: initial !important;
          direction: var(--direction);
        }
        .mdc-text-field--filled .mdc-floating-label {
          inset-inline-start: 48px !important;
          inset-inline-end: initial !important;
          direction: var(--direction);
        }
        .dragged:before {
          position: var(--layout-fit_-_position);
          top: var(--layout-fit_-_top);
          right: var(--layout-fit_-_right);
          bottom: var(--layout-fit_-_bottom);
          left: var(--layout-fit_-_left);
          background: currentColor;
          content: "";
          opacity: var(--dark-divider-opacity);
          pointer-events: none;
          border-radius: 4px;
        }
        .value {
          width: 100%;
        }
        input.file {
          display: none;
        }
        img {
          max-width: 100%;
          max-height: 125px;
        }
        ha-icon-button {
          --mdc-icon-button-size: 24px;
          --mdc-icon-size: 20px;
        }
        ha-circular-progress {
          display: block;
          text-align-last: center;
        }
      `]}}]}}),g),f([A("ha-selector-file")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"field",decorators:[Qi()],key:"_filename",value:void 0},{kind:"field",decorators:[Qi()],key:"_busy",value:()=>!1},{kind:"method",key:"render",value:function(){var e;return x`
      <ha-file-upload
        .hass=${this.hass}
        .accept=${this.selector.file.accept}
        .icon=${sn}
        .label=${this.label}
        .required=${this.required}
        .disabled=${this.disabled}
        .helper=${this.helper}
        .uploading=${this._busy}
        .value=${this.value?(null===(e=this._filename)||void 0===e?void 0:e.name)||"Unknown file":""}
        @file-picked=${this._uploadFile}
        @change=${this._removeFile}
      ></ha-file-upload>
    `}},{kind:"method",key:"willUpdate",value:function(e){k(b(i.prototype),"willUpdate",this).call(this,e),e.has("value")&&this._filename&&this.value!==this._filename.fileId&&(this._filename=void 0)}},{kind:"method",key:"_uploadFile",value:async function(e){this._busy=!0;const t=e.detail.files[0];try{const e=await(async(e,t)=>{const i=new FormData;i.append("file",t);const a=await e.fetchWithAuth("/api/file_upload",{method:"POST",body:i});if(413===a.status)throw new Error(`Uploaded file is too large (${t.name})`);if(200!==a.status)throw new Error("Unknown error");return(await a.json()).file_id})(this.hass,t);this._filename={fileId:e,name:t.name},o(this,"value-changed",{value:e})}catch(e){wn(this,{text:this.hass.localize("ui.components.selectors.file.upload_failed",{reason:e.message||e})})}finally{this._busy=!1}}},{kind:"field",key:"_removeFile",value(){return async()=>{this._busy=!0;try{await(async(e,t)=>e.callApi("DELETE","file_upload",{file_id:t}))(this.hass,this.value)}catch(e){}finally{this._busy=!1}this._filename=void 0,o(this,"value-changed",{value:""})}}}]}}),g),f([A("ha-selector-number")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"placeholder",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"method",key:"render",value:function(){var e,t,i;const a="box"===this.selector.number.mode;return x`
      <div class="input">
        ${a?"":x`
              ${this.label?x`${this.label}${this.required?" *":""}`:""}
              <ha-slider
                .min=${this.selector.number.min}
                .max=${this.selector.number.max}
                .value=${this._value}
                .step=${null!==(e=this.selector.number.step)&&void 0!==e?e:1}
                .disabled=${this.disabled}
                .required=${this.required}
                pin
                ignore-bar-touch
                @change=${this._handleSliderChange}
              >
              </ha-slider>
            `}
        <ha-textfield
          inputMode="numeric"
          pattern="[0-9]+([\\.][0-9]+)?"
          .label=${"box"!==this.selector.number.mode?void 0:this.label}
          .placeholder=${this.placeholder}
          class=${ba({single:"box"===this.selector.number.mode})}
          .min=${this.selector.number.min}
          .max=${this.selector.number.max}
          .value=${null!==(t=this.value)&&void 0!==t?t:""}
          .step=${null!==(i=this.selector.number.step)&&void 0!==i?i:1}
          helperPersistent
          .helper=${a?this.helper:void 0}
          .disabled=${this.disabled}
          .required=${this.required}
          .suffix=${this.selector.number.unit_of_measurement}
          type="number"
          autoValidate
          ?no-spinner=${"box"!==this.selector.number.mode}
          @input=${this._handleInputChange}
        >
        </ha-textfield>
      </div>
      ${!a&&this.helper?x`<ha-input-helper-text>${this.helper}</ha-input-helper-text>`:""}
    `}},{kind:"get",key:"_value",value:function(){var e;return null!==(e=this.value)&&void 0!==e?e:this.selector.number.min||0}},{kind:"method",key:"_handleInputChange",value:function(e){e.stopPropagation();const t=""===e.target.value||isNaN(e.target.value)?this.required?this.selector.number.min||0:void 0:Number(e.target.value);this.value!==t&&o(this,"value-changed",{value:t})}},{kind:"method",key:"_handleSliderChange",value:function(e){e.stopPropagation();const t=Number(e.target.value);this.value!==t&&o(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      .input {
        display: flex;
        justify-content: space-between;
        align-items: center;
        direction: ltr;
      }
      ha-slider {
        flex: 1;
      }
      ha-textfield {
        --ha-textfield-input-width: 40px;
      }
      .single {
        --ha-textfield-input-width: unset;
        flex: 1;
      }
    `}}]}}),g),f([A("ha-selector-object")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_()],key:"placeholder",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return x`<ha-yaml-editor
        .hass=${this.hass}
        .readonly=${this.disabled}
        .label=${this.label}
        .required=${this.required}
        .placeholder=${this.placeholder}
        .defaultValue=${this.value}
        @value-changed=${this._handleChange}
      ></ha-yaml-editor>
      ${this.helper?x`<ha-input-helper-text>${this.helper}</ha-input-helper-text>`:""} `}},{kind:"method",key:"_handleChange",value:function(e){const t=e.target.value;e.target.isValid&&this.value!==t&&o(this,"value-changed",{value:t})}}]}}),g),ts&&await ts;const Nu=(e,t)=>Vu(t).format(e),Vu=n((e=>new Intl.DateTimeFormat("en"!==e.language||ss(e)?e.language:"en-u-hc-h23",{hour:"numeric",minute:"2-digit",hour12:ss(e)})));n((e=>new Intl.DateTimeFormat("en"!==e.language||ss(e)?e.language:"en-u-hc-h23",{hour:ss(e)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hour12:ss(e)}))),n((e=>new Intl.DateTimeFormat("en"!==e.language||ss(e)?e.language:"en-u-hc-h23",{weekday:"long",hour:ss(e)?"numeric":"2-digit",minute:"2-digit",hour12:ss(e)}))),n((()=>new Intl.DateTimeFormat(void 0,{hour:"numeric",minute:"2-digit",hour12:!1})));const qu={s:1,min:60,h:3600,d:86400},ju=(e,t,i,a)=>Ru(e,i,t.entity_id,t.attributes,void 0!==a?a:t.state),Ru=(e,t,i,a,n)=>{if("unknown"===n||"unavailable"===n)return e(`state.default.${n}`);if((e=>!!e.unit_of_measurement||!!e.state_class)(a)){if("duration"===a.device_class&&a.unit_of_measurement&&qu[a.unit_of_measurement])try{return o=n,s=a.unit_of_measurement,yo(parseFloat(o)*qu[s])||"0"}catch(e){}if("monetary"===a.device_class)try{return ds(n,t,{style:"currency",currency:a.unit_of_measurement,minimumFractionDigits:2})}catch(e){}const e=a.unit_of_measurement?"%"===a.unit_of_measurement?"%":` ${a.unit_of_measurement}`:"";return`${ds(n,t)}${e}`}var o,s;const r=gs(i);if("input_datetime"===r){if(void 0===n){let e;return a.has_date&&a.has_time?(e=new Date(a.year,a.month-1,a.day,a.hour,a.minute),rs(e,t)):a.has_date?(e=new Date(a.year,a.month-1,a.day),as(e,t)):a.has_time?(e=new Date,e.setHours(a.hour,a.minute),Nu(e,t)):n}try{const e=n.split(" ");if(2===e.length)return rs(new Date(e.join("T")),t);if(1===e.length){if(n.includes("-"))return as(new Date(`${n}T00:00`),t);if(n.includes(":")){const e=new Date;return Nu(new Date(`${e.toISOString().split("T")[0]}T${n}`),t)}}return n}catch(e){return n}}if("humidifier"===r&&"on"===n&&a.humidity)return`${a.humidity} %`;if("counter"===r||"number"===r||"input_number"===r)return ds(n,t);if("button"===r||"input_button"===r||"scene"===r||"sensor"===r&&"timestamp"===a.device_class)try{return rs(new Date(n),t)}catch(e){return n}var l;return"update"===r?"on"===n?(e=>Jr(e)||!!e.in_progress)(a)?Qr(a,4)?e("ui.card.update.installing_with_progress",{progress:a.in_progress}):e("ui.card.update.installing"):a.latest_version:a.skipped_version===a.latest_version?null!==(l=a.latest_version)&&void 0!==l?l:e("state.default.unavailable"):e("ui.card.update.up_to_date"):a.device_class&&e(`component.${r}.state.${a.device_class}.${n}`)||e(`component.${r}.state._.${n}`)||n},Uu={alarm_control_panel:["armed_away","armed_custom_bypass","armed_home","armed_night","armed_vacation","arming","disarmed","disarming","pending","triggered"],automation:["on","off"],binary_sensor:["on","off"],button:[],calendar:["on","off"],camera:["idle","recording","streaming"],cover:["closed","closing","open","opening"],device_tracker:["home","not_home"],fan:["on","off"],humidifier:["on","off"],input_boolean:["on","off"],input_button:[],light:["on","off"],lock:["jammed","locked","locking","unlocked","unlocking"],media_player:["idle","off","paused","playing","standby"],person:["home","not_home"],remote:["on","off"],scene:[],schedule:["on","off"],script:["on","off"],siren:["on","off"],sun:["above_horizon","below_horizon"],switch:["on","off"],update:["on","off"],vacuum:["cleaning","docked","error","idle","paused","returning"],weather:["clear-night","cloudy","exceptional","fog","hail","lightning-rainy","lightning","partlycloudy","pouring","rainy","snowy-rainy","snowy","sunny","windy-variant","windy"]},Hu={alarm_control_panel:{code_format:["number","text"]},binary_sensor:{device_class:["battery","battery_charging","co","cold","connectivity","door","garage_door","gas","heat","light","lock","moisture","motion","moving","occupancy","opening","plug","power","presence","problem","running","safety","smoke","sound","tamper","update","vibration","window"]},button:{device_class:["restart","update"]},camera:{frontend_stream_type:["hls","web_rtc"]},climate:{hvac_action:["off","idle","heating","cooling","drying","fan"]},cover:{device_class:["awning","blind","curtain","damper","door","garage","gate","shade","shutter","window"]},humidifier:{device_class:["humidifier","dehumidifier"]},media_player:{device_class:["tv","speaker","receiver"],media_content_type:["app","channel","episode","game","image","movie","music","playlist","tvshow","url","video"]},number:{device_class:["temperature"]},sensor:{device_class:["apparent_power","aqi","battery","carbon_dioxide","carbon_monoxide","current","date","duration","energy","frequency","gas","humidity","illuminance","monetary","nitrogen_dioxide","nitrogen_monoxide","nitrous_oxide","ozone","pm1","pm10","pm25","power_factor","power","pressure","reactive_power","signal_strength","sulphur_dioxide","temperature","timestamp","volatile_organic_compounds","voltage"],state_class:["measurement","total","total_increasing"]},switch:{device_class:["outlet","switch"]},update:{device_class:["firmware"]},water_heater:{away_mode:["on","off"]}};f([A("ha-entity-state-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"entityId",value:void 0},{kind:"field",decorators:[_()],key:"attribute",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"autofocus",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!1},{kind:"field",decorators:[_({type:Boolean,attribute:"allow-custom-value"})],key:"allowCustomValue",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"_opened",value:()=>!1},{kind:"field",decorators:[y("ha-combo-box",!0)],key:"_comboBox",value:void 0},{kind:"method",key:"shouldUpdate",value:function(e){return!(!e.has("_opened")&&this._opened)}},{kind:"method",key:"updated",value:function(e){if(e.has("_opened")&&this._opened){const e=this.entityId?this.hass.states[this.entityId]:void 0;this._comboBox.items=this.entityId&&e?((e,t)=>{const i=Hr(e),a=[];switch(!t&&i in Uu?a.push(...Uu[i]):t&&i in Hu&&t in Hu[i]&&a.push(...Hu[i][t]),i){case"climate":t?"fan_mode"===t?a.push(...e.attributes.fan_modes):"preset_mode"===t?a.push(...e.attributes.preset_modes):"swing_mode"===t&&a.push(...e.attributes.swing_modes):a.push(...e.attributes.hvac_modes);break;case"device_tracker":case"person":t||a.push("home","not_home");break;case"fan":"preset_mode"===t&&a.push(...e.attributes.preset_modes);break;case"humidifier":"mode"===t&&a.push(...e.attributes.available_modes);break;case"input_select":case"select":t||a.push(...e.attributes.options);break;case"light":"effect"===t?a.push(...e.attributes.effect_list):"color_mode"===t&&a.push(...e.attributes.color_modes);break;case"media_player":"sound_mode"===t?a.push(...e.attributes.sound_mode_list):"source"===t&&a.push(...e.attributes.source_list);break;case"remote":"current_activity"===t&&a.push(...e.attributes.activity_list);break;case"vacuum":"fan_speed"===t&&a.push(...e.attributes.fan_speed_list);break;case"water_heater":t&&"operation_mode"!==t||a.push(...e.attributes.operation_list)}return t||a.push(...Ur),[...new Set(a)]})(e,this.attribute).map((t=>({value:t,label:this.attribute?t:ju(this.hass.localize,e,this.hass.locale,t)}))):[]}}},{kind:"method",key:"render",value:function(){var e;return this.hass?x`
      <ha-combo-box
        .hass=${this.hass}
        .value=${this.value?this.entityId&&this.hass.states[this.entityId]?ju(this.hass.localize,this.hass.states[this.entityId],this.hass.locale,this.value):this.value:""}
        .autofocus=${this.autofocus}
        .label=${null!==(e=this.label)&&void 0!==e?e:this.hass.localize("ui.components.entity.entity-state-picker.state")}
        .disabled=${this.disabled||!this.entityId}
        .required=${this.required}
        .helper=${this.helper}
        .allowCustomValue=${this.allowCustomValue}
        item-value-path="value"
        item-label-path="label"
        @opened-changed=${this._openedChanged}
        @value-changed=${this._valueChanged}
      >
      </ha-combo-box>
    `:x``}},{kind:"method",key:"_openedChanged",value:function(e){this._opened=e.detail.value}},{kind:"method",key:"_valueChanged",value:function(e){this.value=e.detail.value}}]}}),g),f([A("ha-selector-state")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"field",decorators:[_()],key:"context",value:void 0},{kind:"method",key:"render",value:function(){var e,t;return x`
      <ha-entity-state-picker
        .hass=${this.hass}
        .entityId=${this.selector.state.entity_id||(null===(e=this.context)||void 0===e?void 0:e.filter_entity)}
        .attribute=${this.selector.state.attribute||(null===(t=this.context)||void 0===t?void 0:t.filter_attribute)}
        .value=${this.value}
        .label=${this.label}
        .helper=${this.helper}
        .disabled=${this.disabled}
        .required=${this.required}
        allow-custom-value
      ></ha-entity-state-picker>
    `}}]}}),Fc(g)),f([A("ha-target-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-domains"})],key:"includeDomains",value:void 0},{kind:"field",decorators:[_({type:Array,attribute:"include-device-classes"})],key:"includeDeviceClasses",value:void 0},{kind:"field",decorators:[_()],key:"deviceFilter",value:void 0},{kind:"field",decorators:[_()],key:"entityRegFilter",value:void 0},{kind:"field",decorators:[_()],key:"entityFilter",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"horizontal",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_areas",value:void 0},{kind:"field",decorators:[Qi()],key:"_devices",value:void 0},{kind:"field",decorators:[Qi()],key:"_entities",value:void 0},{kind:"field",decorators:[Qi()],key:"_addMode",value:void 0},{kind:"field",decorators:[y("#input")],key:"_inputElement",value:void 0},{kind:"method",key:"hassSubscribe",value:function(){return[Ic(this.hass.connection,(e=>{const t={};for(const i of e)t[i.area_id]=i;this._areas=t})),Tc(this.hass.connection,(e=>{const t={};for(const i of e)t[i.id]=i;this._devices=t})),Pc(this.hass.connection,(e=>{this._entities=e}))]}},{kind:"method",key:"render",value:function(){return this._areas&&this._devices&&this._entities?x`
      ${this.horizontal?x`
            <div class="horizontal-container">
              ${this._renderChips()} ${this._renderPicker()}
            </div>
            ${this._renderItems()}
          `:x`
            <div>
              ${this._renderItems()} ${this._renderPicker()}
              ${this._renderChips()}
            </div>
          `}
    `:x``}},{kind:"method",key:"_renderItems",value:function(){var e,t,i;return x`
      <div class="mdc-chip-set items">
        ${null!==(e=this.value)&&void 0!==e&&e.area_id?ko(this.value.area_id).map((e=>{const t=this._areas[e];return this._renderChip("area_id",e,(null==t?void 0:t.name)||e,void 0,rn)})):""}
        ${null!==(t=this.value)&&void 0!==t&&t.device_id?ko(this.value.device_id).map((e=>{const t=this._devices[e];return this._renderChip("device_id",e,t?Ec(t,this.hass):e,void 0,aa)})):""}
        ${null!==(i=this.value)&&void 0!==i&&i.entity_id?ko(this.value.entity_id).map((e=>{const t=this.hass.states[e];return this._renderChip("entity_id",e,t?bo(t):e,t)})):""}
      </div>
    `}},{kind:"method",key:"_renderChips",value:function(){return x`
      <div class="mdc-chip-set">
        <div
          class="mdc-chip area_id add"
          .type=${"area_id"}
          @click=${this._showPicker}
        >
          <div class="mdc-chip__ripple"></div>
          <ha-svg-icon
            class="mdc-chip__icon mdc-chip__icon--leading"
            .path=${ta}
          ></ha-svg-icon>
          <span role="gridcell">
            <span role="button" tabindex="0" class="mdc-chip__primary-action">
              <span class="mdc-chip__text"
                >${this.hass.localize("ui.components.target-picker.add_area_id")}</span
              >
            </span>
          </span>
        </div>
        <div
          class="mdc-chip device_id add"
          .type=${"device_id"}
          @click=${this._showPicker}
        >
          <div class="mdc-chip__ripple"></div>
          <ha-svg-icon
            class="mdc-chip__icon mdc-chip__icon--leading"
            .path=${ta}
          ></ha-svg-icon>
          <span role="gridcell">
            <span role="button" tabindex="0" class="mdc-chip__primary-action">
              <span class="mdc-chip__text"
                >${this.hass.localize("ui.components.target-picker.add_device_id")}</span
              >
            </span>
          </span>
        </div>
        <div
          class="mdc-chip entity_id add"
          .type=${"entity_id"}
          @click=${this._showPicker}
        >
          <div class="mdc-chip__ripple"></div>
          <ha-svg-icon
            class="mdc-chip__icon mdc-chip__icon--leading"
            .path=${ta}
          ></ha-svg-icon>
          <span role="gridcell">
            <span role="button" tabindex="0" class="mdc-chip__primary-action">
              <span class="mdc-chip__text"
                >${this.hass.localize("ui.components.target-picker.add_entity_id")}</span
              >
            </span>
          </span>
        </div>
      </div>
      ${this.helper?x`<ha-input-helper-text>${this.helper}</ha-input-helper-text>`:""}
    `}},{kind:"method",key:"_showPicker",value:async function(e){this._addMode=e.currentTarget.type,await this.updateComplete,setTimeout((()=>{var e,t;null===(e=this._inputElement)||void 0===e||e.open(),null===(t=this._inputElement)||void 0===t||t.focus()}),0)}},{kind:"method",key:"_renderChip",value:function(e,t,i,a,n){return x`
      <div
        class="mdc-chip ${ba({[e]:!0})}"
      >
        ${n?x`<ha-svg-icon
              class="mdc-chip__icon mdc-chip__icon--leading"
              .path=${n}
            ></ha-svg-icon>`:""}
        ${a?x`<ha-state-icon
              class="mdc-chip__icon mdc-chip__icon--leading"
              .state=${a}
            ></ha-state-icon>`:""}
        <span role="gridcell">
          <span role="button" tabindex="0" class="mdc-chip__primary-action">
            <span class="mdc-chip__text">${i}</span>
          </span>
        </span>
        ${"entity_id"===e?"":x` <span role="gridcell">
              <ha-icon-button
                class="expand-btn mdc-chip__icon mdc-chip__icon--trailing"
                tabindex="-1"
                role="button"
                .label=${this.hass.localize("ui.components.target-picker.expand")}
                .path=${ln}
                hideTooltip
                .id=${t}
                .type=${e}
                @click=${this._handleExpand}
              ></ha-icon-button>
              <paper-tooltip class="expand" animation-delay="0"
                >${this.hass.localize(`ui.components.target-picker.expand_${e}`)}</paper-tooltip
              >
            </span>`}
        <span role="gridcell">
          <ha-icon-button
            class="mdc-chip__icon mdc-chip__icon--trailing"
            tabindex="-1"
            role="button"
            .label=${this.hass.localize("ui.components.target-picker.remove")}
            .path=${$}
            hideTooltip
            .id=${t}
            .type=${e}
            @click=${this._handleRemove}
          ></ha-icon-button>
          <paper-tooltip animation-delay="0"
            >${this.hass.localize(`ui.components.target-picker.remove_${e}`)}</paper-tooltip
          >
        </span>
      </div>
    `}},{kind:"method",key:"_renderPicker",value:function(){switch(this._addMode){case"area_id":return x`
          <ha-area-picker
            .hass=${this.hass}
            id="input"
            .type=${"area_id"}
            .label=${this.hass.localize("ui.components.target-picker.add_area_id")}
            no-add
            .deviceFilter=${this.deviceFilter}
            .entityFilter=${this.entityRegFilter}
            .includeDeviceClasses=${this.includeDeviceClasses}
            .includeDomains=${this.includeDomains}
            @value-changed=${this._targetPicked}
          ></ha-area-picker>
        `;case"device_id":return x`
          <ha-device-picker
            .hass=${this.hass}
            id="input"
            .type=${"device_id"}
            .label=${this.hass.localize("ui.components.target-picker.add_device_id")}
            .deviceFilter=${this.deviceFilter}
            .entityFilter=${this.entityRegFilter}
            .includeDeviceClasses=${this.includeDeviceClasses}
            .includeDomains=${this.includeDomains}
            @value-changed=${this._targetPicked}
          ></ha-device-picker>
        `;case"entity_id":return x`
          <ha-entity-picker
            .hass=${this.hass}
            id="input"
            .type=${"entity_id"}
            .label=${this.hass.localize("ui.components.target-picker.add_entity_id")}
            .entityFilter=${this.entityFilter}
            .includeDeviceClasses=${this.includeDeviceClasses}
            .includeDomains=${this.includeDomains}
            @value-changed=${this._targetPicked}
            allow-custom-entity
          ></ha-entity-picker>
        `}return x``}},{kind:"method",key:"_targetPicked",value:function(e){if(e.stopPropagation(),!e.detail.value)return;const t=e.detail.value,i=e.currentTarget;i.value="",this._addMode=void 0,o(this,"value-changed",{value:this.value?{...this.value,[i.type]:this.value[i.type]?[...ko(this.value[i.type]),t]:t}:{[i.type]:t}})}},{kind:"method",key:"_handleExpand",value:function(e){const t=e.currentTarget,i=[],a=[];if("area_id"===t.type)Object.values(this._devices).forEach((e=>{var a;e.area_id!==t.id||null!==(a=this.value.device_id)&&void 0!==a&&a.includes(e.id)||!this._deviceMeetsFilter(e)||i.push(e.id)})),this._entities.forEach((e=>{var i;e.area_id!==t.id||null!==(i=this.value.entity_id)&&void 0!==i&&i.includes(e.entity_id)||!this._entityRegMeetsFilter(e)||a.push(e.entity_id)}));else{if("device_id"!==t.type)return;this._entities.forEach((e=>{var i;e.device_id!==t.id||null!==(i=this.value.entity_id)&&void 0!==i&&i.includes(e.entity_id)||!this._entityRegMeetsFilter(e)||a.push(e.entity_id)}))}let n=this.value;a.length&&(n=this._addItems(n,"entity_id",a)),i.length&&(n=this._addItems(n,"device_id",i)),n=this._removeItem(n,t.type,t.id),o(this,"value-changed",{value:n})}},{kind:"method",key:"_handleRemove",value:function(e){const t=e.currentTarget;o(this,"value-changed",{value:this._removeItem(this.value,t.type,t.id)})}},{kind:"method",key:"_addItems",value:function(e,t,i){return{...e,[t]:e[t]?ko(e[t]).concat(i):i}}},{kind:"method",key:"_removeItem",value:function(e,t,i){const a=ko(e[t]).filter((e=>String(e)!==i));if(a.length)return{...e,[t]:a};const n={...e};return delete n[t],Object.keys(n).length?n:void 0}},{kind:"method",key:"_deviceMeetsFilter",value:function(e){var t;const i=null===(t=this._entities)||void 0===t?void 0:t.filter((t=>t.device_id===e.id));if(this.includeDomains){if(!i||!i.length)return!1;if(!i.some((e=>this.includeDomains.includes(gs(e.entity_id)))))return!1}if(this.includeDeviceClasses){if(!i||!i.length)return!1;if(!i.some((e=>{const t=this.hass.states[e.entity_id];return!!t&&(t.attributes.device_class&&this.includeDeviceClasses.includes(t.attributes.device_class))})))return!1}return!this.deviceFilter||this.deviceFilter(e)}},{kind:"method",key:"_entityRegMeetsFilter",value:function(e){if(e.entity_category)return!1;if(this.includeDomains&&!this.includeDomains.includes(gs(e.entity_id)))return!1;if(this.includeDeviceClasses){const t=this.hass.states[e.entity_id];if(!t)return!1;if(!t.attributes.device_class||!this.includeDeviceClasses.includes(t.attributes.device_class))return!1}return!this.entityRegFilter||this.entityRegFilter(e)}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ${dn(En)}
      .horizontal-container {
        display: flex;
        flex-wrap: wrap;
        min-height: 56px;
        align-items: center;
      }
      .mdc-chip {
        color: var(--primary-text-color);
      }
      .items {
        z-index: 2;
      }
      .mdc-chip-set {
        padding: 4px 0;
      }
      .mdc-chip.add {
        color: rgba(0, 0, 0, 0.87);
      }
      .mdc-chip:not(.add) {
        cursor: default;
      }
      .mdc-chip ha-icon-button {
        --mdc-icon-button-size: 24px;
        display: flex;
        align-items: center;
        outline: none;
      }
      .mdc-chip ha-icon-button ha-svg-icon {
        border-radius: 50%;
        background: var(--secondary-text-color);
      }
      .mdc-chip__icon.mdc-chip__icon--trailing {
        width: 16px;
        height: 16px;
        --mdc-icon-size: 14px;
        color: var(--secondary-text-color);
        margin-inline-start: 4px !important;
        margin-inline-end: -4px !important;
        direction: var(--direction);
      }
      .mdc-chip__icon--leading {
        display: flex;
        align-items: center;
        justify-content: center;
        --mdc-icon-size: 20px;
        border-radius: 50%;
        padding: 6px;
        margin-left: -14px !important;
        margin-inline-start: -14px !important;
        margin-inline-end: 4px !important;
        direction: var(--direction);
      }
      .expand-btn {
        margin-right: 0;
      }
      .mdc-chip.area_id:not(.add) {
        border: 2px solid #fed6a4;
        background: var(--card-background-color);
      }
      .mdc-chip.area_id:not(.add) .mdc-chip__icon--leading,
      .mdc-chip.area_id.add {
        background: #fed6a4;
      }
      .mdc-chip.device_id:not(.add) {
        border: 2px solid #a8e1fb;
        background: var(--card-background-color);
      }
      .mdc-chip.device_id:not(.add) .mdc-chip__icon--leading,
      .mdc-chip.device_id.add {
        background: #a8e1fb;
      }
      .mdc-chip.entity_id:not(.add) {
        border: 2px solid #d2e7b9;
        background: var(--card-background-color);
      }
      .mdc-chip.entity_id:not(.add) .mdc-chip__icon--leading,
      .mdc-chip.entity_id.add {
        background: #d2e7b9;
      }
      .mdc-chip:hover {
        z-index: 5;
      }
      paper-tooltip.expand {
        min-width: 200px;
      }
      :host([disabled]) .mdc-chip {
        opacity: var(--light-disabled-opacity);
        pointer-events: none;
      }
    `}}]}}),Fc(g)),f([A("ha-selector-target")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[Qi()],key:"_entitySources",value:void 0},{kind:"field",decorators:[Qi()],key:"_entities",value:void 0},{kind:"field",key:"_deviceIntegrationLookup",value:()=>n(Lc)},{kind:"method",key:"hassSubscribe",value:function(){return[Pc(this.hass.connection,(e=>{this._entities=e.filter((e=>null!==e.device_id))}))]}},{kind:"method",key:"updated",value:function(e){var t,a;k(b(i.prototype),"updated",this).call(this,e),e.has("selector")&&(null!==(t=this.selector.target.device)&&void 0!==t&&t.integration||null!==(a=this.selector.target.entity)&&void 0!==a&&a.integration)&&!this._entitySources&&Ou(this.hass).then((e=>{this._entitySources=e}))}},{kind:"method",key:"render",value:function(){var e,t;return(null!==(e=this.selector.target.device)&&void 0!==e&&e.integration||null!==(t=this.selector.target.entity)&&void 0!==t&&t.integration)&&!this._entitySources?x``:x`<ha-target-picker
      .hass=${this.hass}
      .value=${this.value}
      .helper=${this.helper}
      .deviceFilter=${this._filterDevices}
      .entityFilter=${this._filterEntities}
      .disabled=${this.disabled}
    ></ha-target-picker>`}},{kind:"field",key:"_filterEntities",value(){return e=>!this.selector.target.entity||Pu(this.selector.target.entity,e,this._entitySources)}},{kind:"field",key:"_filterDevices",value(){return e=>{if(!this.selector.target.device)return!0;const t=this._entitySources&&this._entities?this._deviceIntegrationLookup(this._entitySources,this._entities):void 0;return Mu(this.selector.target.device,e,t)}}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-target-picker {
        display: block;
      }
    `}}]}}),Fc(g)),f([A("ha-selector-template")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return x`
      ${this.label?x`<p>${this.label}${this.required?" *":""}</p>`:""}
      <ha-code-editor
        mode="jinja2"
        .hass=${this.hass}
        .value=${this.value}
        .readOnly=${this.disabled}
        autofocus
        autocomplete-entities
        autocomplete-icons
        @value-changed=${this._handleChange}
        dir="ltr"
      ></ha-code-editor>
      ${this.helper?x`<ha-input-helper-text>${this.helper}</ha-input-helper-text>`:""}
    `}},{kind:"method",key:"_handleChange",value:function(e){const t=e.target.value;this.value!==t&&o(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      p {
        margin-top: 0;
      }
    `}}]}}),g),f([A("ha-selector-text")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"placeholder",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"field",decorators:[Qi()],key:"_unmaskedPassword",value:()=>!1},{kind:"method",key:"render",value:function(){var e,t,i,a,n;return null!==(e=this.selector.text)&&void 0!==e&&e.multiline?x`<ha-textarea
        .label=${this.label}
        .placeholder=${this.placeholder}
        .value=${this.value||""}
        .helper=${this.helper}
        helperPersistent
        .disabled=${this.disabled}
        @input=${this._handleChange}
        autocapitalize="none"
        autocomplete="off"
        spellcheck="false"
        .required=${this.required}
        autogrow
      ></ha-textarea>`:x`<ha-textfield
        .value=${this.value||""}
        .placeholder=${this.placeholder||""}
        .helper=${this.helper}
        helperPersistent
        .disabled=${this.disabled}
        .type=${this._unmaskedPassword?"text":null===(t=this.selector.text)||void 0===t?void 0:t.type}
        @input=${this._handleChange}
        .label=${this.label||""}
        .suffix=${"password"===(null===(i=this.selector.text)||void 0===i?void 0:i.type)?x`<div style="width: 24px"></div>`:null===(a=this.selector.text)||void 0===a?void 0:a.suffix}
        .required=${this.required}
      ></ha-textfield>
      ${"password"===(null===(n=this.selector.text)||void 0===n?void 0:n.type)?x`<ha-icon-button
            toggles
            .label=${(this._unmaskedPassword?"Hide":"Show")+" password"}
            @click=${this._toggleUnmaskedPassword}
            .path=${this._unmaskedPassword?cn:ne}
          ></ha-icon-button>`:""}`}},{kind:"method",key:"_toggleUnmaskedPassword",value:function(){this._unmaskedPassword=!this._unmaskedPassword}},{kind:"method",key:"_handleChange",value:function(e){let t=e.target.value;this.value!==t&&(""!==t||this.required||(t=void 0),o(this,"value-changed",{value:t}))}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      :host {
        display: block;
        position: relative;
      }
      ha-textarea,
      ha-textfield {
        width: 100%;
      }
      ha-icon-button {
        position: absolute;
        top: 16px;
        right: 16px;
        --mdc-icon-button-size: 24px;
        --mdc-icon-size: 20px;
        color: var(--secondary-text-color);
        inset-inline-start: initial;
        inset-inline-end: 16px;
        direction: var(--direction);
      }
    `}}]}}),g),f([A("ha-selector-time")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!1},{kind:"method",key:"render",value:function(){return x`
      <ha-time-input
        .value=${this.value}
        .locale=${this.hass.locale}
        .disabled=${this.disabled}
        .required=${this.required}
        .helper=${this.helper}
        .label=${this.label}
        enable-second
      ></ha-time-input>
    `}}]}}),g),f([A("ha-selector-icon")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return x`
      <ha-icon-picker
        .label=${this.label}
        .value=${this.value}
        .required=${this.required}
        .disabled=${this.disabled}
        .helper=${this.helper}
        .fallbackPath=${this.selector.icon.fallbackPath}
        .placeholder=${this.selector.icon.placeholder}
        @value-changed=${this._valueChanged}
      ></ha-icon-picker>
    `}},{kind:"method",key:"_valueChanged",value:function(e){o(this,"value-changed",{value:e.detail.value})}}]}}),g),f([A("ha-theme-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!1},{kind:"method",key:"render",value:function(){return x`
      <ha-select
        .label=${this.label||this.hass.localize("ui.components.theme-picker.theme")}
        .value=${this.value}
        .required=${this.required}
        .disabled=${this.disabled}
        @selected=${this._changed}
        @closed=${Tn}
        fixedMenuPosition
        naturalMenuWidth
      >
        <mwc-list-item value="remove"
          >${this.hass.localize("ui.components.theme-picker.no_theme")}</mwc-list-item
        >
        ${Object.keys(this.hass.themes.themes).sort().map((e=>x`<mwc-list-item .value=${e}>${e}</mwc-list-item>`))}
      </ha-select>
    `}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-select {
        width: 100%;
      }
    `}},{kind:"method",key:"_changed",value:function(e){this.hass&&""!==e.target.value&&(this.value="remove"===e.target.value?void 0:e.target.value,o(this,"value-changed",{value:this.value}))}}]}}),g),f([A("ha-selector-theme")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){return x`
      <ha-theme-picker
        .hass=${this.hass}
        .value=${this.value}
        .label=${this.label}
        .disabled=${this.disabled}
        .required=${this.required}
      ></ha-theme-picker>
    `}}]}}),g);const Gu=e=>e.tileLayer("https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}"+(e.Browser.retina?"@2x.png":".png"),{attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>, &copy; <a href="https://carto.com/attributions">CARTO</a>',subdomains:"abcd",minZoom:0,maxZoom:20}),Wu=async()=>{"function"!=typeof ResizeObserver&&(window.ResizeObserver=(await import("./c.004a7b01.js")).default)};let Ku=f(null,(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:"entity-id"})],key:"entityId",value:void 0},{kind:"field",decorators:[_({attribute:"entity-name"})],key:"entityName",value:void 0},{kind:"field",decorators:[_({attribute:"entity-picture"})],key:"entityPicture",value:void 0},{kind:"field",decorators:[_({attribute:"entity-color"})],key:"entityColor",value:void 0},{kind:"method",key:"render",value:function(){return x`
      <div
        class="marker"
        style=${Ji({"border-color":this.entityColor})}
        @click=${this._badgeTap}
      >
        ${this.entityPicture?x`<div
              class="entity-picture"
              style=${Ji({"background-image":`url(${this.entityPicture})`})}
            ></div>`:this.entityName}
      </div>
    `}},{kind:"method",key:"_badgeTap",value:function(e){e.stopPropagation(),this.entityId&&o(this,"hass-more-info",{entityId:this.entityId})}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      .marker {
        display: flex;
        justify-content: center;
        align-items: center;
        box-sizing: border-box;
        overflow: hidden;
        width: 48px;
        height: 48px;
        font-size: var(--ha-marker-font-size, 1.5em);
        border-radius: 50%;
        border: 1px solid var(--ha-marker-color, var(--primary-color));
        color: var(--primary-text-color);
        background-color: var(--card-background-color);
      }
      .entity-picture {
        background-size: cover;
        height: 100%;
        width: 100%;
      }
    `}}]}}),g);customElements.define("ha-entity-marker",Ku);const Yu=e=>"string"==typeof e?e:e.entity_id;f([A("ha-map")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"entities",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"paths",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"layers",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"autoFit",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"fitZones",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"darkMode",value:void 0},{kind:"field",decorators:[_({type:Number})],key:"zoom",value:()=>14},{kind:"field",decorators:[Qi()],key:"_loaded",value:()=>!1},{kind:"field",key:"leafletMap",value:void 0},{kind:"field",key:"Leaflet",value:void 0},{kind:"field",key:"_resizeObserver",value:void 0},{kind:"field",key:"_mapItems",value:()=>[]},{kind:"field",key:"_mapZones",value:()=>[]},{kind:"field",key:"_mapPaths",value:()=>[]},{kind:"method",key:"connectedCallback",value:function(){k(b(i.prototype),"connectedCallback",this).call(this),this._loadMap(),this._attachObserver()}},{kind:"method",key:"disconnectedCallback",value:function(){k(b(i.prototype),"disconnectedCallback",this).call(this),this.leafletMap&&(this.leafletMap.remove(),this.leafletMap=void 0,this.Leaflet=void 0),this._loaded=!1,this._resizeObserver&&this._resizeObserver.unobserve(this)}},{kind:"method",key:"update",value:function(e){var t;if(k(b(i.prototype),"update",this).call(this,e),!this._loaded)return;const a=e.get("hass");if(e.has("_loaded")||e.has("entities"))this._drawEntities();else if(this._loaded&&a&&this.entities)for(const e of this.entities)if(a.states[Yu(e)]!==this.hass.states[Yu(e)]){this._drawEntities();break}if((e.has("_loaded")||e.has("paths"))&&this._drawPaths(),(e.has("_loaded")||e.has("layers"))&&this._drawLayers(e.get("layers")),(e.has("_loaded")||(e.has("entities")||e.has("layers"))&&this.autoFit)&&this.fitMap(),e.has("zoom")&&this.leafletMap.setZoom(this.zoom),!e.has("darkMode")&&(!e.has("hass")||a&&a.themes.darkMode===this.hass.themes.darkMode))return;const n=null!==(t=this.darkMode)&&void 0!==t?t:this.hass.themes.darkMode;this.shadowRoot.getElementById("map").classList.toggle("dark",n)}},{kind:"method",key:"_loadMap",value:async function(){var e;let t=this.shadowRoot.getElementById("map");t||(t=document.createElement("div"),t.id="map",this.shadowRoot.append(t));const i=null!==(e=this.darkMode)&&void 0!==e?e:this.hass.themes.darkMode;[this.leafletMap,this.Leaflet]=await(async e=>{if(!e.parentNode)throw new Error("Cannot setup Leaflet map on disconnected element");const t=(await import("./c.99c1c4ba.js")).default;t.Icon.Default.imagePath="/static/images/leaflet/images/";const i=t.map(e),a=document.createElement("link");return a.setAttribute("href","/static/images/leaflet/leaflet.css"),a.setAttribute("rel","stylesheet"),e.parentNode.appendChild(a),i.setView([52.3731339,4.8903147],13),[i,t,Gu(t).addTo(i)]})(t),this.shadowRoot.getElementById("map").classList.toggle("dark",i),this._loaded=!0}},{kind:"method",key:"fitMap",value:function(){var e,t;if(!this.leafletMap||!this.Leaflet||!this.hass)return;if(!(this._mapItems.length||null!==(e=this.layers)&&void 0!==e&&e.length))return void this.leafletMap.setView(new this.Leaflet.LatLng(this.hass.config.latitude,this.hass.config.longitude),this.zoom);let i=this.Leaflet.latLngBounds(this._mapItems?this._mapItems.map((e=>e.getLatLng())):[]);var a;this.fitZones&&(null===(a=this._mapZones)||void 0===a||a.forEach((e=>{i.extend("getBounds"in e?e.getBounds():e.getLatLng())})));null===(t=this.layers)||void 0===t||t.forEach((e=>{i.extend("getBounds"in e?e.getBounds():e.getLatLng())})),this.layers||(i=i.pad(.5)),this.leafletMap.fitBounds(i,{maxZoom:this.zoom})}},{kind:"method",key:"_drawLayers",value:function(e){if(e&&e.forEach((e=>e.remove())),!this.layers)return;const t=this.leafletMap;this.layers.forEach((e=>{t.addLayer(e)}))}},{kind:"method",key:"_drawPaths",value:function(){const e=this.hass,t=this.leafletMap,i=this.Leaflet;if(!e||!t||!i)return;if(this._mapPaths.length&&(this._mapPaths.forEach((e=>e.remove())),this._mapPaths=[]),!this.paths)return;const a=getComputedStyle(this).getPropertyValue("--dark-primary-color");this.paths.forEach((e=>{let n,o;e.gradualOpacity&&(n=e.gradualOpacity/(e.points.length-2),o=1-e.gradualOpacity);for(let t=0;t<e.points.length-1;t++){const s=e.gradualOpacity?o+t*n:void 0;this._mapPaths.push(i.circleMarker(e.points[t],{radius:3,color:e.color||a,opacity:s,fillOpacity:s,interactive:!1})),this._mapPaths.push(i.polyline([e.points[t],e.points[t+1]],{color:e.color||a,opacity:s,interactive:!1}))}const s=e.points.length-1;if(s>=0){const t=e.gradualOpacity?o+s*n:void 0;this._mapPaths.push(i.circleMarker(e.points[s],{radius:3,color:e.color||a,opacity:t,fillOpacity:t,interactive:!1}))}this._mapPaths.forEach((e=>t.addLayer(e)))}))}},{kind:"method",key:"_drawEntities",value:function(){var e;const t=this.hass,i=this.leafletMap,a=this.Leaflet;if(!t||!i||!a)return;if(this._mapItems.length&&(this._mapItems.forEach((e=>e.remove())),this._mapItems=[]),this._mapZones.length&&(this._mapZones.forEach((e=>e.remove())),this._mapZones=[]),!this.entities)return;const n=getComputedStyle(this),o=n.getPropertyValue("--accent-color"),s=n.getPropertyValue("--dark-primary-color"),r=(null!==(e=this.darkMode)&&void 0!==e?e:this.hass.themes.darkMode)?"dark":"light";for(const e of this.entities){const i=t.states[Yu(e)];if(!i)continue;const n=bo(i),{latitude:l,longitude:d,passive:c,icon:u,radius:h,entity_picture:p,gps_accuracy:v}=i.attributes;if(!l||!d)continue;if("zone"===Hr(i)){if(c)continue;let e="";if(u){const t=document.createElement("ha-icon");t.setAttribute("icon",u),e=t.outerHTML}else{const t=document.createElement("span");t.innerHTML=n,e=t.outerHTML}this._mapZones.push(a.marker([l,d],{icon:a.divIcon({html:e,iconSize:[24,24],className:r}),interactive:!1,title:n})),this._mapZones.push(a.circle([l,d],{interactive:!1,color:o,radius:h}));continue}const m=n.split(" ").map((e=>e[0])).join("").substr(0,3);this._mapItems.push(a.marker([l,d],{icon:a.divIcon({html:`\n              <ha-entity-marker\n                entity-id="${Yu(e)}"\n                entity-name="${m}"\n                entity-picture="${p?this.hass.hassUrl(p):""}"\n                ${"string"!=typeof e?`entity-color="${e.color}"`:""}\n              ></ha-entity-marker>\n            `,iconSize:[48,48],className:""}),title:bo(i)})),v&&this._mapItems.push(a.circle([l,d],{interactive:!1,color:s,radius:v}))}this._mapItems.forEach((e=>i.addLayer(e))),this._mapZones.forEach((e=>i.addLayer(e)))}},{kind:"method",key:"_attachObserver",value:async function(){this._resizeObserver||(await Wu(),this._resizeObserver=new ResizeObserver((()=>{var e;null===(e=this.leafletMap)||void 0===e||e.invalidateSize({debounceMoveend:!0})}))),this._resizeObserver.observe(this)}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      :host {
        display: block;
        height: 300px;
      }
      #map {
        height: 100%;
      }
      #map.dark {
        background: #090909;
        --map-filter: invert(0.9) hue-rotate(170deg) grayscale(0.7);
      }
      .light {
        color: #000000;
      }
      .dark {
        color: #ffffff;
      }
      .leaflet-tile-pane {
        filter: var(--map-filter);
      }
      .dark .leaflet-bar a {
        background-color: var(--card-background-color, #1c1c1c);
        color: #ffffff;
      }
      .leaflet-marker-draggable {
        cursor: move !important;
      }
      .leaflet-edit-resize {
        border-radius: 50%;
        cursor: nesw-resize !important;
      }
      .named-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        text-align: center;
        color: var(--primary-text-color);
      }
      .leaflet-pane {
        z-index: 0 !important;
      }
      .leaflet-control,
      .leaflet-top,
      .leaflet-bottom {
        z-index: 1 !important;
      }
    `}}]}}),ha),f([A("ha-locations-editor")],(function(e,t){class i extends t{constructor(){super(),e(this),import("./c.99c1c4ba.js").then((e=>{import("./c.bc53dda1.js").then((()=>{this.Leaflet=e.default,this._updateMarkers(),this.updateComplete.then((()=>this.fitMap()))}))}))}}return{F:i,d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"locations",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"autoFit",value:()=>!1},{kind:"field",decorators:[_({type:Number})],key:"zoom",value:()=>16},{kind:"field",decorators:[_({type:Boolean})],key:"darkMode",value:void 0},{kind:"field",decorators:[Qi()],key:"_locationMarkers",value:void 0},{kind:"field",decorators:[Qi()],key:"_circles",value:()=>({})},{kind:"field",decorators:[y("ha-map",!0)],key:"map",value:void 0},{kind:"field",key:"Leaflet",value:void 0},{kind:"method",key:"fitMap",value:function(){this.map.fitMap()}},{kind:"method",key:"fitMarker",value:function(e){if(!this.map.leafletMap||!this._locationMarkers)return;const t=this._locationMarkers[e];if(t)if("getBounds"in t)this.map.leafletMap.fitBounds(t.getBounds()),t.bringToFront();else{const i=this._circles[e];i?this.map.leafletMap.fitBounds(i.getBounds()):this.map.leafletMap.setView(t.getLatLng(),this.zoom)}}},{kind:"method",key:"render",value:function(){return x`
      <ha-map
        .hass=${this.hass}
        .layers=${this._getLayers(this._circles,this._locationMarkers)}
        .zoom=${this.zoom}
        .autoFit=${this.autoFit}
        .darkMode=${this.darkMode}
      ></ha-map>
      ${this.helper?x`<ha-input-helper-text>${this.helper}</ha-input-helper-text>`:""}
    `}},{kind:"field",key:"_getLayers",value:()=>n(((e,t)=>{const i=[];return Array.prototype.push.apply(i,Object.values(e)),t&&Array.prototype.push.apply(i,Object.values(t)),i}))},{kind:"method",key:"willUpdate",value:function(e){k(b(i.prototype),"willUpdate",this).call(this,e),this.Leaflet&&e.has("locations")&&this._updateMarkers()}},{kind:"method",key:"_updateLocation",value:function(e){const t=e.target,i=t.getLatLng();let a=i.lng;Math.abs(a)>180&&(a=(a%360+540)%360-180);const n=[i.lat,a];o(this,"location-updated",{id:t.id,location:n},{bubbles:!1})}},{kind:"method",key:"_updateRadius",value:function(e){const t=e.target,i=this._locationMarkers[t.id];o(this,"radius-updated",{id:t.id,radius:i.getRadius()},{bubbles:!1})}},{kind:"method",key:"_markerClicked",value:function(e){const t=e.target;o(this,"marker-clicked",{id:t.id},{bubbles:!1})}},{kind:"method",key:"_updateMarkers",value:function(){if(!this.locations||!this.locations.length)return this._circles={},void(this._locationMarkers=void 0);const e={},t={},i=getComputedStyle(this).getPropertyValue("--accent-color");this.locations.forEach((a=>{let n;if(a.icon){const e=document.createElement("div");e.className="named-icon",a.name&&(e.innerText=a.name);const t=document.createElement("ha-icon");t.setAttribute("icon",a.icon),e.prepend(t),n=this.Leaflet.divIcon({html:e.outerHTML,iconSize:[24,24],className:"light"})}if(a.radius){const o=this.Leaflet.circle([a.latitude,a.longitude],{color:a.radius_color||i,radius:a.radius});a.radius_editable||a.location_editable?(o.editing.enable(),o.addEventListener("add",(()=>{const e=o.editing._moveMarker,t=o.editing._resizeMarkers[0];n&&e.setIcon(n),t.id=e.id=a.id,e.addEventListener("dragend",(e=>this._updateLocation(e))).addEventListener("click",(e=>this._markerClicked(e))),a.radius_editable?t.addEventListener("dragend",(e=>this._updateRadius(e))):t.remove()})),e[a.id]=o):t[a.id]=o}if(!a.radius||!a.radius_editable&&!a.location_editable){const t={title:a.name,draggable:a.location_editable};n&&(t.icon=n);const i=this.Leaflet.marker([a.latitude,a.longitude],t).addEventListener("dragend",(e=>this._updateLocation(e))).addEventListener("click",(e=>this._markerClicked(e)));i.id=a.id,e[a.id]=i}})),this._circles=t,this._locationMarkers=e,o(this,"markers-updated")}},{kind:"get",static:!0,key:"styles",value:function(){return r`
      ha-map {
        display: block;
        height: 100%;
      }
    `}}]}}),g),f([A("ha-selector-location")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[_({attribute:!1})],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"method",key:"render",value:function(){return x`
      <ha-locations-editor
        class="flex"
        .hass=${this.hass}
        .helper=${this.helper}
        .locations=${this._location(this.selector,this.value)}
        @location-updated=${this._locationChanged}
        @radius-updated=${this._radiusChanged}
      ></ha-locations-editor>
    `}},{kind:"field",key:"_location",value(){return n(((e,t)=>{const i=getComputedStyle(this),a=e.location.radius?i.getPropertyValue("--zone-radius-color")||i.getPropertyValue("--accent-color"):void 0;return[{id:"location",latitude:(null==t?void 0:t.latitude)||this.hass.config.latitude,longitude:(null==t?void 0:t.longitude)||this.hass.config.longitude,radius:e.location.radius?(null==t?void 0:t.radius)||1e3:void 0,radius_color:a,icon:e.location.icon||e.location.radius?"mdi:map-marker-radius":"mdi:map-marker",location_editable:!0,radius_editable:!0}]}))}},{kind:"method",key:"_locationChanged",value:function(e){const[t,i]=e.detail.location;o(this,"value-changed",{value:{...this.value,latitude:t,longitude:i}})}},{kind:"method",key:"_radiusChanged",value:function(e){const t=e.detail.radius;o(this,"value-changed",{value:{...this.value,radius:t}})}},{kind:"field",static:!0,key:"styles",value:()=>r`
    :host {
      display: block;
      height: 400px;
    }
  `}]}}),g);customElements.define("ha-labeled-slider",class extends d{static get template(){return c`
      <style>
        :host {
          display: block;
        }

        .title {
          margin: 5px 0 8px;
          color: var(--primary-text-color);
        }

        .slider-container {
          display: flex;
        }

        ha-icon {
          margin-top: 4px;
          color: var(--secondary-text-color);
        }

        ha-slider {
          flex-grow: 1;
          background-image: var(--ha-slider-background);
          border-radius: 4px;
        }
      </style>

      <div class="title">[[_getTitle()]]</div>
      <div class="extra-container"><slot name="extra"></slot></div>
      <div class="slider-container">
        <ha-icon icon="[[icon]]" hidden$="[[!icon]]"></ha-icon>
        <ha-slider
          min="[[min]]"
          max="[[max]]"
          step="[[step]]"
          pin="[[pin]]"
          disabled="[[disabled]]"
          value="{{value}}"
        ></ha-slider>
      </div>
      <template is="dom-if" if="[[helper]]">
        <ha-input-helper-text>[[helper]]</ha-input-helper-text>
      </template>
    `}_getTitle(){return`${this.caption}${this.caption&&this.required?" *":""}`}static get properties(){return{caption:String,disabled:Boolean,required:Boolean,min:Number,max:Number,pin:Boolean,step:Number,helper:String,extra:{type:Boolean,value:!1},ignoreBarTouch:{type:Boolean,value:!0},icon:{type:String,value:""},value:{type:Number,notify:!0}}}}),f([A("ha-selector-color_temp")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"method",key:"render",value:function(){var e,t,i,a;return x`
      <ha-labeled-slider
        pin
        icon="hass:thermometer"
        .caption=${this.label||""}
        .min=${null!==(e=null===(t=this.selector.color_temp)||void 0===t?void 0:t.min_mireds)&&void 0!==e?e:153}
        .max=${null!==(i=null===(a=this.selector.color_temp)||void 0===a?void 0:a.max_mireds)&&void 0!==i?i:500}
        .value=${this.value}
        .disabled=${this.disabled}
        .helper=${this.helper}
        .required=${this.required}
        @change=${this._valueChanged}
      ></ha-labeled-slider>
    `}},{kind:"method",key:"_valueChanged",value:function(e){o(this,"value-changed",{value:Number(e.target.value)})}},{kind:"field",static:!0,key:"styles",value:()=>r`
    ha-labeled-slider {
      --ha-slider-background: -webkit-linear-gradient(
        right,
        rgb(255, 160, 0) 0%,
        white 50%,
        rgb(166, 209, 255) 100%
      );
      /* The color temp minimum value shouldn't be rendered differently. It's not "off". */
      --paper-slider-knob-start-border-color: var(--primary-color);
    }
  `}]}}),g);let Zu=f([A("ha-selector")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[_()],key:"hass",value:void 0},{kind:"field",decorators:[_()],key:"selector",value:void 0},{kind:"field",decorators:[_()],key:"value",value:void 0},{kind:"field",decorators:[_()],key:"label",value:void 0},{kind:"field",decorators:[_()],key:"helper",value:void 0},{kind:"field",decorators:[_()],key:"placeholder",value:void 0},{kind:"field",decorators:[_({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[_({type:Boolean})],key:"required",value:()=>!0},{kind:"field",decorators:[_()],key:"context",value:void 0},{kind:"method",key:"focus",value:function(){var e,t;null===(e=this.shadowRoot)||void 0===e||null===(t=e.getElementById("selector"))||void 0===t||t.focus()}},{kind:"get",key:"_type",value:function(){return Object.keys(this.selector)[0]}},{kind:"method",key:"render",value:function(){return x`
      ${hn(`ha-selector-${this._type}`,{hass:this.hass,selector:this.selector,value:this.value,label:this.label,placeholder:this.placeholder,disabled:this.disabled,required:this.required,helper:this.helper,context:this.context,id:"selector"})}
    `}}]}}),g);var Qu=Object.freeze({__proto__:null,HaSelector:Zu});export{Xc as B,eu as M,Ur as U,ys as a,tu as b,Nn as c,su as d,jo as e,Ro as f,Wr as g,qo as h,Wu as i,Qu as j,To as l,Yo as t};
